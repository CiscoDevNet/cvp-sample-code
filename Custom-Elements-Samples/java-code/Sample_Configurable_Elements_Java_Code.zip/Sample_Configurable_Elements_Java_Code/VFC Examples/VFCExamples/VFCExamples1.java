/*
   Copyright (c) 1999-2005 Audium Corporation
   All rights reserved
*/

import java.util.*;

import com.audium.server.voiceElement.VoiceElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.session.VoiceElementData;

import com.audium.core.vfc.*;
import com.audium.core.vfc.form.*;
import com.audium.core.vfc.audio.*;
import com.audium.core.vfc.util.*;
import com.audium.core.vfc.util.vxml2.*;

/**
 * This voice element wraps around example 1 of the VFC Examples quick reference
 * document. It is not meant to be used in an application nor called into, it
 * exists only as an example of uses of the VFCs. Its code may be copied and 
 * modified in any developer's custom code.
 */
public class VFCExamples1 extends VoiceElementBase implements ElementInterface 
{
	public String getElementName()
	{
		return "VFC_Example1";
	}

	public String getDescription() 
	{
		return "This is the code from VFC Example #1";
	}

	public String getDisplayFolderName() 
	{
		return "Training";
	}

	public Setting[] getSettings() throws ElementException 
	{
		return null;
	} 

	public HashMap getAudioGroups() throws ElementException 
	{
		return null;
    }
    
	public String[] getAudioGroupDisplayOrder() 
	{
		return null;
	}

	public ExitState[] getExitStates() throws ElementException 
	{
		ExitState[] exitStateArray = new ExitState[1];
		exitStateArray[0] = new ExitState(ExitState.DONE);
		return exitStateArray;
	}

	public ElementData[] getElementData() throws ElementException 
	{
		return null;
	}
	
	protected String addXmlBody(VMain vxml, Hashtable reqParameters, VoiceElementData ved)
									throws VException, ElementException 
	{
		VPreference pref = ved.getPreference();
		
		/************* START VFC EXAMPLE CODE *************/
		
		// Set a page-scope property.
		vxml.setProperties(VProperty.getNew(pref, "someProperty", "someValue"));

		// Make a page-scope variable.
		vxml.add("myVar", "firstValue", VMain.WITH_QUOTES);

		VForm form = VForm.getNew(pref, "start");

		// Make a menu with two options that react to both DTMF and speech. All it does
		// is say the option chosen and exits.
		VMenuField menufield = VMenuField.getNew(pref, "myMenu", VMenuField.DTMF_SPEECH);
		menufield.setPromptCount(1, VAudio.getNew(pref, "To do something say or press 1 " +
                                                "To do something else, say or press 2. ", VAudio.TTS_ONLY));
		VAction exit = VAction.getNew(pref, VAction.EXIT);
		menufield.setChoice(new VoiceInput("1", "One"), VAudio.getNew(pref, "Option 1.", VAudio.TTS_ONLY), exit);
		menufield.setChoice(new VoiceInput("2", "Two"), VAudio.getNew(pref, "Option 2.", VAudio.TTS_ONLY), exit);

		form.add(menufield);    // Add the menu to the form.
		vxml.add(form);         // Add myForm to the VMain object

		// Set a page-scope link using an external grammar that contains a set of secret words.
		// When activated, the link jumps to the myOtherForm form saying something and continuing.
		// We want to set the URI�s maxage. This is a VXML 2.0-only feature so we use the V2 subclass.
		VGrammar linkGrammar = VGrammar.getNew(pref);
		linkGrammar.setSpeechSource("http://my.grammar.source/link.grammar");
		((VGrammarV2) linkGrammar).setMaxage(1000);  // Cast to the VGrammarV2 class to call this method.
		vxml.setLinks(VLink.getNew(pref, VLink.DOCUMENT, "myOtherForm", linkGrammar));

		// Make the other form. Note that the object instances can be reassigned. Once they have 
		// been inserted into other VFCs, their instances are stored internally.
		form = VForm.getNew(pref, "myOtherForm");
		VBlock block = VBlock.getNew(pref);

		// Make audio with a TTS-only phrase followed by a pre-recorded audio file (with transcript).
		VAudio testAudio = VAudio.getNew(pref, "You said the secret password. Congrats!", VAudio.TTS_ONLY);
		testAudio.add("/some/path/", "myAudioFile", "This audio says something.", "wav", false);
		block.add(testAudio);   // Add the audio to the block.

		// After this, store a value in the form-scope variable then go to myForm.
		VAction addAction = VAction.getNew(pref, VAction.ASSIGN, "myVar", "fromLink", VAction.WITHOUT_QUOTES);
		addAction.add(VAction.DOCUMENT, "myForm");

		block.add(addAction);   // Add the action to the block (occurs after the audio or won't hear it).
		form.add(block);        // Add the block to the myOtherForm form.
		vxml.add(form);         // Add myOtherForm to the VMain object.
		
		/************* END VFC EXAMPLE CODE *************/
		
		return "done";
	}
}