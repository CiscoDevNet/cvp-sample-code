/*
   Copyright (c) 1999-2005 Audium Corporation
   All rights reserved
*/

import java.util.*;

import com.audium.server.voiceElement.VoiceElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.session.VoiceElementData;

import com.audium.core.vfc.*;
import com.audium.core.vfc.form.*;
import com.audium.core.vfc.audio.*;
import com.audium.core.vfc.util.*;

/**
 * This voice element wraps around example 2 of the VFC Examples quick reference
 * document. It is not meant to be used in an application nor called into, it
 * exists only as an example of uses of the VFCs. Its code may be copied and 
 * modified in any developer's custom code.
 */
public class VFCExamples2 extends VoiceElementBase implements ElementInterface 
{
	public String getElementName()
	{
		return "VFC_Example2";
	}

	public String getDescription() 
	{
		return "This is the code from VFC Example #2";
	}

	public String getDisplayFolderName() 
	{
		return "Training";
	}

	public Setting[] getSettings() throws ElementException 
	{
		return null;
	} 

	public HashMap getAudioGroups() throws ElementException 
	{
		return null;
    }
    
	public String[] getAudioGroupDisplayOrder() 
	{
		return null;
	}

	public ExitState[] getExitStates() throws ElementException 
	{
		ExitState[] exitStateArray = new ExitState[1];
		exitStateArray[0] = new ExitState(ExitState.DONE);
		return exitStateArray;
	}

	public ElementData[] getElementData() throws ElementException 
	{
		return null;
	}
	
	protected String addXmlBody(VMain vxml, Hashtable reqParameters, VoiceElementData ved)
									throws VException, ElementException 
	{
		VPreference pref = ved.getPreference();
		
		/************* START VFC EXAMPLE CODE *************/
		
		VForm form = VForm.getNew(pref, "start");

		// Create a field that expects a grammar to define what to listen for.
		VField field = VBuiltInField.getNew(pref, VBuiltInField.GRAMMAR, "myField", 
			       			 VBuiltInField.SPEECH);

		// Make the initial prompt.
		field.setPromptCount(1, VAudio.getNew(pref, "To restart say restart, to continue say continue", VAudio.TTS_ONLY));

		// Make an inline grammar that listens for "restart" or "continue" and puts those values in the
		// field when recognized. The field names can be different for each utterance, but in this case,
		// we want both to be entered in the field. The final array contain the actual values to be 
		// placed in the field. These values are chosen to make their values easier to analyze.
		VGrammar speechGrammar = VGrammar.getNew(pref);
		speechGrammar.setSpeechInline(new String[] {"re start", "re do", "continue"}, 
                             		new String[] {"myField", "myField", "myField"}, 
                             		new String[] {"restart", "restart", "continue"});
		field.setGrammar(speechGrammar);

		// Make a nomatch event say an error message then reprompt (the default behavior). The 3rd nomatch 
		// says something else and will not reprompt. The second nomatch will do the same as the first.
		VEvent nomatch = VEvent.getNew(pref, VEvent.NOMATCH);
		nomatch.addCount(1, VAudio.getNew(pref, "I didn't understand you.", VAudio.TTS_ONLY));
		nomatch.addCount(3, VAudio.getNew(pref, "I still don't get you.", VAudio.TTS_ONLY));
		nomatch.setReprompt(3, false);   // Turn off the default reprompting behavior for nomatch #3.
		field.add(nomatch);

		// Make an if statement appear in the field's <filled> that resets myField when
		// restart is matched and say something in all other cases.
		VIfGroup speechIf = VIfGroup.getNew(pref);
		IfCondition expr = new IfCondition("myField", IfCondition.VALUE, IfCondition.EQUALS,  
                                  		"restart", VIfGroup.WITH_QUOTES);
		speechIf.add(expr, VAudio.getNew(pref, "Restarting the field.", VAudio.TTS_ONLY), 
             		VAction.getNew(pref, VAction.RESET_FIELDS, "myField"));
		speechIf.add(VAudio.getNew(pref, "In else. We will continue now.", VAudio.TTS_ONLY), null); // else

		field.add(speechIf); // Add the if to the field.
		form.add(field);     // Add the field to the form.

		// Play something when all the fields in the form are done (in its <filled>).
		form.add(VAudio.getNew(pref, "Great, we are all done.", VAudio.TTS_ONLY));

		vxml.add(form);

		/************* END VFC EXAMPLE CODE *************/
		
		return "done";
	}
}