/*
   Copyright (c) 1999-2005 Audium Corporation
   All rights reserved
*/

import java.util.*;

import com.audium.server.voiceElement.*;
import com.audium.server.session.*;
import com.audium.server.xml.*;

import com.audium.core.vfc.*;
import com.audium.core.vfc.util.*;

/* Unlike other voice elements, super elements must import the classes of
each subelement. */
import com.audium.server.voiceElement.menu.MYesNoMenu;
import com.audium.server.voiceElement.digit.MBasicDigit;

/**
 * This class illustrates the process of building elements out of other existing 
 * elements which act as "subelements". This voice element does not use the VFCs 
 * to produce VoiceXML, it simply assembles and manipulates the configurations 
 * of the subelements who then produce the VoiceXML. The "superelement" acts as 
 * a sort of state engine, controlling when each subelement is executed. Its 
 * role is similar to the role Audium Call Services plays when managing the 
 * call flow of an application.
 *
 * In this example, the superelement combines the individual subelements 
 * "Digits" and "Menu_Yes_No" to duplicate the functionality of the 
 * "Digits_With_Confirm" voice element. All the funcationality provided by these 
 * two existing Audium Elements are utilized, and additional functionality is 
 * added (disconfirm counts).
 * 
 * While this superelement simply uses the VoiceXML produced by the subelements, 
 * the superelement may also alter the VoiceXML produced by the subelements to 
 * suit its needs, however this is significantly harder and messier to do.
 *
 * Audium recommends that voice elements be built from scratch as using this 
 * methodology can get very complex and error prone. It is viable, however, if 
 * the desired element serves as a simple container for other elements that 
 * have already been constructed.
 */
public class NewDigitWithConfirm extends VoiceElementBase implements ElementInterface
{
	/**
	 * This method returns the name the voice element will have in the 
	 * Element Pane in Audium Builder for Studio.
	 */
    public String getElementName()
    {
        return "NewDigitWithConfirm";
    }

	/**
	 * This method returns the name of the folder in which this voice
	 * element resides. Return null if it is to appear directly under the 
	 * Elements folder.
	 */
    public String getDisplayFolderName() {
        
        return "Examples";
    }

	/**
	 * This method returns the text of a description of the voice element
	 * that will appear as a tooltip when the cursor points to the element.
	 */
    public String getDescription() 
    {
        return "This element makes a digit with confirm out of Digits and Menu_Yes_No";
    }

    /**
     * The settings for the superelement must be a combination of the settings 
     * for each subelement since this data must be passed on to the subelement. 
     * In this case, there are some settings in each subelement that have the 
     * same name, so to keep them separate, they are given different names and 
     * dynamically renamed later (see the code in addXMLBody).
     */
    public Setting[] getSettings() throws ElementException 
    {
        Setting[] settingArray = new Setting[9];

        /* For the Digits part of the element. Since there are settings that 
        share the same name between the subelements, we name them differently 
        for each subelement in the single superelement configuration. So here, 
        we name a setting "digits_confidence_level" to represent 
        "confidence_level" in the Digits voice element. We will deal with 
        renaming it when the time comes. */
        settingArray[0] = new Setting(Setting.INPUTMODE);
        settingArray[1] = new Setting("digits_confidence_level", "Digits Confidence Level",
                                      "The confidence level threshold to use during digits capture. Possible values: decimal (0.0 - 1.0). Default = 0.40.",
                                      true, true, true, new Float(0.0f), new Float(1.0f));
        settingArray[2] = new Setting("max_nomatch_count", "Digits Max NoMatch Count",
                                      "The maximum number of nomatch events allowed during digits capture. Possible values: int >= 0. 0 = infinite nomatches. Default = 3.",
                                      true, true, true, new Integer(0), null);
        settingArray[3] = new Setting("max_noinput_count", "Digits Max NoInput Count",
                                      "The maximum number of noinput events allowed during digits capture. Possible values: int >= 0. 0 = infinite noinputs. Default = 3.",
                                      true, true, true, new Integer(0), null);
        settingArray[4] = new Setting("max_digit", "Max Digit", 
                                      "This is the maximum digit value permitted by the voice element.", 
                                      true, true, true, Setting.INT);
        settingArray[5] = new Setting("min_digit",  "Min Digit",
                                      "This is the minimum digit value permitted by the voice element.", 
                                      true, true, true, Setting.INT);
        settingArray[6] = new Setting(Setting.NOINPUT_TIMEOUT);

        // Set setting defaults
        settingArray[0].setDefaultValue("both");
        settingArray[1].setDefaultValue("0.40");
        settingArray[2].setDefaultValue("3");
        settingArray[3].setDefaultValue("3");
        settingArray[6].setDefaultValue("5s");

        /* For the MenuYesNo part of the element. We will share the max noinput 
        and nomatch as well as the noinput timeout settings. */
        settingArray[7] = new Setting("confirmation_confidence_level", "Confirmation Confidence Level",
                                      "The confidence level threshold to use during the confirmation. Possible values: decimal (0.0 - 1.0). Default = 0.40.",
                                      true, true, true, new Float(0.0f), new Float(1.0f));
        settingArray[8] = new Setting("replay", "Replay",
                                      "This setting indicates whether or not the caller can say 'replay' to hear the initial audio group again.  Default = false.", 
                                      true, true, true, Setting.BOOLEAN);
      
        // Set setting defaults
        settingArray[7].setDefaultValue("0.50");
        settingArray[8].setDefaultValue("false");
        
        return settingArray;
    }        

    /**
     * Again, the audio groups are a combination of both subelements.
     */
    public HashMap getAudioGroups() throws ElementException {

        HashMap audioGroups = new HashMap(2);

        /* For the Digits part of the element. Again, audio groups have the 
        same name between the two subelements so we give them individual names 
        and rename them later. */
        AudioGroup[] digitsCaptureArray = new AudioGroup[4];

        digitsCaptureArray[0] = new AudioGroup("digits_initial_audio_group", "Digits Initial",
                                               "This audio group will be played on entry into the voice element.",
                                               true, true);
        digitsCaptureArray[1] = new AudioGroup("digits_nomatch_audio_group", "Digits NoMatch",
                                               "This audio group will be played when the caller enters an invalid " +
                                               "number.", false, false);
        digitsCaptureArray[2] = new AudioGroup("digits_noinput_audio_group", "Digits NoInput",
                                               "This audio group will be played when the caller does not respond to " +
                                               "the audio group to enter a digit value.", false, false);
        digitsCaptureArray[3] = new AudioGroup("digits_help_audio_group", "Digits Help",
                                               "This audio group will be played when the caller says 'help' after " +
                                               "being prompted to enter a digit value.", false, false);

        audioGroups.put("Digits Capture", digitsCaptureArray);
        
        // For the MenuYesNo part of the element
        AudioGroup[] confirmationArray = new AudioGroup[4];
        confirmationArray[0] = new AudioGroup("confirm_initial_audio_group", "Confirm Initial",
                                              "This audio group will be played on entry into the confirmation.",
                                              true, true);
        confirmationArray[1] = new AudioGroup("confirm_nomatch_audio_group", "Confirm NoMatch",
                                              "This audio group will be played when the caller enters an invalid " +
                                              "number in the confirmation menu.", false, false);
        confirmationArray[2] = new AudioGroup("confirm_noinput_audio_group", "Confirm NoInput",
                                              "This audio group will be played when the caller does not respond to " +
                                              "the audio group to confirm the value.", false, false);
        confirmationArray[3] = new AudioGroup("confirm_help_audio_group", "Confirm Help",
                                              "This audio group will be played when the caller says 'help' after " +
                                              "in the confirmation menu.", false, false);
        
        audioGroups.put("Confirmation", confirmationArray);
        
        AudioGroup[] endArray = new AudioGroup[1];
        endArray[0] = new AudioGroup("yes_audio_group", "Yes",
                                     "This audio group will be played when the caller says yes.", false, true);
        
        audioGroups.put("End", endArray);
        return audioGroups;
    }
    
    /**
     * There are three sets of audio groups, one for the digit capture, one for 
     * the confirmation, and one for the end. The End set comes from the set
     * defined in each of the Audium Digits and Menu_Yes_No elements.
     */
    public String[] getAudioGroupDisplayOrder()
    {
        String[] displayOrder = new String[3];
        
        /* We display the audio groups needed for different parts separately to 
        help with configuration. */
        displayOrder[0] = "Digits Capture";
        displayOrder[1] = "Confirmation";
        displayOrder[2] = "End";
        
        return displayOrder;
    }

    /**
     * The exit states are also a combination of the subelements however the 
     * superelement introduces a new exit state that handles a maximum 
     * disconfirmed situation, which must be handled by the superelement itself.
     */
    public ExitState[] getExitStates() throws ElementException {

        ExitState[] exitStateArray = new ExitState[4];

        /* Note that the addition of a confirmation menu introduces another exit 
        state: max_disconfirm. This exit state will have to be handled entirely 
        by the superelement. */
        exitStateArray[0] = new ExitState(ExitState.DONE);
        exitStateArray[1] = new ExitState(ExitState.MAX_NOMATCH);
        exitStateArray[2] = new ExitState(ExitState.MAX_NOINPUT);
        exitStateArray[3] = new ExitState("max_disconfirm", "Max Disconfirm", "maximum disconfirm");

        return exitStateArray;
    }

    public ElementData[] getElementData() throws ElementException {
        ElementData[] elementDataArray = new ElementData[3];

        /* We choose to store the digit entry confidence in a variable named
        "confidence" and the confirmation confidence in a variable named
        "confirmation_confidence" to keep them separate. Also, despite the fact
        that the Menu_Yes_No element stores the selection in a variable, we don't
        need it since we already take care of going back to the digit entry when
        the caller says "no". */
        elementDataArray[0] = new ElementData(ElementData.CONFIDENCE);
        elementDataArray[1] = new ElementData("confirmation_confidence", "This is the confirmation confidence");
        elementDataArray[2] = new ElementData(ElementData.VALUE);

        return elementDataArray;
    }
    
    /**
     * As with any voice element, the action takes place in the addXmlBody 
     * method. The only thing that is different is that instead of using the 
     * VFCs here to create the VoiceXML, the superelements coaxes the 
     * subelements to do the work instead. The superelement simply acts as the 
     * glue by keeping track of the state.
     */
    protected String addXmlBody(VMain vxml, Hashtable reqParameters, VoiceElementData ved)
                                throws VException, ElementException 
    {
        VoiceElementResult result = null;
        String returned = null;
        
        /* For informational purposes, we will print out all the scratch data 
        to the console. */
        System.out.println("\nHere is all the scratch data in this element:");
        HashMap scratchMap = ved.getAllScratchData();        
        Iterator iter = scratchMap.entrySet().iterator();
        while(iter.hasNext()) {
            Map.Entry entry = (Map.Entry)iter.next();
            System.out.println("  Key: \"" + entry.getKey() + " Value: \"" + entry.getValue()+"\"");
        }
        /* End scratch data printout. */
        
        /* As the superelement, we need to take care of knowing in which 
        subelement we are in at any moment in time. We use scratch space for 
        this. Note that we need to make sure that the scratch data we use here
        does not conflict with the scratch data used by the subelements as they
        all share the same namespace. */
        Object insidePart1 = ved.getScratchData("insidePart1");
        if (insidePart1 == null || ((Boolean)insidePart1).booleanValue()) {
            System.out.println("We are going to visit the first subelement");
            
            /* Before entering a subelement, it is important to set up the input 
            configuration correctly. Each voice element requires a configuration 
            with settings and audio groups of a certain name. The configuration 
            for the superelement chose to use settings and audio groups with 
            different names for those that apply for the digit entry and those 
            that applied to the confirmation menu. At this point, these values 
            need to be renamed to the values expected by the subelement. 
            
            It is important to remember that once changes are made to the 
            configuration, it applies for all future calls to this voice element 
            instance. This means that when it is time to play the confirmation 
            part of the element, we will need to do another set of renamings in 
            order to set up the inputs correctly.
                
            Note that we do the renaming only once, when the sub element is 
            visited for the first time. */
            if (ved.getScratchData("initializedPart1") == null) {
                VoiceElementConfig config = ved.getVoiceElementConfig();
                
                config.renameSetting("digits_confidence_level", "confidence_level"); 
                config.renameAudioGroup("digits_initial_audio_group", "initial_audio_group");
                config.renameAudioGroup("digits_nomatch_audio_group", "nomatch_audio_group"); 
                config.renameAudioGroup("digits_noinput_audio_group", "noinput_audio_group"); 
                config.renameAudioGroup("digits_help_audio_group", "help_audio_group");
                
                ved.setScratchData("initializedPart1", new Boolean(true));
            }
            
            /* This is the magic sauce. The first line creates a new instance 
             * of the subelement. The second calls a method which executes the 
             * addXmlBody method in the subelement using the same "environment" 
             * as this superelement. This is done by passing all the same inputs 
             * as well as an instance of the superelement ("this"). Remember to 
             * call this method from the newly created subelement instance.*/ 
            MBasicDigit a = new MBasicDigit();
            result = a.createSubVoiceElement(this, vxml, reqParameters, ved);
            
            /* Since this subelement thought it was being executed normally, it 
            filled the VMain object with VoiceXML content and return a possible 
            exit state. These can then be analyzed by the superelement before 
            returning that information to Audium Call Services. */
            
            /* Let's analyze the exit state and see if the subelement is done. */
            returned = result.getExitState();
                
            if (returned == null) {
            
                /* In this case, the subelement is not done, so we set our 
                scratch to say we are in the first element and return null so 
                Audium Call Services can send to the voice browser the VoiceXML 
                page produced. */
                ved.setScratchData("insidePart1", new Boolean(true));
                return null;
            } else if (returned.compareTo("done") == 0) {
            
                /* The exit state returned is "done". Before we continue, we 
                must save the digits captured by this subelement in scratch 
                data because the Menu_Yes_No subelement also stores its result 
                in a variable named "value". Since all subelements share the 
                same namespace for element data, not doing this means the number 
                captured would be overwritten by the yes/no selection. Note that 
                when you get element data, you have to know the name of the 
                voice element. Here we call the method getCurrentVoiceElement, 
                which returns the name of this element. Remember, the subelement 
                has no name, it is essentially part of the single superelement. */
                ved.setScratchData("digits_value", ved.getElementData(ved.getCurrentElement(), "value"));
            } else {
            
                /* This occurs if the subelement returns an exit state that is 
                not done, i.e. "max_nomatch" or "max_noinput". In this case, we 
                simply return this exit state because the superelement also has 
                these exit states. */
                return returned;
            }
            
            /* If we get to this part, we are no longer inside the first 
            subelement, so we set the scratch data to be false. */
            ved.setScratchData("insidePart1", new Boolean(false));
            
            /* Now, we have to determine if the subelement created a VoiceXML 
            page at the same time as it returned a non-null exit state. If so, 
            we return null so Audium Call Services can send back the VoiceXML 
            page. When it comes back to this superelement, "insidePart1" will 
            be false and the "internal flow" will go to the next subelement. */
            boolean stuffInVMain = result.hasVxmlResponse();
            if (stuffInVMain) {
                return null;
            }
        }
        
        /* We are now potentially dealing with the second subelement. */
        Object insidePart2 = ved.getScratchData("insidePart2");
        if (insidePart2 == null || ((Boolean)insidePart2).booleanValue()) {
            System.out.println("We are going to visit the second subelement");

            VoiceElementConfig config = ved.getVoiceElementConfig();
            
            /* Again, we rename the settings and audio groups only the first 
            time we visit this subelement. */
            if (ved.getScratchData("initializedPart2") == null ) {
                
                /* Here, we need to set up the confidence setting. Note that we 
                don't want to lose the existing setting because it still applies 
                to the digit entry subelement which we can still visit if the 
                caller disconfirms. We therefore name it back to what it was 
                originally named for future use. */
                config.renameSetting("confidence_level", "digits_confidence_level"); 
                config.renameSetting("confirmation_confidence_level", "confidence_level"); 
                
                /* All the audio groups are also renamed (with the old values 
                named to their original values). */
                config.renameAudioGroup("initial_audio_group", "digits_initial_audio_group");
                config.renameAudioGroup("nomatch_audio_group", "digits_nomatch_audio_group"); 
                config.renameAudioGroup("noinput_audio_group", "digits_noinput_audio_group"); 
                config.renameAudioGroup("help_audio_group", "digits_help_audio_group");
                
                config.renameAudioGroup("confirm_initial_audio_group", "initial_audio_group");
                config.renameAudioGroup("confirm_nomatch_audio_group", "nomatch_audio_group"); 
                config.renameAudioGroup("confirm_noinput_audio_group", "noinput_audio_group"); 
                config.renameAudioGroup("confirm_help_audio_group", "help_audio_group");
                
                ved.setScratchData("initializedPart2", new Boolean(true));
            }
            
            /* Now that the inputs have all been prepared correctly, we can 
            instantiate the Menu_Yes_No subelement and call its main method. */
            MYesNoMenu b = new MYesNoMenu();
            result = b.createSubVoiceElement(this, vxml, reqParameters, ved);
            
            /* As before, if there is no exit state, we are inside the second 
            subelement. */
            returned = result.getExitState();
            if (returned == null) {
                ved.setScratchData("insidePart2", new Boolean(true));
                return null;
            }
            
            /* In order to allow Say It Smart playback during the confirmation 
            audio group element data named "value" must be created. If not done, 
            the value stored there will be the selection of the yes/no menu 
            (either "yes" or "no"). This line will overwrite that with the 
            digit value.*/
            ved.setElementData("value", (String)ved.getScratchData("digits_value"));
            
            /* As before, we are no longer in the second subelement. */
            ved.setScratchData("insidePart2", new Boolean(false));
            
            /* If the caller said "no" when asked to confirm the number, they 
            need to go back to the digit entry. Additionally, the superelement 
            needs to keep track of disconfirms so that when a limit is reached 
            (here its hardcoded to 3 though could easily be another setting), 
            the superelement exits with a max disconfirm exit state. The 
            disconfirm count is stored in scratch space. */
            if (returned.compareTo("no") == 0) {
                Object c = ved.getScratchData("disconfirm_count");
                int dcount;
                if (c == null) {
                    dcount = 1;
                } else {
                    dcount = ((Integer) c).intValue() +1;
                }
                if (dcount >= 3) {
                    return "max_disconfirm";
                }
                
                /* We now must go back to the digit entry. But we cannot simply 
                return null here because there will be no VoiceXML content to 
                send back to the voice browser and the voice browser will 
                encounter an error. Therefore, the digit entry subelement must 
                be visited again. This means renaming the settings and audio 
                groups as usual. What we also want to do is reset the scratch 
                space because you don't know what kinds of stuff were stored in 
                the scratch space by the subelements. Removing the scratch space 
                will ensure that everything can start from the beginning. There 
                is data,  however, that cannot be reset, namely the disconfirm 
                count. */
                
                ved.removeAllScratchData();
                ved.setScratchData("disconfirm_count", new Integer(dcount));
                
                config.renameSetting("confidence_level", "confirmation_confidence_level"); 
                config.renameAudioGroup("initial_audio_group", "confirm_initial_audio_group");
                config.renameAudioGroup("nomatch_audio_group", "confirm_nomatch_audio_group"); 
                config.renameAudioGroup("noinput_audio_group", "confirm_noinput_audio_group"); 
                config.renameAudioGroup("help_audio_group", "confirm_help_audio_group");
                
                config.renameSetting("digits_confidence_level", "confidence_level"); 
                config.renameAudioGroup("digits_initial_audio_group", "initial_audio_group");
                config.renameAudioGroup("digits_nomatch_audio_group", "nomatch_audio_group"); 
                config.renameAudioGroup("digits_noinput_audio_group", "noinput_audio_group"); 
                config.renameAudioGroup("digits_help_audio_group", "help_audio_group");
            
                /* Run the digit entry subelement again. In this case, we don't 
                need to worry about the exit state because if we return it here 
                the superelement will pick it up from there (since the 
                "insidePart1" scratch data is reset).*/
                MBasicDigit newDigit = new MBasicDigit();
                result = newDigit.createSubVoiceElement(this, vxml, reqParameters, ved);   
                return result.getExitState();
            } else if (returned.compareTo("yes") == 0) {
                
                /* If the caller said yes, they confirmed the captured digit 
                entry. We need to create element data to store this value so it 
                can be used by other elements. */
                ved.setElementData("value", (String)ved.getScratchData("digits_value"));
                return "done";
            } else {
                /* Again, this would be visited if a max nomatch or max noinput 
                event occurred so we simply return this to get our of the 
                superelement. */
                return returned;
            }
        }
        return null;
    }
}
