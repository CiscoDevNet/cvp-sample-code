This sample voice element demonstrates how one can construct a voice element by using existing elements as "subelements". The idea is to create a working voice element without having to write any VFC code. This element creates a voice element that mirrors the Digits_With_Confirm Audum element by assembling a "superelement" out of the Digits and Menu_Yes_No Audium elements.

Note that in order to compile this element, you need to add to the classpath an additional JAR file (along with the framework.jar file). This is the elements.jar file found in the Audium Call Services common/lib directory or the Audium Studio eclipse/plugins/com.audium.studio.elements.core_3.4.1/lib directory.

This is because this element utilizes Audium elements that the compiler would not be able to find without their definitions, which is encapsulated in elements.jar, being added to the classpath.

So, for example, if you are using the command-line javac function you would do the following (assuming Linux or Solaris):

Code:

javac -classpath=$AUDIUM_HOME/lib/framework.jar:$AUDIUM_HOME/common/lib/elements.jar NewDigitWithConfirm.java

or on Windows:
Code:

javac -classpath "%AUDIUM_HOME%\lib\framework.jar;%AUDIUM_HOME%\common\lib\elements.jar NewDigitWithConfirm.java 