package com.audiumcorp.support.elements.voiceElements;

import java.io.*;
import java.util.*;

import com.audium.core.vfc.VException;
import com.audium.core.vfc.VPreference;
import com.audium.core.vfc.audio.VAudio;
import com.audium.core.vfc.audio.VRecord;
import com.audium.core.vfc.form.VForm;
import com.audium.core.vfc.form.VBlock;
import com.audium.core.vfc.util.VAction;
import com.audium.core.vfc.util.VMain;
import com.audium.core.vfc.util.VProperty;
import com.audium.core.vfc.util.VEvent;
import com.audium.core.vfc.util.VIfGroup;
import com.audium.core.vfc.util.IfCondition;
import com.audium.server.session.VoiceElementData;
import com.audium.server.voiceElement.AudioGroup;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Dependency;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.VoiceElementBase;
import com.audium.server.xml.VoiceElementConfig;

/**
 * CLASS: EnhancedRecord.java
 * 
 * This voice element makes a recording of the caller's voice when prompted. The
 * caller may either hang up or enter a DTMF (if configured to terminate on
 * DTMF) to terminate the recording. It then saves the audio file to the
 * location specified in the configuration in the specified format.
 */

public class EnhancedRecord extends VoiceElementBase implements ElementInterface {
	private final static String FIELD_NAME = "VRecord";

	private static String DEFAULT_CONFIDENCE = "0.4";

	private static String DEFAULT_NOINPUT_TIMEOUT = "5s";


	/**
	 * This method returns the name of the voice element.
	 * 
	 * @return The name of the voice element which is "Record".
	 */
	public String getElementName() {
		return "EnhancedRecord";
	}

	/**
	 * This method returns the description of the voice element.
	 * 
	 * @return The description of the voice element.
	 */
	public String getDescription() {
		return "This voice element makes a recording of the caller's voice when prompted.  "
				+ "The caller may either hang up or enter a DTMF (if configured to terminate "
				+ "on DTMF) to terminate the recording.  It then saves the audio file to the location "
				+ "specified in the configuration in the specified format.";
	}

	public String getDisplayFolderName() {
		return "Audium Support";
	}

	/**
	 * This method returns a list of properties of the voice element.
	 * 
	 * @return An array of Setting objects, each containing one of the
	 *         properties used by the voice element.
	 */
	public Setting[] getSettings() throws ElementException {
		Setting[] settingArray = new Setting[13];

		settingArray[0] = new Setting(Setting.NOINPUT_TIMEOUT);
		settingArray[1] = new Setting(Setting.MAX_NOINPUT_COUNT);
		settingArray[2] = new Setting(
				"start_with_beep",
				"Start With Beep",
				"This setting indicates whether or not the caller should hear a beep before recording. Default = true.",
				true, true, true, Setting.BOOLEAN);
		settingArray[3] = new Setting(
				"terminate_on_dtmf",
				"Terminate On DTMF",
				"This setting indicates whether or not the caller can end the recording by pressing a key. Default = true.",
				true, true, true, Setting.BOOLEAN);
		settingArray[4] = new Setting(
				"max_record_time",
				"Max Record Time",
				"The maximum recording time allowed in seconds. Default = 180.",
				true, true, true, new Integer(0), null);
		settingArray[5] = new Setting(
				"final_silence",
				"Final Silence",
				"The interval of silence that indicates end of speech. Default = 4s.",
				true, true, true, Setting.STRING);
		settingArray[6] = new Setting(
				"filename",
				"Filename",
				"This is the name of the file that will hold the recording. If blank, one will be chosen for you.",
				false, true, true, Setting.STRING);
		settingArray[7] = new Setting(
				"file_type",
				"File Type",
				"This is the audio type of the file that will hold the recording. Default = wav",
				true, true, false, new String[] { "wav", "vox", "au", "other" });
		settingArray[8] = new Setting(
				"mime_type",
				"MIME Type",
				"This is the MIME type of the file that will hold the recording.",
				true, true, true, Setting.STRING);
		settingArray[9] = new Setting(
				"extension",
				"File Extension",
				"This specifies the file extension to use for the recorded file. A file extension different from the file type can be used. For example, with a mime type of vox, the file extension could be set to \"ulaw\".",
				false, true, true, Setting.STRING);
		settingArray[10] = new Setting(
				"path",
				"Path",
				"This is the path to the file that will hold the recording.",
				false, true, true, Setting.STRING);
		String[] choices = {"Exit", "Return"};
		settingArray[11] = new Setting(
				"hangup_action",
				"Hangup Action",
				"This settings determines what final action is taken if the recording is terminated with a hangup.",
				true, true, false, choices);
		settingArray[12] = new Setting(
				"return_data",
				"Return Data",
				"A variable name and value pair, separated by a colon (i.e. var1:hello) that will be returned when a hangup occurs.",
				false, false, true, Setting.STRING);
		
		// set setting defaults
		settingArray[0].setDefaultValue("5s");
		settingArray[1].setDefaultValue("3");
		settingArray[2].setDefaultValue("true");
		settingArray[3].setDefaultValue("true");
		settingArray[4].setDefaultValue("180");
		settingArray[5].setDefaultValue("4s");
		settingArray[7].setDefaultValue("wav");
		
		// create dependencies
		Dependency d1 = new Dependency(settingArray[7].getRealName(), "other",
				Dependency.EQUAL);
		Dependency[] depArray1 = { d1 };
		
		// MIME type should only appear if file type is "other"
		settingArray[8].setDependencies(depArray1);

		Dependency d2 = new Dependency(settingArray[11].getRealName(), "Return",
				Dependency.EQUAL);
		Dependency[] depArray2 = { d2 };
		
		// Return Data should only appear if Hangup Action is "Return"
		settingArray[12].setDependencies(depArray2);
		
		return settingArray;
	}

	public String[] getAudioGroupDisplayOrder() {

		String[] displayOrder = new String[1];

		displayOrder[0] = "Record Capture";

		return displayOrder;
	}

	public HashMap getAudioGroups() throws ElementException {

		HashMap groups = new HashMap(1);

		AudioGroup[] audioGroupArray = new AudioGroup[2];
		audioGroupArray[0] = new AudioGroup(AudioGroup.INITIAL);
		audioGroupArray[1] = new AudioGroup(AudioGroup.NOINPUT);

		groups.put("Record Capture", audioGroupArray);
		return groups;
	}

	/**
	 * This method returns a list of exit states of the voice element.
	 * 
	 * @return An array of ExitState objects, each containing one of the exit
	 *         states used by the voice element.
	 */
	public ExitState[] getExitStates() throws ElementException {
		ExitState[] exitStateArray = new ExitState[2];

		exitStateArray[0] = new ExitState(ExitState.DONE);
		exitStateArray[1] = new ExitState(ExitState.MAX_NOINPUT);
		
		return exitStateArray;
	}

	/**
	 * This method returns a list of public variables of the voice element.
	 * 
	 * @return An array of PublicVariable objects, each containing one of the
	 *         public variables used by the voice element.
	 */
	public ElementData[] getElementData() throws ElementException {
		ElementData[] elementDataArray = new ElementData[2];

		elementDataArray[0] = new ElementData(
				"filepath",
				"This public variable contains the full path of the file storing the caller's recording.");
		elementDataArray[1] = new ElementData(
				"filename",
				"This public variable contains the name of the file storing the caller's recording.");

		return elementDataArray;
	}

	/**
	 * This method handles the two parts of a recording, creating the VoiceXML
	 * content, and handling the result.
	 * 
	 * @param vxml
	 *            The VMain object in which to put all the VFCs.
	 * @param reqParameters
	 *            The input parameters.
	 * @param md
	 *            The VoiceElementData object containing the voice element's
	 *            configuration.
	 * @return The exit state of the voice element.
	 */
	public String addXmlBody(VMain vxml, Hashtable reqParameters,
			VoiceElementData md) throws VException, ElementException {

		VoiceElementConfig config = md.getVoiceElementConfig();

		// NOINPUT TIMEOUT
		VProperty prop = vxml.getProperties(); // get reference to VXML
		// properties
		String timeout = config.getSettingValue("noinput_timeout", md);
		if (timeout == null) {
			prop.add(VProperty.NOINPUT_TIMEOUT, DEFAULT_NOINPUT_TIMEOUT);
		} else {
			prop.add(VProperty.NOINPUT_TIMEOUT, timeout);
		}

		//returns the max noinput state
		if (reqParameters.get("maxNoInput") != null) {
			return "max_noinput";
		}

		// get the recording itself (if present)
		String value = (String) reqParameters.get(FIELD_NAME);
		// get the type of hangup that occured (if any)
		String hanguptype = (String) reqParameters.get("hanguptype");
		
		// if we don't have the recording or a hangup, then we need to produce VoiceXML
		if (value == null && hanguptype == null) {
			record(vxml, md);
			return null;
		} else if (value != null) { // we have the recording, save it
			//	get the recording variables
			String duration = (String) reqParameters.get("duration");
			String size = (String) reqParameters.get("size");
			String termchar = (String) reqParameters.get("termchar");
			String maxtime = (String) reqParameters.get("maxtime");

			//save the recording variables in element data
			if ((duration != null) && (!(duration.equals("undefined")))) {
				md.setElementData("duration", duration,
						VoiceElementData.PD_INT, true);
			}
			if ((size != null) && (!(size.equals("undefined")))) {
				md.setElementData("size", size, VoiceElementData.PD_INT, true);
			}
			if ((termchar != null) && (!(termchar.equals("undefined")))) {
				md.setElementData("termchar", termchar,
						VoiceElementData.PD_STRING, true);
			}
			if ((maxtime != null) && (!(maxtime.equals("undefined")))) {
				md.setElementData("maxtime", maxtime,
						VoiceElementData.PD_BOOLEAN, true);
			}
			saveRecording(value, md);
		}
		
		// did the user hangup?
		if (hanguptype != null) {
			// check value of Hangup Action setting
			if (config.getSettingValue("hangup_action", md).equals("Exit"))	{
				// if Hangup Action setting is Exit, produce VoiceXML which throws an event
				// that the root document will catch (which causes the root doc to generate an <exit/>)

				// setup a form element, and a block that it will contain
				VPreference pref = md.getPreference();
				VForm start = VForm.getNew(pref, "start");
				VBlock block = VBlock.getNew(pref);
				
				// setup a VAction that will throw com.audium.disconnect
				// NOTE: this event will be caught by the root document at runtime,
				// allowing normal handling of the hang up
				VAction throwAction = VAction.getNew(pref);
				throwAction.add(VAction.THROW, "com.audium.disconnect");
				block.add(throwAction);
				
				// add the block to the form
				start.add(block);
				// add the form to the VoiceXML container
				vxml.add(start);	
			} else if (config.getSettingValue("hangup_action", md).equals("Return")) {
				// Hangup Action setting is Return, return the values specified
				// in Return Data (repeatable) settings.
				
				// setup a form element, and a block it will contain
				VPreference pref = md.getPreference();
				VForm start = VForm.getNew(pref, "start");
				VBlock block = VBlock.getNew(pref);
				
				// initialize the list of variable names to return
				String returnString = "";
				
				// find any Return Data settings that were configured
				String[] returnDataArray = config.getSettingValues("return_data", md);
				
				// if at least one Return Data setting has been configured...
				if (returnDataArray.length > 0)
				{
					VAction variableDeclarations = null;
					
					// go through each variable name/value pair, add the name to the returnString, and add the pair to
					// a VAction that will declare the variable at runtime (so that the value exists to be returned)
					for (int i = 0; i < returnDataArray.length; i++)
					{
						// nameValuePair, where name and value are separated by a colon (:)
						String nameValuePair = returnDataArray[i];
					    StringTokenizer st = new StringTokenizer(nameValuePair);
						
						// extract the variable name
					    String varName = "";
						try
						{
							varName = st.nextToken(":");							
						}
						catch (NoSuchElementException nsee)
						{
							nsee.printStackTrace();
							throw new ElementException("EnhancedRecord element has a Return Data setting that is not properly delimited by a colon.");
						}
						
						// extract the value of the variable
						String varValue = "";
						try
						{
							varValue = st.nextToken(":");							
						}
						catch (NoSuchElementException nsee)
						{
							nsee.printStackTrace();
							throw new ElementException("EnhancedRecord element has a Return Data setting that is not properly delimited by a colon.");
						}
						
						// if this is the first variable we're adding, we need to first create the container
						if (variableDeclarations == null)
							variableDeclarations = VAction.getNew(pref, VAction.VARIABLE, varName, varValue, VAction.WITH_QUOTES);													
						else // container already exists, just add the variable
							variableDeclarations.add(VAction.VARIABLE, varName, varValue, VAction.WITH_QUOTES);
						
						// add the name of this variable to the return string
						if (returnString.length() == 0)
							returnString = varName;
						else
							returnString += (" " + varName); 
					}
					
					// add the variable declarations to the block
					block.add(variableDeclarations);
				}
				// add the return string to the block (note that it will be an empty string if no Return Data settings were found)
				block.add(VAction.getNew(pref, VAction.RETURN, returnString));
				// add the block to the form
				start.add(block);
				// add the form to the VoiceXML container
				vxml.add(start);

				// invalidate the session, the call is over
				md.invalidateSession(false);	
			}			
			// return null because we generated VoiceXML
			return null; 			
		}

		// user did not hang up to terminate recording, we can continue
		return "done";
	}

	/**
	 * Creates a unique filename for the recording.
	 * 
	 * @return The unique filename.
	 */
	private String getUniqueName() {
		return "audio" + new Date().getTime();
	}

	/**
	 * Saves the recording to a file.
	 * 
	 * @param value
	 *            This is the string containing the contents of the recording.
	 * @param md
	 *            This contains the VoiceElementData object with the
	 *            configuration.
	 */
	private void saveRecording(String value, VoiceElementData md)
			throws ElementException {
		VoiceElementConfig config = md.getVoiceElementConfig();

		// Create our own filename if the user did not specify one of his own.
		String fileName = config.getSettingValue("filename", md);
		if (fileName == null || "".equals(fileName.trim())) {
			fileName = getUniqueName();
		}

		// Figure out the file extension: file type in most cases. If file type
		// is "other", use the extension setting.
		String extension = config.getSettingValue("extension", md);
		String fileType = config.getSettingValue("file_type", md);

		if (extension == null || "".equals(extension.trim())) {
			// Figure out if the fileName already contains an extension
			String endsWith = null;
			int index = fileName.lastIndexOf(".");
			if (index >= 0) {
				endsWith = fileName.substring(index);
			}

			// Add the proper extension if the fileName doesn't already contain
			// one
			if ("wav".equals(fileType) && !".wav".equalsIgnoreCase(endsWith)) {
				fileName += ".wav";
			} else if ("vox".equals(fileType)
					&& !".vox".equalsIgnoreCase(endsWith)) {
				fileName += ".vox";
			} else if ("au".equals(fileType)
					&& !".au".equalsIgnoreCase(endsWith)) {
				fileName += ".au";
			}
		} else {
			// Remove starting dot from extension
			if (extension.startsWith(".")) {
				extension = extension.substring(1);
			}

			// Add extension
			fileName += ("." + extension);
		}

		// Set file name as element data
		md.setElementData("filename", fileName, VoiceElementData.PD_STRING,
				true);

		// Get the path specified (if given) and save the local file.
		String path = config.getSettingValue("path", md);
		if (path != null) {
			// Throw an error if the path is not a directory.
			File thePath = new File(path);
			if (!thePath.isDirectory()) {
				throw new ElementException("The path given for recording, "
						+ path + ", is not a directory.");
			}

			String completeFileName = saveToFile(path, fileName, value, md);

			md.setElementData("filepath", completeFileName,
					VoiceElementData.PD_STRING, true);
		}
	}

	/**
	 * This method saves the recording to a local file.
	 * 
	 * @param path
	 *            The path in which to store the recording.
	 * @param filename
	 *            The filename to give it.
	 * @param value
	 *            This is the string containing the contents of the recording.
	 * @return The full filename (including path) of the saved file.
	 */
	private String saveToFile(String path, String filename, String value,
			VoiceElementData md) throws ElementException {
		// Throw an error if the path is not a directory.
		File thePath = new File(path);
		if (!thePath.isDirectory()) {
			throw new ElementException("The path given for recording, " + path
					+ ", is not a directory.");
		}

		VPreference pref = md.getPreference();
		String currentElement = md.getCurrentElement();

		String completeFileName;
		try {
			completeFileName = thePath.getCanonicalPath() + File.separator
					+ filename;
			File file = new File(completeFileName);
			file.createNewFile();

			byte[] valueAsBytes = null;
			try {
				valueAsBytes = value.getBytes("ISO-8859-1");
			} catch (UnsupportedEncodingException e) {
				throw new ElementException(
						"There was a problem writing the recording to a file for "
								+ currentElement
								+ "voice element.  The correct"
								+ "encoding type, ISO-8859-1, is not supported by this system.");
			}

			ByteArrayInputStream in = new ByteArrayInputStream(valueAsBytes);
			FileOutputStream out = new FileOutputStream(file);
			byte[] buffer = new byte[1024];

			while (true) {
				int bytes_read = in.read(buffer);
				if (bytes_read == -1)
					break;
				out.write(buffer, 0, bytes_read);
				out.flush();
			}
			in.close();
			out.close();
		} catch (IOException ioe) {
			throw new ElementException(ioe);
		}
		return completeFileName;
	}

	/**
	 * This generates the vxml for the recording form.
	 * 
	 * @param vxml
	 *            The VMain object in which to put all the VFCs.
	 * @param md
	 *            The VoiceElementData object containing the voice element's
	 *            configuration.
	 */
	private void record(VMain vxml, VoiceElementData md) throws VException,
			ElementException {

		VoiceElementConfig config = md.getVoiceElementConfig();
		VPreference pref = md.getPreference();

		// create a new form named "start"
		VForm form = VForm.getNew(pref, "start");

		// default - beep indicates the start of the recording
		boolean startWithBeep = true;
		String tempStart = config.getSettingValue("start_with_beep", md);
		if ((tempStart != null) && (tempStart.equalsIgnoreCase("false"))) {
			startWithBeep = false;
		}

		boolean terminateOnDtmf = true;// default - dtmf key press indicates the
		// termination of recording.
		String tempTerminate = config.getSettingValue("terminate_on_dtmf", md);
		if ((tempTerminate != null)
				&& (tempTerminate.equalsIgnoreCase("false"))) {
			terminateOnDtmf = false;
		}

		int recordTimeOut = config.getIntSettingValue("max_record_time", 180,
				md);
		String str = config.getSettingValue("max_record_time", md);
		if (str == null) {
			recordTimeOut = config.getIntSettingValue("duration", 180, md);
		}

		// add min confidence to vxml properties
		VProperty prop = vxml.getProperties();
		prop.add(VProperty.CONFIDENCE, DEFAULT_CONFIDENCE);

		VRecord record = null;

		// instantiate a record element (different settings based on file type)
		String fileType = config.getSettingValue("file_type", md);
		if ("wav".equals(fileType)) {
			record = VRecord.getNew(pref, FIELD_NAME, recordTimeOut,
					VRecord.WAV, startWithBeep, terminateOnDtmf);
		} else if ("vox".equals(fileType)) {
			record = VRecord.getNew(pref, FIELD_NAME, recordTimeOut,
					VRecord.VOX, startWithBeep, terminateOnDtmf);
		} else if ("au".equals(fileType)) {
			record = VRecord.getNew(pref, FIELD_NAME, recordTimeOut,
					VRecord.AU, startWithBeep, terminateOnDtmf);
		} else {
			String mimeType = config.getSettingValue("mime_type", md);
			record = VRecord.getNew(pref, FIELD_NAME, recordTimeOut, mimeType,
					startWithBeep, terminateOnDtmf);
		}

		record.setSubmitThis(false);

		VoiceElementConfig.AudioGroup initialAG = config.getAudioGroup(
				"initial_audio_group", 1);
		if (initialAG != null) {
			// Logs initial prompt
			VAction logAction = VAction.getNew(pref, VAction.ASSIGN,
					VXML_LOG_VARIABLE_NAME, VXML_LOG_VARIABLE_NAME
							+ " + '|||audio_group$$$" + getElementName()
							+ "_initial_audio_group"
							+ "^^^' + application.getElapsedTime("
							+ ELEMENT_START_TIME_MILLISECS + ")",
					VAction.WITHOUT_QUOTES);
			VBlock block = VBlock.getNew(pref);
			logAction.add(VAction.FIELD, FIELD_NAME);
			block.add(logAction);
			form.add(block);

			record.setPromptCount(1, initialAG.constructAudio(md));
		} else {
			throw new ElementException(
					"The initial_audio_group is required for "
							+ md.getCurrentElement() + " voice element.");
		}

		int terminationSilence = 4;
		String silenceStr = config.getSettingValue("final_silence", md);
		if (silenceStr != null) {
			int tmpIndex = silenceStr.indexOf("s");
			if (tmpIndex > -1) {
				silenceStr = silenceStr.substring(0, tmpIndex);
			}
			terminationSilence = Integer.parseInt(silenceStr);
		}
		record.setTerminationSilence(terminationSilence);

		VEvent noinputEvent = VEvent.getNew(pref, VEvent.NOINPUT);
		VAudio audioEvent = null;
		VAction logEvent = null;

		for (int i = 1; i <= config.getIntSettingValue("max_noinput_count", md); i++) {
			VoiceElementConfig.AudioGroup _audioGroup = md
					.getVoiceElementConfig().getAudioGroup(
							"noinput_audio_group", i);

			if (_audioGroup != null) {
				audioEvent = _audioGroup.constructAudio(md);
			}

			//add the noinput count to the log file
			logEvent = VAction.getNew(pref, VAction.ASSIGN,
					VXML_LOG_VARIABLE_NAME, VXML_LOG_VARIABLE_NAME + " + '|||"
							+ getElementName() + "_noinput$$$' + '" + i
							+ "' + '^^^' + application.getElapsedTime("
							+ ELEMENT_START_TIME_MILLISECS + ")",
					VAction.WITHOUT_QUOTES);

			noinputEvent.addCount(i);
			noinputEvent.addItem(i, audioEvent);
			noinputEvent.addItem(i, logEvent);

			//add audio played to the log file
			logEvent = VAction.getNew(pref, VAction.ASSIGN,
					VXML_LOG_VARIABLE_NAME, VXML_LOG_VARIABLE_NAME
							+ " + '|||audio_group$$$" + getElementName()
							+ "_noinput_audio_group"
							+ "^^^' + application.getElapsedTime("
							+ ELEMENT_START_TIME_MILLISECS + ")",
					VAction.WITHOUT_QUOTES);

			noinputEvent.addItem(i, logEvent);
			noinputEvent.setReprompt(i, (audioEvent == null));
		}
		//adding noinput and submit maxNoInput events to the vxml
		VAction submitAction = VAction.getNew(pref, VAction.VARIABLE,
				"maxNoInput", "yes", VAction.WITH_QUOTES);
		submitAction
				.add(getSubmitURL(), VXML_LOG_VARIABLE_NAME + " maxNoInput");

		noinputEvent.addItem(noinputEvent.getMaxCount(), submitAction);
		record.add(noinputEvent);

		//	adds all the shadow variables for recording
		VAction action = VAction.getNew(pref, VAction.VARIABLE, "duration",
				FIELD_NAME + "$.duration", VAction.WITHOUT_QUOTES);
		action.add(VAction.VARIABLE, "size", FIELD_NAME + "$.size",
				VAction.WITHOUT_QUOTES);
		action.add(VAction.VARIABLE, "termchar", FIELD_NAME + "$.termchar",
				VAction.WITHOUT_QUOTES);
		action.add(VAction.VARIABLE, "maxtime", FIELD_NAME + "$.maxtime",
				VAction.WITHOUT_QUOTES);
		record.add(action);

		/*
		 * We are adding VRecord here because we turned off including this in
		 * the submit argument list since it would end up in error submits,
		 * which is unncessary.
		 */
		VAction submitAction2 = getSubmitVAction(
				"VRecord duration size termchar maxtime", pref);
		submitAction2.setEncoding("multipart/form-data");
		record.add(submitAction2); // add the normal submit action

		/*
		 * This bit of code catches a hangup event, and performs a submit which
		 * has all of the same variables as the submit above, but also includes
		 * a variable named hanguptype that tells the addXmlBody() method that
		 * a hangup occured.
		 */
		// create listener for a connection hangup
		VEvent hangupSubmitEvent1 = VEvent.getNew(pref,
				"connection.disconnect.hangup");
		// there is only one count for this event (never happens more than once in a call)
		hangupSubmitEvent1.addCount(1);
		// create an action that will store hanguptype = connection
		VAction wasConnectionHangup = VAction.getNew(pref, VAction.VARIABLE,
				"hanguptype", "connection", VAction.WITH_QUOTES);
		// add the action (that declares hanguptype) to the listener
		hangupSubmitEvent1.addItem(1, wasConnectionHangup);		
		// add an if-statement to this catch, to ensure that the recording has actually
		// been received.  if not, we may be outside the record VoiceXML element, but the
		// catch has been loaded because of voice browser caching behavior.  if the
		// recording has no value, just submit the log and hangup type instead
		VIfGroup ifGroup = VIfGroup.getNew(pref);
		VAction submitWithoutRecording = getSubmitVAction("hanguptype", pref);
		submitWithoutRecording.setEncoding("multipart/form-data");		
		ifGroup.add(new IfCondition(FIELD_NAME, IfCondition.VALUE, IfCondition.EQUALS, 
				"undefined", IfCondition.WITHOUT_QUOTES), null, submitWithoutRecording);
		hangupSubmitEvent1.addItem(1, ifGroup);		
		// declare the same variables the normal submit requires
		hangupSubmitEvent1.addItem(1, action);
		// add a log entry
		VAction log1 = VAction.getNew(pref, VAction.ASSIGN,
				VXML_LOG_VARIABLE_NAME, VXML_LOG_VARIABLE_NAME + " + '|||"
						+ getElementName() + "_terminated_by_hangup$$$' + '" 
						+ "connection.disconnect.hangup"
						+ "' + '^^^' + application.getElapsedTime("
						+ ELEMENT_START_TIME_MILLISECS + ")",
						VAction.WITHOUT_QUOTES);				
		// create an action to perform the submit, includes hanguptype variable
		VAction submitActionConnectionHangup = getSubmitVAction(
				"VRecord duration size termchar maxtime hanguptype", pref);
		submitActionConnectionHangup.setEncoding("multipart/form-data");
		// add the log action to the listener
		hangupSubmitEvent1.addItem(1, log1);
		// add the submit action to the listener
		hangupSubmitEvent1.addItem(1, submitActionConnectionHangup);
		// this event should not result in a reprompt, since the call has ended
		hangupSubmitEvent1.setReprompt(1, false);
		
		// some browsers throw this event instead, should also end the recording
		// create listener for a connection hangup
		VEvent hangupSubmitEvent2 = VEvent.getNew(pref,
				"telephone.disconnect.hangup");
		// there is only one count for this event (never happens more than once in a call)
		hangupSubmitEvent2.addCount(1);	
		// create an action that will store hanguptype = telephone
		VAction wasTelephoneHangup = VAction.getNew(pref, VAction.VARIABLE,
				"hanguptype", "telephone", VAction.WITH_QUOTES);
		// add the action (that declares hanguptype) to the listener
		hangupSubmitEvent2.addItem(1, wasTelephoneHangup);		
		// add the same if-statement to this catch (as from the last catch), for 
		// the case where the recording hasn't been captured yet
		hangupSubmitEvent2.addItem(1, ifGroup);		
		// declare the same variables the normal submit requires
		hangupSubmitEvent2.addItem(1, action);
		VAction log2 = VAction.getNew(pref, VAction.ASSIGN,
				VXML_LOG_VARIABLE_NAME, VXML_LOG_VARIABLE_NAME + " + '|||"
						+ getElementName() + "_terminated_by_hangup$$$' + '" 
						+ "telephone.disconnect.hangup"
						+ "' + '^^^' + application.getElapsedTime("
						+ ELEMENT_START_TIME_MILLISECS + ")",
						VAction.WITHOUT_QUOTES);			
		// create an action to perform the submit, includes hanguptype variable
		VAction submitActionTelephoneHangup = getSubmitVAction(
				"VRecord duration size termchar maxtime hanguptype", pref);
		submitActionConnectionHangup.setEncoding("multipart/form-data");
		// add the log action to the listener
		hangupSubmitEvent2.addItem(1, log2);
		// add the submit action to the listener
		hangupSubmitEvent2.addItem(1, submitActionConnectionHangup);
		// this event should not result in a reprompt, since the call has ended
		hangupSubmitEvent2.setReprompt(1, false);
		
		// add the hangup-driven submits to the record element
		record.add(hangupSubmitEvent1);
		record.add(hangupSubmitEvent2);
		
		form.add(record); // add the record element to the form
		vxml.add(form); // add the form to the voicexml document
	}
}
