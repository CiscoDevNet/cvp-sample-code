This sample element includes the ability to terminate and save a recording with a hang up (in addition to the normal methods of DTMF-entry or waiting for a certain amount of silence).

This element has been tested using the "SpeechWorks OSB 1.2 with OSR 1.0/1.1" and "Cisco CVP 3.0 for DTMF Only" gateway adapters, and is considered beta software. Use on other adapters may require modifications to the provided source; testing should be performed to ensure compatibility, use the element at your own risk.

An element specification has been provided, please find the .pdf attached to this post. It follows the same format as the official Element Specifications.

To use this element in a single Audium application:

Copy EnhancedRecord.jar into that application's deploy/java/application/lib directory in Audium Builder for Studio, and then close and reopen the call flow for that application. The new element will be listed in the "Local Elements/Audium Support" folder, in the Elements pane. The jar file for EnhancedRecord will automatically be deployed when the Audium application is deployed.

To install this element for use in any application:

Copy EnhancedRecord.jar into the eclipse/plugins/com.audium.studio.common_3.4.1/lib directory (under Audium Studio's directory). Then, exit and restart Audium Studio. The new element will be listed in the "Audium Support" folder, in the Elements pane. Additionally, any installation of Audium Call Services that will be used to execute an application that includes this element should have EnhancedRecord.jar copied into its AUDIUM_HOME/common/lib directory.

For additional details about deploying custom elements, please refer to Chapter 2 of the Programmer Guide.

UPDATED 7/27/05: New versions of the source, documentation, and JAR file have been attached. This new version includes support for use in an application that is called as a subdialog, and does away with the "record_ended_with_hangup" exit state. Please refer to the attached element specification for details, but here are some brief notes:

If your application is not called as a subdialog:

Set the "Hangup Action" setting to "Exit". When a hang up terminates a recording, an event will be thrown that causes the application's root document to handle the hang up normally.

If your application is called as a subdialog:

Set the "Hangup Action" setting to "Return". A repeatable "Return Data" setting will appear, which you should then configure to return any data that the calling document is expecting. The value of "Return Data" settings should be a colon-delimited string of a variable name/value pair (e.g. "choice1:marketing"), and may include substitution.

UPDATED 7/28/05: New version of the source and JAR file have been attached. The element specification PDF has not changed. This new version is to fix an issue related to voice browser caching causing hung sessions. This new version has been confirmed to work (and not leave hung sessions) with both "SpeechWorks OSB 1.2 with OSR 1.0/1.1" and "Cisco CVP 3.0 for DTMF Only" gateway adapters. 