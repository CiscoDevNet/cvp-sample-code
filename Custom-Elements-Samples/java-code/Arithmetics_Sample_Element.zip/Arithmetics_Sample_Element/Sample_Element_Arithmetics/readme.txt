This sample element allows for simple arithmetic operations to be executed as part of the callflow, storing the result in element data. It includes support for addition, subtraction, division, and multiplication.

This element is considered beta software. Use with a particular gateway adapter may require modifications to the provided source; testing should be performed to ensure compatibility, use the element at your own risk.

An element specification has been provided, please find the .pdf attached to this post. It follows the same format as the official Element Specifications.

To use this element in a single Audium application:

Copy Arithmetics.jar into that application's deploy/java/application/lib directory in Audium Builder for Studio, and then close and reopen the call flow for that application. The new element will be listed in the "Local Elements/Audium Support" folder, in the Elements pane. The JAR file for Arithmetics will automatically be deployed when the Audium application is deployed.

To install this element for use in any application:

Copy Arithmetics.jar into the eclipse/plugins/com.audium.studio.common_3.4.1/lib directory (under Audium Studio's directory). Then, exit and restart Audium Studio. The new element will be listed in the "Audium Support" folder, in the Elements pane. Additionally, any installation of Audium Call Services that will be used to execute an application that includes this element should have Arithmetics.jar copied into its AUDIUM_HOME/common/lib directory.

For additional details about deploying custom elements, please refer to Chapter 2 of the Programmer Guide. 