package com.audiumcorp.support.elements.actionElements;

import com.audium.server.session.ActionElementData;
import com.audium.server.voiceElement.ActionElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.xml.ActionElementConfig;

/**
 * CLASS: Arithmetics.java
 * 
 * This Action element takes several operands and performs an operation on them,
 * storing the result in element data. For example, if this element is
 * configured with a first operand of "1", a next operand of "2", and an
 * operation of "addition", then the result "3" will be stored in element data
 * under the variable "value". Note that this element does not support mixing
 * different operations in one calculation (e.g. 1 + 2 - 3 is not supported,
 * whereas 1 * 2 * 3 is).  If mixed operations are needed, several Arithmetics 
 * elements can be used in succession. The "Next Operand" setting is repeatable to 
 * allow more than 2 operands.
 * 
 * If an error condition is caught (i.e. a non-integer operand, or an attempted division
 * by zero), the custom utility method hadError() is called to log the problem and set 
 * the "value" to "0" before returning.  However, it is a best practice to catch these 
 * problems at a higher level, so that the call can be handled gracefully.
 */

public class Arithmetics extends ActionElementBase implements ElementInterface {
	/**
	 * This is the name of the sample Action element, which appears in the
	 * Audium Builder.
	 */
	public final String getElementName() {
		return "Arithmetics";
	}

	/**
	 * This is the name of the folder in the Audium Builder in which this sample
	 * Action element appears.
	 */
	public final String getDisplayFolderName() {
		return "Audium Support";
	}

	/**
	 * This is the description of what this Action element does.
	 */
	public final String getDescription() {
		return "This sample Action element performs basic arithmetic functions.";
	}

	/**
	 * This returns the settings used by this sample Action element.
	 */
	public final Setting[] getSettings() throws ElementException {
		Setting[] settingArray = new Setting[3];

		// The first operand
		settingArray[0] = new Setting("first_operand", "First Operand",
				"The first operand, for example 1 in the equation 1 + 2 = x.",
				true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.INT);
		settingArray[0].setDefaultValue("0");

		// The operation to be performed on the operands
		settingArray[1] = new Setting(
				"operation",
				"Operation",
				"The operation to be performed on the operands, for example addition in the equation 1 + 2 = x.",
				true, // It is required
				true, // It appears only once
				false, // It does not allow substitution
				new String[] {"addition", "subtraction", "multiplication", "division"});
		settingArray[1].setDefaultValue("addition");

		// The next operand(s)
		settingArray[2] = new Setting(
				"next_operand",
				"Next Operand",
				"The next operand, for example 2 in the equation 1 + 2 = x.  This setting is repeatable, for equations such as 10 - 3 - 2 = x where both 3 and 2 are the next operands.",
				true, // It is required
				false, // It can appear multiple times
				true, // It allows substitution
				Setting.INT);
		settingArray[2].setDefaultValue("0");

		return settingArray;
	}

	/**
	 * This method returns an array of ElementData objects representing the
	 * Element Data that this Action element creates.
	 */
	public final ElementData[] getElementData() throws ElementException {
		ElementData[] elementDataArray = new ElementData[1];

		elementDataArray[0] = new ElementData("value",
				"The result of performing the operation on the operands.");

		return elementDataArray;
	}

	/**
	 * This method performs the action. It gets the configuration settings, and
	 * then performs the appropriate operation depending on the settings. The
	 * result is stored in element data and in the activity log.
	 */
	public final void doAction(String name, ActionElementData actionData)
			throws ElementException {

		// Get a reference to the configuration
		ActionElementConfig config = actionData.getActionElementConfig();

		// Get the first operand
		int firstOperand;
		try {
			firstOperand = Integer.parseInt(config.getSettingValue(
					"first_operand", actionData));
		} catch (NumberFormatException nfe) {
			// If we get here, operand might have had non-digit characters,
			// or too many digits, etc.
			hadError(actionData, "The first operand was not an integer.  "
					+ "First operand: "
					+ config.getSettingValue("first_operand", actionData) + ".");
			return;
		}

		// Get the operation
		String operation = config.getSettingValue("operation", actionData);

		// Get an array of the "next" operands (i.e. operands that follow the
		// first operand)
		String[] nextOperands = config.getSettingValues("next_operand",
				actionData);

		int nextOperand;
		int result = firstOperand; // Start with the value of the first operand

		// Perform the operation, using the result so far and the next operand
		// as operands
		for (int i = 0; i < nextOperands.length; i++) {
			// Get the next operand
			try {
				nextOperand = Integer.parseInt(nextOperands[i]);
			} catch (NumberFormatException nfe) {
				// If we get here, operand might have had non-digit characters,
				// or too many digits, etc.
				hadError(actionData, "A next operand was not an integer.  "
						+ "Next operand: " + nextOperands[i] + ".");
				return;
			}

			// Depending on the operation chosen, perform various calculations
			if (operation.equals("addition")) {
				result += nextOperand;
			} else if (operation.equals("subtraction")) {
				result -= nextOperand;
			} else if (operation.equals("multiplication")) {
				result *= nextOperand;
			} else if (operation.equals("division")) {
				// Detect attempted division by zero, so that the Audium
				// application can continue without throwing an exception.
				if (nextOperand != 0) {
					result /= nextOperand;
				} else {
					hadError(actionData, "Attempted division by zero.");
					return;
				}
			}
		}
		// Create element data named "value" and store the result there
		actionData.setElementData("value", "" + result);

		// Log the result
		actionData.addToLog("result", "" + result);
	}

	// A utility method that logs an error message, and sets the element
	// data named "value" to 0
	private void hadError(ActionElementData aed, String message)
			throws ElementException {
		aed.addToLog("error", message);
		aed.setElementData("value", "0");
	}
}