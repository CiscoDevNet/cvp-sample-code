This project contains simple sample element and Say It Smart code. These classes appear in other posts as just the raw Java files, this simply wraps an Audium project around them. The project contains the following Java classes:

ActionElementExample.java
ConfigurationExample.java
DecisionElementExample.java
DualAudioVoiceElement.java
SpellingSayItSmart.java
VFCExamples1.java
VFCExamples2.java 