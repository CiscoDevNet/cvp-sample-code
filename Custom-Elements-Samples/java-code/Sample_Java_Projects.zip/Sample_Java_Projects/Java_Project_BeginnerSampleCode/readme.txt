This project contains Java templates for all situations where Java can be used to extend Audium. These templates provide stub code that sets up the component correctly, allowing the developer to simply enter their own code without having to worry about importing the correct Audium classes, defining the appropriate methods, etc.

Templates are given for:

# Configurable action, decision, and voice elements
# Standard action and decision elements
# On call start and call end classes
# Dynamic action, decision, and voice element configurations
# NEW 9/29/05: On error notification, hotevent