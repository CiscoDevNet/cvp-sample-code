// These classes are used by on call start classes.
import com.audium.server.AudiumException;
import com.audium.server.proxy.StartCallInterface;
import com.audium.server.session.CallStartAPI;

/**
 * The On Start Call Class is called when a call is first received before the 
 * call flow begins.
 */
public class MyCallStart implements StartCallInterface
{
    /**
     * All On Start Call classes must implement this method.  This method will
     * be called at the beginning of the call. You can set session data here
     * that can be used throughout the call.
     */
    public void onStartCall(CallStartAPI callStartAPI) throws AudiumException
    {
		// PUT YOUR CODE HERE.
    }
}
