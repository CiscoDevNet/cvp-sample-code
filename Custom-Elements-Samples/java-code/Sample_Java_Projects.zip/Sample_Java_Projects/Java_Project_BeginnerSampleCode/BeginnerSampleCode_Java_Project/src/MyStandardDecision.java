// These classes are used by standard decision elements.
import com.audium.server.AudiumException;
import com.audium.server.voiceElement.DecisionElementBase;
import com.audium.server.session.DecisionElementData;

/**
 * This class is called when a standard decision has been configured to use a 
 * Java class. Since this is a standard decision element, it applies to a 
 * specific application and does not have a configuration. As a result, the 
 * only method needed in this class is the doDecision method.
 */
public class MyStandardDecision extends DecisionElementBase
{
    /**
     * All decision classes must implement this method. The data is retreived 
     * through the DecisionElementData class and the result of the decision is 
     * returned as a String from the method.
     */
    public String doDecision(String name, DecisionElementData data) throws AudiumException
    {
		// PUT YOUR CODE HERE.
		
		// Return the appropriate exit state.
        return "";
    }
}
