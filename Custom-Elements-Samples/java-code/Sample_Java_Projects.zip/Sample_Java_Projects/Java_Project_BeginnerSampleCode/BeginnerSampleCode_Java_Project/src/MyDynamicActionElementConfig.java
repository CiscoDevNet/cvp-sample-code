// These classes are used by dynamic action element configurations.
import com.audium.server.AudiumException;
import com.audium.server.proxy.ActionConfigInterface;
import com.audium.server.session.ActionAPI;
import com.audium.server.xml.ActionElementConfig;

/**
 * This class would be called if the action element configuration is to be 
 * dynamically generated.
 */
public class MyDynamicActionElementConfig implements ActionConfigInterface
{
	/**
	 * This method is expected to assemble the completed action element 
	 * configuration. It receives the base configuration created by Audium 
	 * Builder for Studio which this method can edit to represent the desired 
	 * configuration. If no base configuration is defined in the Builder, the 
	 * third argument to the method is null. ActionAPI is used to interface 
	 * with the system such as creating variables.
	 */
    public ActionElementConfig getConfig(String name, 
                                    	 ActionAPI actionAPI, 
                                    	 ActionElementConfig defaults) throws AudiumException
    {
		// PUT YOUR CODE HERE.
		
		// Alter defaults or create a new configuration and return.
        return defaults;
    }
}
