// These classes are used by on call end classes.
import com.audium.server.AudiumException;
import com.audium.server.proxy.EndCallInterface;
import com.audium.server.session.CallEndAPI;

/** 
 * The On End Call Class is called if the caller hung up, the application hung
 * up on the caller, the application was transferred to another application, a
 * blind telephony transfer took place, the session was manually invalidated by
 * an element, or the sesion timed out on its own (due to some error). 
 */
public class MyCallEnd implements EndCallInterface
{
    /**
     * All On End Call classes must implement this method. Use the passed 
     * CallEndAPI class to get useful information. Making changes here will do 
     * nothing as the call has already ended.
     */
    public void onEndCall(CallEndAPI callEndAPI) throws AudiumException
    {
		// PUT YOUR CODE HERE.
    }
}
