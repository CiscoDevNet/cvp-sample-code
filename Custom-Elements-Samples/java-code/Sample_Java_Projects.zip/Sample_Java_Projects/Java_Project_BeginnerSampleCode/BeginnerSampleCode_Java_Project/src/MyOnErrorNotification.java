// These classes are used by On Error Notification classes.
import java.util.ArrayList;
import java.util.HashMap;
import com.audium.server.proxy.GlobalErrorInterface;

/** 
 * The On Error Notification class is called by Audium Call Services whenever
 * an Audium application encounters an error.  It can be used to log information
 * to the console, notify administrators of a problem, or any other activity
 * you would like to perform when an error occurs.
 */
public class MyOnErrorNotification implements GlobalErrorInterface {
	/**
	 * All On Error Notification classes must implement this method.  It is passed
	 * a significant amount of data to aid developers in debugging application problems.
	 */
	public void doError(String audiumSessionID, String appName, String ani,
			String dnis, String iidigits, String uui, ArrayList entityHistory,
			ArrayList exitStateHistory, HashMap sessionData) {
		// PUT YOUR CODE HERE.
	}
}
