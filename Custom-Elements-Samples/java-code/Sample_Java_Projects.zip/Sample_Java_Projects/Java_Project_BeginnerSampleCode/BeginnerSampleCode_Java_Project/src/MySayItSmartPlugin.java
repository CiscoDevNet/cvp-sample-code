/*
   Copyright (c) 1999-2005 Audium Corporation
   All rights reserved
*/

import com.audium.server.sayitsmart.*;

/**
 * This defines a custom Say It Smart plugin. The marker class SayItSmartPlugin 
 * is needed so it will appear within Audium Builder for Studio.
 */
public class MySayItSmartPlugin extends SayItSmartBase implements SayItSmartPlugin
{
    /**
     * This method is used to define how this plugin will appear in Builder for 
     * Studio.
     */
	public SayItSmartDisplay getDisplayInformation() throws SayItSmartException
	{
		// PUT YOUR CODE HERE.
		
		SayItSmartDisplay toReturn = new SayItSmartDisplay("typeRealname", "Display Name", "Description");
		return toReturn;
    }
    
    /**
     * The input and output format dependencies are defined here. 
     */
    public SayItSmartDependency getFormatDependencies() throws SayItSmartException
    {
		// PUT YOUR CODE HERE.
        SayItSmartDependency toReturn = new SayItSmartDependency();
        toReturn.addParent("inputFormat", "outputFormat");
        return toReturn;
    }
    
    /**
     * The output format and fileset dependencies are defined here. 
     */
    public SayItSmartDependency getFilesetDependencies() throws SayItSmartException
    {
		// PUT YOUR CODE HERE.
        SayItSmartDependency toReturn = new SayItSmartDependency();
        toReturn.addParent("outputFormat", "fileset");
        return toReturn;
    }
    
    /**
     * This method actually does the conversion, returning a SayItSmartContent 
     * object listing all the audio files and/or TTS phrases needed to speak the
     * value passed as input.
     */
    public SayItSmartContent convertToFiles(Object dataAsObject, String inputFormat, 
    		String outputFormat, String fileset) throws SayItSmartException
    {    
		// PUT YOUR CODE HERE.
    		SayItSmartContent toReturn = new SayItSmartContent();
    		toReturn.add("filename", "transript", false);
    		return toReturn;
    }
    
    /**
     * This method returns what files need to be recorded for each filset. At 
     * this stage, this method is not used by Builder for Studio, but should be 
     * provided for future compatibility. Return null if the content is so 
     * dynamic that the number of audio files cannot be predicted.
     */
    public String[] getFilesetContents(String fileset) throws SayItSmartException
    {
		// PUT YOUR CODE HERE.
    		String[] toReturn = new String[] {"filename1", "filename2"};
    		return toReturn;
    }
}
