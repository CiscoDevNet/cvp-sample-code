import java.util.*;

// These classes are used by custom elements.
import com.audium.server.voiceElement.VoiceElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;

// This class is used by voice elements.
import com.audium.server.session.VoiceElementData;

// Include these to use VFCs.
import com.audium.core.vfc.*;
import com.audium.core.vfc.util.*;

/**
 * This defines a custom voice element. The marker class ElementInterface is
 * needed so it will show up in Audium Builder for Studio.
 */
public class MyVoiceElement extends VoiceElementBase implements ElementInterface 
{
	/**
	 * This method is where the voice element is expected to produce the 
	 * appropriate VoiceXML in the form of VFCs. The VMain object is where the 
	 * VFCs are to be added to, the Hashtable contains the submit arguments 
	 * sent by the voice browser (or null if there are none), and 
	 * VoiceElementData is the API with which the voice element can get its 
	 * configuration and get/set variables. Returning null from the method 
	 * indicates the voice element is not done and Audium Call Services needs 
	 * to revisit it to produce the next VoiceXML page. Return a non-null exit 
	 * state to indicate the voice element is done.
	 */
    protected String addXmlBody(VMain vxml, Hashtable reqParameters, VoiceElementData ved)
    							throws VException, ElementException 
    {
		// PUT YOUR CODE HERE.
		
    	return "done";
    }
    
	/**
	 * This method returns the name the voice element will have in the Element 
	 * Pane in the Audium Builder for Studio.
	 */
    public String getElementName()
    {
		// PUT YOUR CODE HERE.
    	
        return "My voice element";
    }

	/**
	 * This method returns the name of the folder in which this voice element 
	 * resides. Return null if it is to appear directly under the Elements 
	 * folder.
	 */
    public String getDisplayFolderName()
    {
		// PUT YOUR CODE HERE.
    	
        return "My voice element folder";
    }
    
	/**
	 * This method returns the text of a description of the voice element that 
	 * will appear as a popup when the cursor points to the element.
	 */
    public String getDescription() 
    {
		// PUT YOUR CODE HERE.
    	
        return "My voice element description";
    }

	/**
	 * This method returns an array of Setting objects representing all the 
	 * settings this voice element expects. Return null if the voice element 
	 * does not need any settings.
	 */
    public Setting[] getSettings() throws ElementException 
    {
		// PUT YOUR CODE HERE.
    	
        return null;
    } 
    
	/**
	 * This method returns a HashMap of arrays of AudioGroup objects 
	 * representing each set of audio groups this voice element expects. The 
	 * keys to the HashMap are the names of sets of audio groups. The arrays 
	 * represent the audio groups that appear in the set. Return null if the 
	 * voice element does not need any audio groups.
	 */
    public HashMap getAudioGroups() throws ElementException 
    {
		// PUT YOUR CODE HERE.
		
        return null;
    }

	/**
	 * This method returns an array of Strings representing the order in which 
	 * the audio group sets are to be displayed in Audium Builder for Studio. 
	 * Return null if the voice element does not need any audio groups.
	 */
    public String[] getAudioGroupDisplayOrder()
    {
		// PUT YOUR CODE HERE.
        
        return null;
    }

	/**
	 * This method returns an array of ExitState objects representing all the 
	 * possible exit states the voice element can return. There must be at 
	 * least one exit state.
	 */
    public ExitState[] getExitStates() throws ElementException 
    {
		// PUT YOUR CODE HERE.
		
        return null;
    }

	/**
	 * This method returns an array of ElementData objects representing the 
	 * element data that this voice element creates. Return null if the voice 
	 * element does not create any Element Data.
	 */
    public ElementData[] getElementData() throws ElementException 
    {
		// PUT YOUR CODE HERE.
		
        return null;
    }
}
