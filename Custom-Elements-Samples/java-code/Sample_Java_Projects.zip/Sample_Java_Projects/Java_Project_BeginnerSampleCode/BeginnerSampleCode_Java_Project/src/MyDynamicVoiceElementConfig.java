// These classes are used by dynamic voice element configurations.
import com.audium.server.AudiumException;
import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.session.ElementAPI;
import com.audium.server.xml.VoiceElementConfig;

/**
 * This class would be called if the voice element configuration is to be 
 * dynamically generated. Note that the interface to implement is named 
 * VoiceElementInterface for backwards compatibility purposes.
 */
public class MyDynamicVoiceElementConfig implements VoiceElementInterface
{
    /**
     * This method is expected to assemble the completed voice element 
     * configuration. It receives the base configuration created by Audium 
     * Builder for Studio which this method can edit to represent the desired 
     * configuration. If no base configuration is defined in the Builder, the 
     * third argument to the method is null. ElementAPI is used to interface 
     * with the system such as creating variables.
     */
    public VoiceElementConfig getConfig(String name, 
                                    	ElementAPI elementAPI, 
                                    	VoiceElementConfig defaults) throws AudiumException
    {
		// PUT YOUR CODE HERE. 
		
		// Alter defaults or create a new configuration and return.
        return defaults;
    }
}
