// These classes are used by standard action elements.
import com.audium.server.AudiumException;
import com.audium.server.voiceElement.ActionElementBase;
import com.audium.server.session.ActionElementData;

/**
 * This class is called when a standard action has been configured to use a 
 * Java class. Since this is a standard action element, it applies to a 
 * specific application and does not have a configuration. As a result, the 
 * only method needed in this class is the doAction method.
 */
public class MyStandardAction extends ActionElementBase
{
    /**
     * All action classes must implement this method. The data is retreived 
     * through the ActionElementData class. Unlike decisions, there is no need 
     * to return anything as all actions have a single exit state.
     */
    public void doAction(String name, ActionElementData data) throws AudiumException
    {
		// PUT YOUR CODE HERE. 
    }
}
