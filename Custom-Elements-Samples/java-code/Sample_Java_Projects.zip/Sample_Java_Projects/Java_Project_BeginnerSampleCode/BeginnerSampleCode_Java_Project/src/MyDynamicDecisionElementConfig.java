// These classes are used by dynamic decision element configurations.
import com.audium.server.AudiumException;
import com.audium.server.proxy.DecisionConfigInterface;
import com.audium.server.session.ElementAPI;
import com.audium.server.xml.DecisionElementConfig;

/**
 * This class would be called if the decision element configuration is to be 
 * dynamically generated.
 */
public class MyDynamicDecisionElementConfig implements DecisionConfigInterface
{
	/**
	 * This method is expected to assemble the completed decision element 
	 * configuration. It receives the base configuration created by Audium 
	 * Builder for Studio which this method can edit to represent the desired 
	 * configuration. If no base configuration is defined in the Builder, the 
	 * third argument to the method is null. ElementAPI is used to interface 
	 * with the system such as creating variables.
	 */
    public DecisionElementConfig getConfig(String name, 
                                    	   ElementAPI elementAPI, 
                                    	   DecisionElementConfig defaults) throws AudiumException
    {
		// PUT YOUR CODE HERE.
		
		// Alter defaults or create a new configuration and return.
        return defaults;
    }
}
