// These classes are used by custom configurable elements.
import com.audium.server.voiceElement.DecisionElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;

// This class is used by decision elements.
import com.audium.server.session.DecisionElementData;

/**
 * This is the skeleton of a configurable decision element. This is different 
 * from a standard decision in that it is pre-built and the developer 
 * configures it in Audium Builder for Studio. The methods implemented here 
 * apply primarily to define the configuration for display in the Builder.
 */
public class MyConfigurableDecision extends DecisionElementBase implements ElementInterface 
{
    /**
     * This method is run when the decision is visited. From the 
     * DecisionElementData object, the configuration can be obtained. The result 
     * of the decision is returned as a String from the method.
     */
    public String doDecision(String name, DecisionElementData data) throws ElementException
    {
		// PUT YOUR CODE HERE.

		// Return the appropriate exit state.
        return "";
    }

	/**
	 * This method returns the name the decision element will have in the Element 
	 * Pane in the Audium Builder for Studio.
	 */
    public String getElementName()
    {
		// PUT YOUR CODE HERE.
    	
        return "My decision element";
    }

	/**
	 * This method returns the name of the folder in which this decision element 
	 * resides. Return null if it is to appear directly under the Elements 
	 * folder.
	 */
    public String getDisplayFolderName()
    {
		// PUT YOUR CODE HERE.
    	
        return "My decision element folder";
    }

	/**
	 * This method returns the text of a description of the decision element that 
	 * will appear as a popup when the cursor points to the element.
	 */
    public String getDescription() 
    {
		// PUT YOUR CODE HERE.
    	
        return "My decision element description";
    }

	/**
	 * This method returns an array of Setting objects representing all the 
	 * settings this decision element expects. Return null if the decision element 
	 * does not need any settings.
	 */
    public Setting[] getSettings() throws ElementException 
    {
		// PUT YOUR CODE HERE.
    	
        return null;
    } 

	/**
	 * This method returns an array of ExitState objects representing all the 
	 * possible exit states the decision element can return. There must be at 
	 * least one exit state.
	 */
    public ExitState[] getExitStates() throws ElementException 
    {
		// PUT YOUR CODE HERE.
    	
    	// Here, the one exit state is "done".
        ExitState[] exitStateArray = new ExitState[1];
        exitStateArray[0] = new ExitState(ExitState.DONE);
        return exitStateArray;
    }

	/**
	 * This method returns an array of ElementData objects representing the 
	 * element data that this decision element creates. Return null if the decision 
	 * element does not create any Element Data.
	 */
    public ElementData[] getElementData() throws ElementException 
    {
		// PUT YOUR CODE HERE.
		
        return null;
    }
}
