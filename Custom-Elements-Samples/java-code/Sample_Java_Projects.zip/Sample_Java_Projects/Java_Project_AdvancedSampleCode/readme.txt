This project contains several more adavanced elements and Say It Smart plugins that require additional libraries to be added to their classpaths. The classes included in this project are:

NewDateInputFormat.java
NewDigitWithConfirm.java
NwForm.java 