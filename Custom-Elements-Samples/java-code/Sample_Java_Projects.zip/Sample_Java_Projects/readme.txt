This post contains several Java projects containing the sample code referenced in the other posts in this forum. These projects are suitable for importing into Audium Studio and already import the appropriate libraries in their classpath so the code can compile correctly.

Please do not attempt to use these projects unless you have knowledge of how Eclipse and Audium Studio function (by reading the Audium User and Programmer Guides).

These projects can also be imported into Eclipse, however the developer will need to re-establish links to the appropriate libraries in the project properties Java Build Path setting.

*** Audium provides these projects as-is as an aid to the developer. Audium will provide no support for these projects and the developer is expected to understand how to use them on their own. If the developer encounters problems with these projects, the command-line Java compiler is always available as defined in the Audium Programmer Guide. ***

The following instructions explain how to import these projects into Audium Studio:

0) Make sure you have a Java 1.3.1 JRE (or JDK) installed. All code deployed on Audium must be compiled on Java 1.3.1 in order to function without problems on Audium Call Services.

1) Unzip the project and place its contents in the Studio/workspace folder. Make sure that the end result is a folder with the name of the project, with the .project files, src folder, and build folder within it.

2) Launch Audium Studio and choose the Import option from the File menu.

3) Choose "Existing Project into Workspace", click on Next, Browse for the project folder you placed in the workspace folder, the click on Finish.

4) There will be errors attempting to compile this project because the desired Java 1.3.1 library cannot be found. To remedy this open the project properties, visit the "Java Build Path" setting, choose the "Libraries" tab, select the Java 1.3.1 JRE referenced and click on the delete button. Then click on the "Add Library..." button, choose the JRE System Library, and choose a Java 1.3.1 JRE. Click on Finish. Click on Ok to exit the project preferences. The classes should compile without errors.

5) If you want to enjoy everything a Java IDE has to offer, you will need to open up the Java Perspective from the Window menu. You can then use Studio in the same way as Eclipse to edit Java code.

When you compile code, it will appear in a build folder that will not be visible in the Java persective but will appear in the Audium perspective. Note that when an Audium application is deployed, it will copy whatever is placed in the deploy folder to the Call Services application. To get compiled Java classes into this folder, one can simly copy them from the build directory of these projects directly to the deploy/java/classes folder of the desired application (or the Studio common plugin).

One note on compiling code within Studio. Each class will seem to display a warning or error message at the top of the class with the warning "This compilation unit indirectly references the missing type com.audium.server.xml.e (typically some required class file is referencing a type outside the classpath)". This warning can be safely ignored as when you deploy your applications to Audium Call Services, all required classes will appear in the classpath. The classes in framework.jar are all you need in order to compile your custom Audum components.

Enjoy!