package com.audiumcorp.support.sayitsmart;

import com.audium.sayitsmart.plugins.AudiumSayItSmartTime;
import com.audium.server.sayitsmart.*;
import java.util.StringTokenizer;

/**
 * CLASS: OptionalLeadingZerosTimeInputFormat.java
 * 
 * This Say It Smart plugin extends the existing "Time/Time Period" plugin.  
 * 
 * New input format supported: (H)H:(M)M
 * 
 * This adds the ability to accept time inputs that optionally omit leading zeros.
 * For example, the times 1:13 and 01:13 are both acceptable to represent 1:13am
 * with this plugin.  Another example is 15:3, which may be used to represent
 * 3:03pm.
 * 
 * The allowance for omitted zeros allows for the current time to be played back
 * using substitution.  This can be done by inserting two substitutions into the Data 
 * field of the plugin's configuration.  One for the current hour, a colon, and then 
 * one for the current minute.  These substitutions can be found on the Date/Time tab 
 * of the Substitution Tag Builder.
 */
public class OptionalLeadingZerosTimeInputFormat extends SayItSmartBase implements
		SayItSmartPlugin {
	/*
	 * We define the constants holding the real name, display name, and
	 * description of the new input format.
	 */
	public static final String OPTIONAL_LEADING_ZEROS_TIME_INPUT_FORMAT = 
		"optional_leading_zeros_time";

	public static final String OPTIONAL_LEADING_ZEROS_TIME_INPUT_FORMAT_DISPLAY = 
		"Time Period (H)H:(M)M";

	public static final String OPTIONAL_LEADING_ZEROS_TIME_INPUT_FORMAT_DESCRIPTION = 
		"This input format supports omitting leading zeros before the hour"
	  + " and/or minutes.  For example 1:12 (meaning 01:12) or 12:4 (meaning 12:04).";

	/*
	 * We create an instance of AudiumSayItSmartTime because we need it to
	 * access information and to actually take care of most of the work for us.
	 */
	public AudiumSayItSmartTime timePlugin = new AudiumSayItSmartTime();

	/**
	 * This method only defines this plugin's information, which is the new
	 * input format; the output formats and filesets already defined in the
	 * AudiumSayItSmartTime plugin are reused. We use the instance of 
	 * AudiumSayItSmartTime to return the information for these output formats 
	 * and filesets. It is important that we give this plugin the same real name 
	 * (and display name too) as the AudiumSayItSmartTime plugin type's real 
	 * name otherwise the Builder will not merge the two plugins. We still have 
	 * to define an output format and filesets even though we are just reusing 
	 * the ones from AudiumSayItSmartTime because a plugin must define the 
	 * dependencies correctly.
	 */
	public final SayItSmartDisplay getDisplayInformation() throws SayItSmartException {
		SayItSmartDisplay toReturn = new SayItSmartDisplay("time",
				"Time/Time Period",
				"This plugin adds a new input format to the time plugin");
		toReturn.addInputFormat(OPTIONAL_LEADING_ZEROS_TIME_INPUT_FORMAT,
				OPTIONAL_LEADING_ZEROS_TIME_INPUT_FORMAT_DISPLAY,
				OPTIONAL_LEADING_ZEROS_TIME_INPUT_FORMAT_DESCRIPTION);
		toReturn.addOutputFormat(timePlugin.TIME_OUTPUT_FORMAT,
				timePlugin.TIME_OUTPUT_FORMAT_DISPLAY,
				timePlugin.TIME_OUTPUT_FORMAT_DESCRIPTION);
		toReturn.addFileset(timePlugin.STANDARD_TIME_FILESET,
				timePlugin.STANDARD_TIME_FILESET_DISPLAY,
				timePlugin.STANDARD_TIME_FILESET_DESCRIPTION);
		toReturn.addFileset(timePlugin.ENHANCED_TIME_FILESET,
				timePlugin.ENHANCED_TIME_FILESET_DISPLAY,
				timePlugin.ENHANCED_TIME_FILESET_DESCRIPTION);

		return toReturn;
	}

	/**
	 * Here we report the dependencies between the new input format and
	 * the output format.
	 */
	public final SayItSmartDependency getFormatDependencies()
			throws SayItSmartException {
		return new SayItSmartDependency(OPTIONAL_LEADING_ZEROS_TIME_INPUT_FORMAT,
				timePlugin.TIME_OUTPUT_FORMAT);
	}

	/**
	 * Here we report the dependencies between the output format and the
	 * filesets. We get this information straight from how the
	 * AudiumSayItSmartTime defines them.
	 */
	public final SayItSmartDependency getFilesetDependencies()
			throws SayItSmartException {
		return new SayItSmartDependency(timePlugin.TIME_OUTPUT_FORMAT,
				new String[] {timePlugin.STANDARD_TIME_FILESET,
				               timePlugin.ENHANCED_TIME_FILESET});
	}

	/**
	 * The filesets have not changed, all we did is change how the input comes
	 * in as. Therefore, we return whatever the AudiumSayItSmartTime
	 * object returns.
	 */
	public final String[] getFilesetContents(String fileset)
			throws SayItSmartException {
		return timePlugin.getFilesetContents(fileset);
	}

	/**
	 * Converts the input string in the format (H)H:(M)M to the HHMM format
	 * after which point the convertToFiles() method of our AudiumSayItSmartTime
	 * object is called to do the work.
	 */
	public final SayItSmartContent convertToFiles(Object optionalLeadingZerosTime,
			String inputFormat, String outputFormat, String fileset)
			throws SayItSmartException {
		
		// Find the hour
		StringTokenizer st = new StringTokenizer((String) optionalLeadingZerosTime, ":");
		String hour = st.nextToken();
		
		// Pad the hour if required
		if (hour.length() == 1) {
			hour = "0" + hour;
		}
		
		// Find the minute
		String minute = st.nextToken();
		
		// Pad the minute if required
		if (minute.length() == 1) {
			minute = "0" + minute;
		}
		
		// Combine the padded hours and minutes to form the HHMM format
		String standardTime = hour + minute;
		
		/*
		 * Now that the conversion of the input type is complete, our instance
		 * of the time plugin can do the work.
		 */
		return timePlugin.convertToFiles(standardTime, timePlugin.TIME_HHMM,
				outputFormat, fileset);
	}
}