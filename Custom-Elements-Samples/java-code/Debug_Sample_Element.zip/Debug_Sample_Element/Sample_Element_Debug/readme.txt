This sample element logs specified element or session data to the console and/or to a specified log file.

This element is considered beta software. Use with a particular gateway adapter may require modifications to the provided source; testing should be performed to ensure compatibility, use the element at your own risk.

An element specification has been provided, please find the .pdf attached to this post. It follows the same format as the official Element Specifications.

To use this element in a single Audium application:

Copy Debug.jar into that application's deploy/java/application/lib directory in Audium Builder for Studio, and then close and reopen the call flow for that application. The new element will be listed in the "Local Elements/Audium Support" folder, in the Elements pane. The JAR file for Debug will automatically be deployed when the Audium application is deployed.

To install this element for use in any application:

Copy Debug.jar into the eclipse/plugins/com.audium.studio.common_3.4.1/lib directory (under Audium Studio's directory). Then, exit and restart Audium Studio. The new element will be listed in the "Audium Support" folder, in the Elements pane. Additionally, any installation of Audium Call Services that will be used to execute an application that includes this element should have Debug.jar copied into its AUDIUM_HOME/common/lib directory.

For additional details about deploying custom elements, please refer to Chapter 2 of the Programmer Guide. 