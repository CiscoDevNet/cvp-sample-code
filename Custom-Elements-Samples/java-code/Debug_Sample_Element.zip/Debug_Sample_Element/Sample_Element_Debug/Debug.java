package com.audiumcorp.support.elements.actionElements;

import com.audium.server.session.ActionElementData;
import com.audium.server.voiceElement.ActionElementBase;
import com.audium.server.voiceElement.Dependency;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.voiceElement.ElementData;
import java.io.*;
import java.util.*;
import java.text.*;

import com.audium.server.xml.ActionElementConfig;

/**
 * CLASS: Debug.java
 * 
 * This Action element logs the value of one or more element or session variables.  
 * They may either be logged to the console, to a specified file, or to both.  If the
 * element is configured to log to a file, and the file cannot be created, then an
 * exception will be thrown.
 */

public class Debug extends ActionElementBase implements ElementInterface {
	/**
	 * This is the name of the sample Action element, which appears in the
	 * Audium Builder.
	 */
	public final String getElementName() {
		return "Debug";
	}

	/**
	 * This is the name of the folder in the Audium Builder in which this sample
	 * Action element appears.
	 */
	public final String getDisplayFolderName() {
		return "Audium Support";
	}

	/**
	 * This is the description of what this Action element does.
	 */
	public final String getDescription() {
		return "This element logs the value of one or more element or session variables.";
	}

	/**
	 * This returns the settings used by this sample Action element.
	 */
	public final Setting[] getSettings() throws ElementException {
		Setting[] settingArray = new Setting[4];

		settingArray[0] = new Setting("log_to", "Log To",
				"Where the element and/or session data should be logged.", true, // It is required
				true, // It appears only once
				false, // It does not allow substitution
				new String[] {"console", "file", "both"});
		settingArray[0].setDefaultValue("console");

		settingArray[1] = new Setting(
				"log_filename",
				"Log Filename",
				"The location where the log file should be created, including the filename.",
				true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.STRING);

		settingArray[2] = new Setting("element_data", "Element Data",
				"An element name and variable pair, delimited by a colon; the variable will be logged.  For example, myelement:value.", false, // It is not required
				false, // It can appear multiple times
				true, // It allows substitution
				Setting.STRING);
		settingArray[2].setDefaultValue("");

		settingArray[3] = new Setting("session_data", "Session Data",
				"The name of a variable in session data to log the value of.", false, // It is not
				// required
				false, // It can appear multiple times
				true, // It allows substitution
				Setting.STRING);
		settingArray[3].setDefaultValue("");

		// Create dependencies
		Dependency d1 = new Dependency(settingArray[0].getRealName(),
				"console", Dependency.NOT_EQUAL);
		Dependency[] depArray1 = {d1};

		// Log Filename should only appear if Log To is not set to "console"
		settingArray[1].setDependencies(depArray1);

		return settingArray;
	}

	/**
	 * This method returns an array of ElementData objects representing the
	 * Element Data that this action element creates. In this case, the element
	 * creates no Element Data, and so this method returns null.
	 */
	public final ElementData[] getElementData() throws ElementException {
		return null;
	}

	/**
	 * This method performs the action.
	 */
	public final void doAction(String name, ActionElementData actionData)
			throws ElementException {

		// Get the configuration
		ActionElementConfig config = actionData.getActionElementConfig();

		// Determine where to log to
		boolean logToConsole = config.getSettingValue("log_to", actionData).equals("console") 
							   || config.getSettingValue("log_to", actionData).equals("both");
		boolean logToFile =    config.getSettingValue("log_to", actionData).equals("file") 
							   || config.getSettingValue("log_to", actionData).equals("both");
		
		// Init
		FileWriter logWriter = null;
		
		try {
			if (logToFile) {
				// Open a file for output
				logWriter = new FileWriter(config.getSettingValue("log_filename", actionData));				
			}
			
			// Find all of the requested element/session data to log the value of
			String[] elementData = config.getSettingValues("element_data",
					actionData);
			String[] sessionData = config.getSettingValues("session_data",
					actionData);

			// Indicate that this log is from the Debug element, and add timestamp
			DateFormat df = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
			String timestamp = df.format(new Date());
			String content = "[" + timestamp + "]" + " Debug element log";
			if (logToConsole) {
				System.out.println(content);
			}
			if (logToFile) {
				logWriter.write(content + "\n");
			}
			
			// Log the element data
			content = "Element Data";
			if (logToConsole) {
				System.out.println(content);
			}
			if (logToFile) {
				logWriter.write(content + "\n");
			}

			for (int i = 0; i < elementData.length; i++) {
				StringTokenizer st = new StringTokenizer(elementData[i], ":");
				String elementName = st.nextToken(); 
				String variableName = st.nextToken();
				content = (i + 1) + ". Element: "
						+ elementName
						+ " Variable: "
						+ variableName
						+ " Value: "
						+ actionData.getElementData(elementName, variableName);
				if (logToConsole) {
					System.out.println(content);
				}
				if (logToFile) {
					logWriter.write(content + "\n");					
				}
			}

			// Log the session data
			content = "Session Data";
			if (logToConsole) {
				System.out.println(content);
			}
			if (logToFile) {
				logWriter.write(content + "\n");			
			}

			for (int i = 0; i < sessionData.length; i++) {
				content = (i + 1) + ". Session Variable: " + sessionData[i] + " Value: "
						+ actionData.getSessionData(sessionData[i]);
				if (logToConsole) {
					System.out.println(content);
				}
				if (logToFile) {
					logWriter.write(content + "\n");
				}
			}
			
			// Close the log file if it was opened
			if (logWriter != null) {
				logWriter.close();
			}
		} catch (IOException ioe) {
			// If there is an IO exception, we will throw it to Audium 
			// Call Services with a message
			throw new ElementException("IO exception while in Debug element.");
		}
	}
}