The CounterWithDecision sample element works much like the built-in Counter element, except it also branches the callflow when it is visited, based on the current value of the counter. The ResetCounterWithDecision element can be used to reset any CounterWithDecision elements in the callflow.

These elements are considered beta software. Use with a particular gateway adapter may require modifications to the provided source; testing should be performed to ensure compatibility, use the elements at your own risk.

Element specifications have been provided, please find the .pdf files attached to this post. They follow the same format as the official Element Specifications.

To use these elements in a single Audium application:

Copy the JAR files into that application's deploy/java/application/lib directory in Audium Builder for Studio, and then close and reopen the call flow for that application. The new elements will be listed in the "Local Elements/Audium Support" folder, in the Elements pane. The JAR files will automatically be deployed when the Audium application is deployed.

To install these elements for use in any application:

Copy the JAR files into the eclipse/plugins/com.audium.studio.common_3.4.1/lib directory (under Audium Studio's directory). Then, exit and restart Audium Studio. The new elements will be listed in the "Audium Support" folder, in the Elements pane. Additionally, any installation of Audium Call Services that will be used to execute an application that includes these elements should have the JAR files copied into its AUDIUM_HOME/common/lib directory.

For additional details about deploying custom elements, please refer to Chapter 2 of the Programmer Guide. 