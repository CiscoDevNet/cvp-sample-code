package com.audiumcorp.support.elements.actionElements;

import com.audium.server.session.ActionElementData;
import com.audium.server.voiceElement.ActionElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.xml.ActionElementConfig;

/**
 * CLASS: ResetCounterWithDecision.java
 * 
 * This Action element is used only in conjunction with one or more CounterWithDecision
 * elements.  When this element is visited, the specified CounterWithDecision element 
 * is informed that it should reset its count variable.  The actual resetting of
 * this variable does not occur until the CounterWithDecision element is next visited,
 * so if this variable is examined between the time when the ResetCounterWithDecision
 * element is visited, and the CounterWithDecision element is visited, the count will
 * have an old (i.e. not reset) value.
 * 
 * This element has no effect on built-in Counter elements.
 */

public class ResetCounterWithDecision extends ActionElementBase implements
		ElementInterface {
	/**
	 * This is the name of the sample Action element, which appears in the
	 * Audium Builder.
	 */	
	public final String getElementName() {
		return "ResetCounterWithDecision";
	}

	/**
	 * This is the name of the folder in the Audium Builder in which this sample
	 * Action element appears.
	 */	
	public final String getDisplayFolderName() {
		return "Audium Support";
	}

	/**
	 * This is the description of what this Action element does.
	 */	
	public final String getDescription() {
		return "This element causes a CounterWithDecision element to reset" 
		  + " its count the next time it is visited.";
	}

	/**
	 * This returns the settings used by this sample Action element.
	 */	
	public final Setting[] getSettings() throws ElementException {
		Setting[] settingArray = new Setting[1];

		settingArray[0] = new Setting("element_to_reset", "Element To Reset",
				"The name of the CounterWithDecision element that will be told to reset itself.", 
				true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.STRING);

		return settingArray;
	}

	/**
	 * This method returns an array of ElementData objects representing the
	 * Element Data that this action element creates.  Since this element does
	 * not create any element data, this method returns null.
	 */
	public final ElementData[] getElementData() throws ElementException {
		return null;
	}

	/**
	 * This method performs the action.
	 */
	public final void doAction(String name, ActionElementData actionData)
			throws ElementException {
		// Get a reference to the configuration
		ActionElementConfig config = actionData.getActionElementConfig();

		// Get the name of the CounterWithDecision element to reset
		String elementToReset = config.getSettingValue("element_to_reset", actionData);

		/** 
		 * Check whether the element exists, by checking if it has set session
		 * data named ELEMENTNAME_resetCounter (where ELEMENTNAME is the name of
		 * the CounterWithDecision element).
		 */
		if (actionData.getSessionData(elementToReset + "_resetCounter") != null) {
			/** 
			 * The element exists, we will tell it to reset itself by setting
			 * the value of this session variable to true.  Note that the count
			 * of the element is not immediately reset, it will be reset the next
			 * time the CounterWithDecision element is visited.
			 */
			try {
				actionData.setSessionData(elementToReset + "_resetCounter", "true");
			} catch (Exception e) {
				throw new ElementException("Caught an exception in ResetCounterWithDecision element." 
						+ "  Element name passed to setSessionData() was probably null.");
			}
			actionData.addToLog(elementToReset, "reset");
		} else {
			// The specified CounterWithDecision element does not exist, log this
			actionData.addToLog(elementToReset, "does not exist");
		}
	}
}