package com.audiumcorp.support.elements.decisionElements;

import com.audium.server.voiceElement.DecisionElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.session.DecisionElementData;
import com.audium.server.xml.DecisionElementConfig;
import com.audium.server.AudiumException;

/**
 * CLASS: CounterWithDecision.java
 * 
 * This Decision element combines the functionality of a counter with a decision.
 * Each time this element is visited, the counter is incremented or decremented 
 * (as configured), and if the new value passes a certain limit (also as configured) 
 * then the element will exit as limit_reached.  Otherwise, the element will exit as 
 * limit_not_reached.
 * 
 * This element can be used in conjunction with one or more ResetCounterWithDecision
 * elements (which can reset a specified CounterWithDecision element), or can be
 * used alone.
 */

public class CounterWithDecision extends DecisionElementBase implements ElementInterface {
	/**
	 * This method performs the decision.
	 */	
	public final String doDecision(String arg0, DecisionElementData data)
			throws AudiumException {
		String exitState = "limit_not_reached";
		
		// Get a reference to the configuration
		DecisionElementConfig config = data.getDecisionElementConfig();
		
		// Get the current value of the counter from element data
		String count = data.getElementData(data.getCurrentElement(), "count");

		// Get the limit for the counter from the settings
		int limit = Integer.parseInt(config.getSettingValue("limit", data));

		/* If count is null, then this is the first time the element has been visited,
		 * and the count needs to be initialized from the settings.  Additionally, if
		 * session data named ELEMENTNAME_resetCounter (where ELEMENTNAME is the name
		 * of this element) exists and is set to true, reset the count.  This session 
		 * data variable is used as a communication channel from the 
		 * ResetCounterWithDecision element, telling us to reset the count. 
		 */
		String sessionValue = (String) (data.getSessionData(data.getCurrentElement() + "_resetCounter"));
		boolean shouldReset = false;
		if (sessionValue != null) {
			shouldReset = sessionValue.equals("true");
		}
		if ((count == null)	|| shouldReset) {
			count = config.getSettingValue("counter_initial", data);
			data.setSessionData(data.getCurrentElement() + "_resetCounter",	"false");

			// If the counter_initial setting exceeds the limit setting,
			// then the counter is already done.
			if ((Integer.parseInt(count) >= limit && config.getSettingValue("type", data).equals("increment"))
			 || (Integer.parseInt(count) <= limit && config.getSettingValue("type", data).equals("decrement"))) {
				exitState = "limit_reached";
			}
		} else { // This is not the first time through the loop.
			// Check if the count has exceeded the limit setting.  If so, then the counter is done.
			if ((Integer.parseInt(count) >= limit && config.getSettingValue("type", data).equals("increment"))
			 || (Integer.parseInt(count) <= limit && config.getSettingValue("type", data).equals("decrement"))) {
				exitState = "limit_reached";
			} else { // The count has not exceeded the limit setting, update the count.			
				String stepSize = config.getSettingValue("step_size", data);
				if (config.getSettingValue("type", data).equals("increment")) {
					count = String.valueOf(Integer.parseInt(count) + Integer.parseInt(stepSize));					
				} else if (config.getSettingValue("type", data).equals("decrement")) {
					count = String.valueOf(Integer.parseInt(count) - Integer.parseInt(stepSize));				
				}					
			}
		}

		// Store the new count in element data.
		data.setElementData("count", count);

		// Log the new count.
		data.addToLog("count", count);
		
		return exitState;
	}

	/**
	 * This is the name of the sample Decision element, which appears in the
	 * Audium Builder.
	 */
	public final String getElementName() {
		return "CounterWithDecision";
	}

	/**
	 * This is the description of what this Decision element does.
	 */
	public final String getDescription() {
		return "Whenever this element is visited, the counter is updated, and one of two" 
		  + " exit states is followed based on how the value of the counter compares"
		  + " to the configured limit.";
	}

	/**
	 * This is the name of the folder in the Audium Builder in which this sample
	 * Decision element appears.
	 */
	public final String getDisplayFolderName() {
		return "Audium Support";
	}

	/**
	 * This returns the settings used by this sample Decision element.
	 */
	public final Setting[] getSettings() throws ElementException {
		Setting[] settingArray = new Setting[4];

		settingArray[0] = new Setting("counter_initial", "Initial Count",
				"This setting specifies what integer value this counter should start at.",
				true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.INT);
		settingArray[0].setDefaultValue("0");
		settingArray[1] = new Setting("type", "Type",
				"This setting is either increment or decrement.",
				true, // It is required
				true, // It appears only once
				false, // It does not allow substitution
				new String[] {"increment", "decrement"});
		settingArray[1].setDefaultValue("increment");				
		settingArray[2] = new Setting("step_size", "Step Size",
				"This setting specifies by how much this counter"
				  + " should be incremented or decremented.", 
				true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.INT);
		settingArray[2].setDefaultValue("1");
		settingArray[3] = new Setting("limit", "Limit Value",
				"This setting specifies the limit value for the counter.", 
				true, // It is required
				true, // It appears only once
				true, // It allows substitution
				Setting.INT);
		settingArray[3].setDefaultValue("1");

		return settingArray;
	}

	/**
	 * This method returns an array of ExitState objects representing the
	 * exit states that this Decision element has.
	 */
	public final ExitState[] getExitStates() throws ElementException {
		ExitState[] exitStates = new ExitState[2];
		exitStates[0] = new ExitState("limit_reached", "limit_reached",
				"The counter has reached the limit value.");
		exitStates[1] = new ExitState("limit_not_reached", "limit_not_reached",
				"The counter has not reached the limit value.");

		return exitStates;
	}

	/**
	 * This method returns an array of ElementData objects representing the
	 * Element Data that this Decision element creates.
	 */	
	public final ElementData[] getElementData() throws ElementException {
		ElementData[] elementDataArray = new ElementData[1];

		elementDataArray[0] = new ElementData("count",
		  "The current value of the counter.");		
		
		return elementDataArray;
	}
}