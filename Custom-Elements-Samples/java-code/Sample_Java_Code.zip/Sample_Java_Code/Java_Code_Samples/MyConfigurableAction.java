//These classes are used by custom configurable elements.
import com.audium.server.voiceElement.ActionElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;

// This class is used by action elements.
import com.audium.server.session.ActionElementData;

/**
 * This is the skeleton of a configurable action element. This is different 
 * from a standard action in that it is pre-built and the developer 
 * configures it in Audium Builder for Studio. The methods implemented here 
 * apply primarily to define the configuration for display in the Builder. Note 
 * that there is no need to implement the methods getExitStates because action 
 * elements only have a single exit state: "done".
 */
public class MyConfigurableAction extends ActionElementBase implements ElementInterface 
{
    /**
     * This method is run when the action is visited. From the ActionElementData
     * object, the configuration can be obtained. 
     */
    public void doAction(String name, ActionElementData data) throws ElementException
    {
		// PUT YOUR CODE HERE.
    }

	/**
	 * This method returns the name the action element will have in the Element 
	 * Pane in the Audium Builder for Studio.
	 */
    public String getElementName()
    {
		// PUT YOUR CODE HERE.
    	
        return "My action element";
    }

	/**
	 * This method returns the name of the folder in which this action element 
	 * resides. Return null if it is to appear directly under the Elements 
	 * folder.
	 */
    public String getDisplayFolderName()
    {
		// PUT YOUR CODE HERE.
    	
        return "My action element folder";
    }

	/**
	 * This method returns the text of a description of the action element that 
	 * will appear as a popup when the cursor points to the element.
	 */
    public String getDescription() 
    {
		// PUT YOUR CODE HERE.
    	
        return "My action element description";
    }

	/**
	 * This method returns an array of Setting objects representing all the 
	 * settings this action element expects. Return null if the action element 
	 * does not need any settings.
	 */
    public Setting[] getSettings() throws ElementException 
    {
		// PUT YOUR CODE HERE.
    	
        return null;
    } 

	/**
	 * This method returns an array of ElementData objects representing the 
	 * element data that this action element creates. Return null if the action 
	 * element does not create any Element Data.
	 */
    public ElementData[] getElementData() throws ElementException 
    {
		// PUT YOUR CODE HERE.
		
        return null;
    }
}
