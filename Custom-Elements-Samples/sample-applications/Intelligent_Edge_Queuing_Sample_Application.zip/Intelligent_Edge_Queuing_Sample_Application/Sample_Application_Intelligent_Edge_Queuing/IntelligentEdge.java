/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cisco.cvp.vxml;

/**
 *
 * @author jbyron
 */
import com.audium.server.AudiumException;
import com.audium.server.proxy.EndCallInterface;
import com.audium.server.session.CallEndAPI;

import java.sql.*;
import javax.sql.*;
import javax.naming.*;

/**
 * The On End Call Class is called if the caller hung up, the application hung
 * up on the caller, the session was invalidated, or the sesion timed out on its
 * own (due tosome error).
 */
public class IntelligentEdge implements EndCallInterface {

    /**
     * Method name
     */
    public static final String ELEMENT_LOG_NAME = "IntelligentEdge End Class";
    /**
     * Element variables
     */

    //@Override
    /**
     * @param appApi
     * @throws com.audium.server.AudiumException
     */
    public void onEndCall(CallEndAPI appApi) throws AudiumException {
        try {
            appApi.addToLog(ELEMENT_LOG_NAME, "onEndCall");
            String discCause = appApi.getHowCallEnded();
            if (discCause.equals("hangup")) {
                discCause = "ABANDONED";
            } else if (discCause.equals("call_transfer")) {
                discCause = "CONNECTED";
            } else {
                discCause = "OTHER";
            }
            Context envCtx = (Context) new InitialContext().lookup("java:comp/env");
            DataSource ds = (DataSource) envCtx.lookup("jdbc/ciscotest");
            Connection conn = ds.getConnection();

            String qid = (String) appApi.getElementData("DB_InsertCall","id");
            System.out.println("IntelligentEdge: Updating end time in queue entry " + qid);

            Statement s = conn.createStatement();
            s.execute("call cvp_cleanup(" + qid + ",'" + discCause + "');");

            conn.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
