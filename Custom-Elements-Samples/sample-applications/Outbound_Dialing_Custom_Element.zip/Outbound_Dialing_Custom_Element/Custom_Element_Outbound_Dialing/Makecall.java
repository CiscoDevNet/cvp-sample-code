/*
 * MAKECALL CUSTOM VOICE ELEMENT
 * This model is a sample intended for distribution on developer.cisco.com (CDC).
 * Refer to the CDC website Support Tab for Support rules that apply to this module.
 *
 * This element is a component of the CVP Standalone Outbound Solution.
 * It is used to send an outbound call request to the Cisco ingress gateway via handoff to OBCALLREQ.TCL
 * on the VXML gateway.  The outbound call parameters are read from the element settings at run-time
 * and formatted into the handoff-object argument string in the following format:
 * 
 *      dest=8669445025 cli=8005551212 rna=30 id=11112222AAAABBBB uui="Call context info"
 * 
 * The outbound call outcome is extracted from the handoff-object return string, mapped into a summary
 * set of exit states and also copied into the element data with name "result".
 * 
 * Version 1.0
 */

import java.util.*;

import com.audium.server.voiceElement.VoiceElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.session.VoiceElementData;
import com.audium.server.xml.VoiceElementConfig;

import com.audium.core.vfc.*;
import com.audium.core.vfc.form.*;
import com.audium.core.vfc.util.*;

public class Makecall extends VoiceElementBase implements ElementInterface 
{
	public String getElementName()
	{
		return "Makecall";
	}

	public String getDescription() 
	{
		return "Make outbound call from voice gateway";
	}

	public String getDisplayFolderName() 
	{
		return "Call Control";
	}

	public Setting[] getSettings() throws ElementException 
	{

//public Setting(java.lang.String name,
//               java.lang.String displayName,
//               java.lang.String description,
//               boolean required,
//               boolean single,
//               boolean substitution,
//               int type)
//        throws ElementException
//
//    Constructs a string, boolean, or textfield Setting with custom parameters, or an integer or float Setting with custom parameters and no range minimum/maximum value restrictions.
//
//Parameters:
//    name - The name of the setting.
//    displayName - The display name of the setting
//    description - A String describing this setting.
//    required - True if all element configurations must set this setting, false if it is optional.
//    single - True if there can be only one value for this setting, false if multiple values are allowed.
//    substitution - True if this setting's value can come from substitution, false if the value must be static.
//    type - The data type of this setting. Must be STRING, BOOLEAN, TEXTFIELD, INT or FLOAT. 
            
                Setting dnis =  new Setting("destination", "Outbound Destination",
                                            "Destination for outbound call",
                                            true, true, true, Setting.STRING);

                Setting cli =   new Setting("calling_party", "Calling-party",
                                            "ANI/CLI to send on outbound call",
                                            true, true, true, Setting.STRING);

                Setting rna =   new Setting("rna_timeout", "No-answer timeout",
                                            "Timeout value (secs) for destination ring-no-answer (default 30)",
                                            false, true, true, Setting.STRING);

                Setting req  =   new Setting("req_id", "Request ID",
                                            "User or DB supplied ID for this outbound call request (default is the existing call ID for this session)",
                                            false, true, true, Setting.STRING);

                Setting uui =   new Setting("uui", "UUI",
                                            "User-to-User data to send on the outbound call",
                                            false, true, true, Setting.STRING);          

                Setting[] cfg_settings = new Setting[] {dnis, cli, rna, req, uui};

                rna.setDefaultValue("30");
                req.setDefaultValue("{Data.Session.callid}");
								   
		return cfg_settings;
	} 

	public HashMap getAudioGroups() throws ElementException 
	{
		return null;
        }
    
	public String[] getAudioGroupDisplayOrder() 
	{
		return null;
	}

	public ExitState[] getExitStates() throws ElementException 
	{
		ExitState[] exitStateArray = new ExitState[6];
                
            exitStateArray[0] = new ExitState("connected", "connected", "Called party answered");
		exitStateArray[1] = new ExitState("busy", "busy", "Called party busy");
		exitStateArray[2] = new ExitState("noanswer", "noanswer", "Called party answer timeout");
		exitStateArray[3] = new ExitState("invalid_number", "invalid_number", "Invalid number was dialed");
		exitStateArray[4] = new ExitState("disconnect", "disconnect", "Called party disconnected");
		exitStateArray[5] = new ExitState("failed", "failed", "Failed to setup outbound call");
		return exitStateArray;
	}

	public ElementData[] getElementData() throws ElementException 
	{
                ElementData[] elemDataArray = new ElementData[1];
                
                elemDataArray[0] = new ElementData("result", "Call setup outcome");           
                return elemDataArray;
	}
	
	protected String addXmlBody(VMain vxml, Hashtable reqParameters, VoiceElementData ved)
									throws VException, ElementException 
	{
		VPreference pref = ved.getPreference();
                Boolean process_response = (Boolean) ved.getScratchData("setup_sent");
                
		if (process_response == null)
                {
                    
// This is the first pass through addXmlBody() so build the VXML document to perform handoff to the TCL
// script on the VXML gateway that will send the request to the ingress gateway to make the outbound call.
// Start by looking up the dynamic settings for this element.
                    
                        VoiceElementConfig cfg = ved.getVoiceElementConfig();
                        
                        String rna = cfg.getSettingValue("rna_timeout", ved);
                        String cli = cfg.getSettingValue("calling_party", ved);
                        String dst = cfg.getSettingValue("destination", ved);
                        String id  = cfg.getSettingValue("req_id", ved);
                        String uui = cfg.getSettingValue("uui", ved);
                                           
// Start building the VXML doc by adding catch blocks to trap the various disconnect events.
                        
                        String event_name;
                
                        VAction submit_action = getSubmitVAction("call_outcome", pref);
                        VAction ev_submit = VAction.getNew(pref, VAction.VARIABLE, "call_outcome", "disconnect", true);
                        ev_submit.add(submit_action);

                        event_name = "telephone.disconnect.com.cisco.callhandoff";
                        VEvent ev_disc_1 = VEvent.getNew(pref, event_name);
                        ev_disc_1.addCount(1);
                        ev_disc_1.setReprompt(1, false);
                        ev_disc_1.addItem(1, VAction.getNew(pref, null, null, "MAKECALL, detected event <" + event_name + ">, call ID <" + id + ">", false));
                        ev_disc_1.addItem(1, ev_submit);
                        vxml.add(ev_disc_1);

                        event_name = "telephone.disconnect.com.cisco.handoff";
                        VEvent ev_disc_2 = VEvent.getNew(pref, event_name);
                        ev_disc_2.addCount(1);
                        ev_disc_2.setReprompt(1, false);
                        ev_disc_2.addItem(1, VAction.getNew(pref, null, null, "MAKECALL, detected event <" + event_name + ">, call ID <" + id + ">", false));
                        ev_disc_2.addItem(1, ev_submit);
                        vxml.add(ev_disc_2);

                        event_name = "disconnect.com.cisco.callhandoff";
                        VEvent ev_disc_3 = VEvent.getNew(pref, event_name);
                        ev_disc_3.addCount(1);
                        ev_disc_3.setReprompt(1, false);
                        ev_disc_3.addItem(1, VAction.getNew(pref, null, null, "MAKECALL, detected event <" + event_name + ">, call ID <" + id + ">", false));
                        ev_disc_3.addItem(1, ev_submit);
                        vxml.add(ev_disc_3);

                        event_name = "disconnect.com.cisco.handoff";
                        VEvent ev_disc_4 = VEvent.getNew(pref, event_name);
                        ev_disc_4.addCount(1);
                        ev_disc_4.setReprompt(1, false);
                        ev_disc_4.addItem(1, VAction.getNew(pref, null, null, "MAKECALL, detected event disconnect.com.cisco.handoff, call ID <" + id + ">", false));
                        ev_disc_4.addItem(1, ev_submit);
                        vxml.add(ev_disc_4);

                        event_name = "telephone.disconnect";
                        VEvent ev_disc_5 = VEvent.getNew(pref, event_name);
                        ev_disc_5.addCount(1);
                        ev_disc_5.setReprompt(1, false);
                        ev_disc_5.addItem(1, VAction.getNew(pref, null, null, "MAKECALL, detected event disconnect.com.cisco.handoff, call ID <" + id + ">", false));
                        ev_disc_5.addItem(1, ev_submit);
                        vxml.add(ev_disc_5);

                        event_name = "disconnect";
                        VEvent ev_disc_6 = VEvent.getNew(pref, event_name);
                        ev_disc_6.addCount(1);
                        ev_disc_6.setReprompt(1, false);
                        ev_disc_6.addItem(1, VAction.getNew(pref, null, null, "MAKECALL, detected event disconnect.com.cisco.handoff, call ID <" + id + ">", false));
                        ev_disc_6.addItem(1, ev_submit);
                        vxml.add(ev_disc_6);

// Add main form which must be called "start"
// Add block containing setup actions before handing-off to TCL
                        
                        VForm handoff_form = VForm.getNew(pref, "start");
                        
                        VBlock handoff_init_blk = VBlock.getNew(pref);
                        VAction handoff_setup = VAction.getNew(pref, null, null, "MAKECALL, handing off to OBCALLREQ.TCL, call ID <" + id + ">", false);
                        handoff_init_blk.add(handoff_setup);
                        
                        handoff_form.add(handoff_init_blk);                        
                        
// Add TCL handoff block to pass the outbound call parameters to the VXML gateway

                        String handoff_argstr = "'dnis=" + dst + " cli=" + cli + " rna=" + rna + " id=" + id + " uui=\"" + uui + "\"'";
                        
                        VObject handoff_obj = VObject.getNew(pref, "obcallreq", "builtin://com.cisco.callhandoff", null);
//                        handoff_obj.addParam("return", "true", true);
                        handoff_obj.addParam("return", "true", true);
                        handoff_obj.addParam("app-uri", "'builtin://cvp_obcallreq'", true);
                        handoff_obj.addParam("arg-string", handoff_argstr, true);
                        handoff_obj.setOutsideSubmit(false);
                        handoff_form.add(handoff_obj);

// Add block to handle and submit the call outcome following return from TCL back to VXML

                        VBlock handoff_complete_blk = VBlock.getNew(pref);
                        
                        VAction handoff_submit = VAction.getNew(pref, null, null, "MAKECALL, returned from TCL, call ID <" + id + ">", false);
                        handoff_submit.add(VAction.VARIABLE, "call_outcome", "obcallreq.argstring", false);
                        handoff_submit.add(submit_action);

                        handoff_complete_blk.add(handoff_submit);
                        handoff_form.add(handoff_complete_blk);
                        vxml.add(handoff_form);

                        ved.setScratchData("setup_sent", true);
                        
                        return null;
                }
                else
                {
                    
// This is the second interation through this method so process the makecall outcome passed back on
// the VXML submit. Map the call outcome to the correct element exit-state and set the actual outcome
// returned as element data. 
                    
                        String exit_state;
                        String call_outcome = (String) reqParameters.get("call_outcome");

                        if (call_outcome == null) call_outcome = "unknown";
                        ved.setElementData("result", call_outcome, VoiceElementData.PD_STRING, true);

                        if (call_outcome.equals("connected") ||
                                 call_outcome.equals("busy") ||
                                 call_outcome.equals("invalid_number") ||
                                 call_outcome.equals("noanswer"))

                        {
                                exit_state = call_outcome;
                        }
                        else
                        {
                                exit_state = "failed";
                        }
                        
                        return exit_state;
                }
        }
}        