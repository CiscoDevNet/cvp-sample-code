import javax.naming.*;
import java.sql.*;
import javax.sql.*;

import com.audium.server.AudiumException;
import com.audium.server.voiceElement.*;
import com.audium.server.session.ActionElementData;
import com.audium.server.xml.ActionElementConfig;

/**
 * @author Audium
 *
 * Retrieves the account balance associated with an account ID.
 * 
 * The account ID is stored in session data, and the location (variable name) 
 * of it is configurable.  Additionally, all database settings are fully 
 * configurable.
 */
public class CPCRetrieveBalance
	extends ActionElementBase
	implements ElementInterface {
		
	// Control flow for this action element starts here			
	public void doAction(String name, ActionElementData actionData)
		throws AudiumException {
		// init
		String balance = "";

		// acquire values from configuration
		ActionElementConfig config = actionData.getActionElementConfig();
		String JNDIDBName = config.getSettingValue("JNDIDBName", actionData);
		String tableName = config.getSettingValue("TableName", actionData);
		String accountIDColumn =
			config.getSettingValue("AccountIDColumn", actionData);
		String balanceColumn =
			config.getSettingValue("BalanceColumn", actionData);
		String accountIDvar =
			config.getSettingValue("AccountIDVar", actionData);

		// find the account ID from session data
		String accountID = (String) (actionData.getSessionData(accountIDvar));

		try {
			// create a context
			Context ctx = new InitialContext();
			if (ctx == null)
				throw new AudiumException("No context, unable to attempt DB connection.");

			// acquire ref to datasource (via JNDI)
			DataSource datasource = (DataSource) ctx.lookup(JNDIDBName);

			if (datasource != null) {
				// connect to the DB
				Connection connection = datasource.getConnection();

				if (connection != null) {
					// create a statement to query the DB with
					Statement statement = connection.createStatement();

					// construct query
					String queryString =
						"select "
							+ balanceColumn
							+ " from "
							+ tableName
							+ " where "
							+ accountIDColumn
							+ "=\""
							+ accountID
							+ "\";";

					// execute the query
					ResultSet result = statement.executeQuery(queryString);
					result.next();
					// move cursor to the only row in the result set
					balance = result.getString(balanceColumn);

					// close the DB connection
					connection.close();
				} else // unable to connect to DB
					throw new AudiumException("DB connection failed.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AudiumException("Unknown exception in CPCRetrieveBalance, see log for stack trace.");
		}

		// store the balance in this element
		actionData.setElementData(
			"value",
			balance,
			ActionElementData.PD_STRING,
			true);
	}

	/* The following three methods are required for custom configurable elements.
	 * They simply return a string.
	 */
	public String getElementName() {
		return "RetrieveBalance";
	}

	public String getDescription() {
		return "Given database settings and an Account ID, retrieves the balance for that account.";
	}

	public String getDisplayFolderName() {
		return "Account";
	}

	/* This method is currently unused by Audium Studio, but it is good practice
	 * to include it, since newer releases of Studio may make use of it.  See the
	 * Programmer Guide or Audium API Javadocs for more information.
	 */
	public ElementData[] getElementData() throws ElementException {
		// create the element data definitions
		ElementData[] elementData = new ElementData[1];
		elementData[0] =
			new ElementData("value", "The balance of the account specified.");

		return elementData;
	}

	/* This is where the configurable settings are defined for this custom 
	 * configurable element.
	 */
	public Setting[] getSettings() throws ElementException {
		// init
		Setting[] settings = new Setting[5];

		// create the setting definitions	
		settings[0] =
			new Setting(
				"JNDIDBName",
				"JNDI DB Name",
				"The JNDI name of the database to access.",
				true,
				true,
				true,
				Setting.STRING);
		settings[1] =
			new Setting(
				"TableName",
				"Table Name",
				"The name of the table within the database where customer data is stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[2] =
			new Setting(
				"AccountIDColumn",
				"AccountID Column",
				"The name of the column in the table where AccountIDs are stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[3] =
			new Setting(
				"BalanceColumn",
				"Balance Column",
				"The name of the column in the table where balances are stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[4] =
			new Setting(
				"AccountIDVar",
				"AccountID Session Var",
				"The name of the session variable holding the Account ID.",
				true,
				true,
				true,
				Setting.STRING);

		return settings;
	}
}
