import java.util.Random;
import javax.naming.*;
import java.sql.*;
import javax.sql.*;

import com.audium.server.AudiumException;
import com.audium.server.session.ActionElementData;
import com.audium.server.voiceElement.ActionElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.xml.ActionElementConfig;

/**
 * @author Audium
 *
 * Generates a random 10-digit ID that does not already exist in the customer DB.  Adds
 * a new row to the table, assigns this new row the random ID, and a random PIN.  Stores
 * new account ID in element data "AccountID", stores new PIN in element data "PIN".
 * 
 * Requires JNDI DB name, table name, and account ID column name as configuration.
 * Requires a DB table exist, with only four columns; the first is a unique key (not account ID),
 * the second is the account ID, the third is the pin, and the fourth is the balance.
 * While column order is important, the column names are not pre-determined, and are specified 
 * in the configuration.
 * 
 * The unique key is never used in this application, but is present as a best practice.  
 * There may be future situations where a unique key is needed for each user (e.g. a 
 * new feature where each user can have multiple accounts).
 * 
 * The column order is important because this class sets default values when a
 * new account is created, and it assumes the presence (and order) of the 4 columns.
 */
public class CPCCreateAccount
	extends ActionElementBase
	implements ElementInterface {

	// Control flow for this action element starts here			
	public void doAction(String name, ActionElementData actionData)
		throws AudiumException {
		// init
		String newID = "";
		String newPIN = "";
		boolean newIDExistsInDB = true;

		// acquire values from configuration
		ActionElementConfig config = actionData.getActionElementConfig();
		String JNDIDBName = config.getSettingValue("JNDIDBName", actionData);
		String tableName = config.getSettingValue("TableName", actionData);
		String accountIDColumn =
			config.getSettingValue("AccountIDColumn", actionData);

		while (newIDExistsInDB) {
			// construct the ID
			Random generator = new Random();
			for (int i = 0; i < 10; i++)
				newID = newID + generator.nextInt(10);

			// construct the default PIN
			for (int i = 0; i < 4; i++)
				newPIN = newPIN + generator.nextInt(10);

			// check the DB to see if this ID exists yet
			try {
				// create a context
				Context ctx = new InitialContext();
				if (ctx == null)
					throw new AudiumException("No context, unable to attempt DB connection.");

				// acquire ref to datasource (via JNDI)
				DataSource datasource = (DataSource) ctx.lookup(JNDIDBName);

				if (datasource != null) {
					// connect to the DB
					Connection connection = datasource.getConnection();

					if (connection != null) {
						// create a statement to query the DB with
						Statement statement = connection.createStatement();

						// construct the query
						String queryString = "";
						queryString =
							"select "
								+ accountIDColumn
								+ " from "
								+ tableName
								+ " where "
								+ accountIDColumn
								+ " = \""
								+ newID
								+ "\";";

						// create a resultset, fill it with query result	
						ResultSet resultSet =
							statement.executeQuery(queryString);

						// if the resultset is empty, this new ID doesn't exist yet
						if (!resultSet.next())
							newIDExistsInDB = false;
						else
							// otherwise try new ID, this one already exists in DB						
							continue;

						// add a new row to the table 
						if (!newIDExistsInDB) {
							// construct update command
							String updateString = "";
							updateString =
								"insert into "
									+ tableName
									+ " values (null, \""
									+ newID
									+ "\", "
									+ "\""
									+ newPIN
									+ "\", \"0.00\");";

							// execute the update
							statement.executeUpdate(updateString);
						}
					} else // unable to connect to DB
						throw new AudiumException("DB connection failed.");

					// close the DB connection
					connection.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new AudiumException("Unknown exception in CPCCreateAccount, see log for stack trace.");
			}
		}

		// store the new ID in this element
		actionData.setElementData(
			"AccountID",
			newID,
			ActionElementData.PD_STRING,
			true);

		// store the new PIN in this element
		actionData.setElementData(
			"PIN",
			newPIN,
			ActionElementData.PD_STRING,
			false);	// don't log PINs, security risk
	}

	/* The following three methods are required for custom configurable elements.
	 * They simply return a string.
	 */
	public String getElementName() {
		return "CreateAccount";
	}

	public String getDescription() {
		return "Given database settings, creates a new table row with a random ID and PIN.";
	}

	public String getDisplayFolderName() {
		return "Account";
	}

	/* This method is currently unused by Audium Studio, but it is good practice
	 * to include it, since newer releases of Studio may make use of it.  See the
	 * Programmer Guide or Audium API Javadocs for more information.
	 */
	public ElementData[] getElementData() throws ElementException {
		// create the element data definitions
		ElementData[] elementData = new ElementData[2];
		elementData[0] =
			new ElementData(
				"AccountID",
				"The new AccountID that this element generates and stores in the DB.");
		elementData[1] =
			new ElementData(
				"PIN",
				"The new PIN that this element generates and stores in the DB.");

		return elementData;
	}

	/* This is where the configurable settings are defined for this custom 
	 * configurable element.
	 */
	public Setting[] getSettings() throws ElementException {
		// init
		Setting[] settings = new Setting[3];

		// create the setting definitions	
		settings[0] =
			new Setting(
				"JNDIDBName",
				"JNDI DB Name",
				"The JNDI name of the database to access.",
				true,
				true,
				true,
				Setting.STRING);
		settings[1] =
			new Setting(
				"TableName",
				"Table Name",
				"The name of the table within the database where customer data is stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[2] =
			new Setting(
				"AccountIDColumn",
				"AccountID Column",
				"The name of the column in the table where AccountIDs are stored.",
				true,
				true,
				true,
				Setting.STRING);

		return settings;
	}
}
