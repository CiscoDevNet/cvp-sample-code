import javax.naming.*;
import java.sql.*;
import javax.sql.*;

import com.audium.server.AudiumException;
import com.audium.server.session.DecisionElementData;
import com.audium.server.voiceElement.*;
import com.audium.server.xml.DecisionElementConfig;

/**
 * @author Audium
 *
 * Verifies if the account ID and PIN the user has provided (earlier in the
 * call flow) match up in the database.
 * 
 * The account ID is stored in session data, the PIN is stored in element data,
 * and the locations of both are fully configurable.  Additionally, all database
 * settings are fully configurable.
 */
public class CPCValidateLogin
	extends DecisionElementBase
	implements ElementInterface {

	// Control flow for this decision element starts here
	public String doDecision(String arg0, DecisionElementData decisionData)
		throws AudiumException {
		// init exit value to default
		String exitValue = "LoginFail";

		// acquire values from configuration
		DecisionElementConfig config = decisionData.getDecisionElementConfig();
		String JNDIDBName = config.getSettingValue("JNDIDBName", decisionData);
		String tableName = config.getSettingValue("TableName", decisionData);
		String accountIDColumn =
			config.getSettingValue("AccountIDColumn", decisionData);
		String PINColumn = config.getSettingValue("PINColumn", decisionData);
		String accountIDvar =
			config.getSettingValue("AccountIDVar", decisionData);
		String elementWithPIN =
			config.getSettingValue("ElementWithPIN", decisionData);
		String PINVariable =
			config.getSettingValue("PINVariable", decisionData);

		// get the account ID from session data
		String accountID = (String) (decisionData.getSessionData(accountIDvar));

		// get the PIN from element data
		String PIN =
			(String) (decisionData.getElementData(elementWithPIN, PINVariable));

		try {
			// create a context
			Context ctx = new InitialContext();
			if (ctx == null)
				throw new AudiumException("No context, unable to attempt DB connection.");

			// acquire ref to datasource (via JNDI)
			DataSource datasource = (DataSource) ctx.lookup(JNDIDBName);

			if (datasource != null) {
				// connect to the DB
				Connection connection = datasource.getConnection();

				if (connection != null) {
					// create a statement to query the DB with
					Statement statement = connection.createStatement();

					// construct query
					String queryString =
						"select "
							+ accountIDColumn
							+ " from "
							+ tableName
							+ " where "
							+ accountIDColumn
							+ "=\""
							+ accountID
							+ "\" and "
							+ PINColumn
							+ "=\""
							+ PIN
							+ "\";";

					// execute the query
					ResultSet result = statement.executeQuery(queryString);

					// does this account exist?
					if (result.next())
						exitValue = "LoginOK";

					// close the DB connection
					connection.close();
				} else // unable to connect to DB
					throw new AudiumException("DB connection failed.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AudiumException("Unknown exception in CPCValidateLogin, see log for stack trace.");
		}

		return exitValue;
	}

	/* The following three methods are required for custom configurable elements.
	 * They simply return a string.
	 */
	public String getElementName() {
		return "ValidateLogin";
	}

	public String getDescription() {
		return "Given database settings, an Account ID and PIN, checks if this is a valid login.";
	}

	public String getDisplayFolderName() {
		return "Account";
	}

	/* This method is currently unused by Audium Studio, but it is good practice
	 * to include it, since newer releases of Studio may make use of it.  See the
	 * Programmer Guide or Audium API Javadocs for more information.
	 */
	public ElementData[] getElementData() throws ElementException {
		return null; // does not create any element data
	}

	/* This is where the configurable settings are defined for this custom 
	 * configurable element.
	 */
	public Setting[] getSettings() throws ElementException {
		// init
		Setting[] settings = new Setting[7];

		// create the setting definitions	
		settings[0] =
			new Setting(
				"JNDIDBName",
				"JNDI DB Name",
				"The JNDI name of the database to access.",
				true,
				true,
				true,
				Setting.STRING);
		settings[1] =
			new Setting(
				"TableName",
				"Table Name",
				"The name of the table within the database where customer data is stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[2] =
			new Setting(
				"AccountIDColumn",
				"AccountID Column",
				"The name of the column in the table where AccountIDs are stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[3] =
			new Setting(
				"PINColumn",
				"PIN Column",
				"The name of the column in the table where PINs are stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[4] =
			new Setting(
				"AccountIDVar",
				"AccountID Session Var",
				"The name of the session variable holding the Account ID.",
				true,
				true,
				true,
				Setting.STRING);
		settings[5] =
			new Setting(
				"ElementWithPIN",
				"Element With PIN",
				"The name of the element that is holding the PIN in a variable.",
				true,
				true,
				true,
				Setting.STRING);
		settings[6] =
			new Setting(
				"PINVariable",
				"PIN Variable",
				"The name of the variable holding the PIN.",
				true,
				true,
				true,
				Setting.STRING);

		return settings;
	}

	/* Since this is a custom configurable decision element (as opposed to an
	 * action element), this method must be defined to return the exit states
	 * this element has. 
	 */
	public ExitState[] getExitStates() {
		ExitState[] exitStates = new ExitState[2];

		exitStates[0] =
			new ExitState(
				"LoginFail",
				"LoginFail",
				"The login attempt with the provided account ID and PIN failed.");
		exitStates[1] =
			new ExitState(
				"LoginOK",
				"LoginOK",
				"The login attempt with the provided account ID and PIN succeeded.");

		return exitStates;
	}
}
