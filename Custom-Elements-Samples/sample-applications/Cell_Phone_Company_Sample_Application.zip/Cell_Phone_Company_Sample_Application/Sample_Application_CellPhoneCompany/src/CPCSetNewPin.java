import javax.naming.*;
import java.sql.*;
import javax.sql.*;

import com.audium.server.AudiumException;
import com.audium.server.voiceElement.*;
import com.audium.server.session.ActionElementData;
import com.audium.server.xml.ActionElementConfig;

/**
 * @author Audium
 *
 * Assigns user-selected PIN to user's Account ID in database.
 * 
 * The account ID is stored in session data, the PIN is stored in element data,
 * and the locations of both are fully configurable.  Additionally, all database
 * settings are fully configurable.
 */
public class CPCSetNewPin
	extends ActionElementBase
	implements ElementInterface {

	// Control flow for this action element starts here		
	public void doAction(String name, ActionElementData actionData)
		throws AudiumException {
		// acquire values from configuration
		ActionElementConfig config = actionData.getActionElementConfig();
		String JNDIDBName = config.getSettingValue("JNDIDBName", actionData);
		String tableName = config.getSettingValue("TableName", actionData);
		String accountIDColumn =
			config.getSettingValue("AccountIDColumn", actionData);
		String PINColumn = config.getSettingValue("PINColumn", actionData);
		String accountIDvar =
			config.getSettingValue("AccountIDVar", actionData);
		String elementWithPIN =
			config.getSettingValue("ElementWithPIN", actionData);
		String PINVariable = config.getSettingValue("PINVariable", actionData);

		// find the new PIN
		String newPIN =
			(String) (actionData.getElementData(elementWithPIN, PINVariable));

		try {
			// create a context
			Context ctx = new InitialContext();
			if (ctx == null)
				throw new AudiumException("No context, unable to attempt DB connection.");

			// acquire ref to datasource (via JNDI)
			DataSource datasource = (DataSource) ctx.lookup(JNDIDBName);

			if (datasource != null) {
				// connect to the DB
				Connection connection = datasource.getConnection();

				if (connection != null) {
					// create a statement to query the DB with
					Statement statement = connection.createStatement();

					// construct update command
					String accountID =
						(String) (actionData.getSessionData("AccountID"));
					String updateString = "";
					updateString =
						"update "
							+ tableName
							+ " set "
							+ PINColumn
							+ " = \""
							+ newPIN
							+ "\" where "
							+ accountIDColumn
							+ " = \""
							+ accountID
							+ "\";";

					// execute the update
					statement.executeUpdate(updateString);

					// close the DB connection
					connection.close();
				} else // unable to connect to DB
					throw new AudiumException("DB connection failed.");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new AudiumException("Unknown exception in CPCSetNewPIN, see log for stack trace.");
		}
	}

	/* The following three methods are required for custom configurable elements.
	 * They simply return a string.
	 */
	public String getElementName() {
		return "SetNewPin";
	}

	public String getDescription() {
		return "Given database settings and an Account ID, sets the PIN for that account.";
	}

	public String getDisplayFolderName() {
		return "Account";
	}

	/* This method is currently unused by Audium Studio, but it is good practice
	 * to include it, since newer releases of Studio may make use of it.  See the
	 * Programmer Guide or Audium API Javadocs for more information.
	 */
	public ElementData[] getElementData() throws ElementException {
		return null; // does not create any element data
	}

	/* This is where the configurable settings are defined for this custom 
	 * configurable element.
	 */
	public Setting[] getSettings() throws ElementException {
		// init
		Setting[] settings = new Setting[7];

		// create the setting definitions	
		settings[0] =
			new Setting(
				"JNDIDBName",
				"JNDI DB Name",
				"The JNDI name of the database to access.",
				true,
				true,
				true,
				Setting.STRING);
		settings[1] =
			new Setting(
				"TableName",
				"Table Name",
				"The name of the table within the database where customer data is stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[2] =
			new Setting(
				"AccountIDColumn",
				"AccountID Column",
				"The name of the column in the table where AccountIDs are stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[3] =
			new Setting(
				"PINColumn",
				"PIN Column",
				"The name of the column in the table where PINs are stored.",
				true,
				true,
				true,
				Setting.STRING);
		settings[4] =
			new Setting(
				"AccountIDVar",
				"AccountID Session Var",
				"The name of the session variable holding the Account ID.",
				true,
				true,
				true,
				Setting.STRING);
		settings[5] =
			new Setting(
				"ElementWithPIN",
				"Element With PIN",
				"The name of the element that is holding the new PIN in a variable.",
				true,
				true,
				true,
				Setting.STRING);
		settings[6] =
			new Setting(
				"PINVariable",
				"PIN Variable",
				"The name of the variable holding the PIN.",
				true,
				true,
				true,
				Setting.STRING);

		return settings;
	}
}