import com.audium.server.AudiumException;
import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.session.ElementAPI;
import com.audium.server.session.ReadOnlyList;
import com.audium.server.xml.VoiceElementConfig;

/* *************************************************************************************************
 * HOLLYWOODHOTEL - Advanced Sample Application
 * Class: TransferCallConfig
 * 
 * This class is used to dynamically configure the Transfer element to say that the caller 
 * is about to be transferred to <the name of the chosen celebrity> before performing the transfer.
 * 
 * NOTE: This class is slightly different from the TransferCallConfig class used in
 * part 3 of HollywoodHotel.  It has only one place to look for the name the caller chose.
 ************************************************************************************************* */
public class TransferCallConfig implements VoiceElementInterface {

	public VoiceElementConfig getConfig(
		String arg0,
		ElementAPI elementAPI,
		VoiceElementConfig defaults)
		throws AudiumException {

		// get a reference to the initial audio group of this element
		VoiceElementConfig.AudioGroup initial =
			defaults.getAudioGroup("initial_audio_group", 1);

		// store the element history in a read-only list
		ReadOnlyList rol = elementAPI.getElementHistory();

		// the first audio item in the initial audio group is configured to say "I am tranferring you to";
		// the code below adds the name of the person the caller chose as a new audio item. 

		// if the element data named "value" of the previous element is "yes" then set audioItem 
		// to session data named "choice1"  
		String audioItem =
			elementAPI.getElementData(
				rol.get(rol.size() - 2),
				"value").equalsIgnoreCase(
				"yes")
				? (String) elementAPI.getSessionData("choice1")
				: elementAPI.getElementData(rol.get(rol.size() - 2), "value");
		initial.addAudioItem(defaults.new StaticAudio(audioItem, ""));
		
		return defaults;
	}

}
