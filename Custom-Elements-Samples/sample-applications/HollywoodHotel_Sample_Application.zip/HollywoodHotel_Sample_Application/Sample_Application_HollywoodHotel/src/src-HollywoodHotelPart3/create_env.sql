CREATE DATABASE IF NOT EXISTS HollywoodHotel;

CREATE TABLE HollywoodHotel.guests  (id INT AUTO_INCREMENT PRIMARY KEY, 
				     first VARCHAR(20), 
				     last VARCHAR(20), 
				     utterance VARCHAR(40));

GRANT ALL PRIVILEGES ON HollywoodHotel.* TO caller@localhost.localdomain IDENTIFIED BY 'caller';

INSERT INTO HollywoodHotel.guests VALUES (NULL,"monica","bellucci","");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"marlon","brando","godfather");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"kevin","spacey","kevin spacey");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"orlando","bloom","orlando bloom");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"michael","douglas","michael douglas");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"michael","caine","michael caine");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"kiefer","sutherland","kiefer sutherland");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"donald","sutherland","donald sutherland");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"prince","","");
INSERT INTO HollywoodHotel.guests VALUES (NULL,"","pink","");
