import com.audium.server.AudiumException;
import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.session.ElementAPI;
import com.audium.server.session.ReadOnlyList;
import com.audium.server.xml.VoiceElementConfig;

/* *************************************************************************************************
 * HOLLYWOODHOTEL - Advanced Sample Application
 * Class: TransferCallConfig
 * 
 * This class is used to dynamically configure the Transfer element to say that the caller 
 * is about to be transferred to <the name of the chosen celebrity> before performing the transfer.
 * 
 * NOTE: This class is slightly different from the TransferCallConfig class used in
 * part 2 of HollywoodHotel.  It has two places to look for the name the caller chose.
 ************************************************************************************************* */
public class TransferCallConfig implements VoiceElementInterface {

	public VoiceElementConfig getConfig(
		String arg0,
		ElementAPI elementAPI,
		VoiceElementConfig defaults)
		throws AudiumException {

		// get a reference to the initial audio group of this element
		VoiceElementConfig.AudioGroup initial =
			defaults.getAudioGroup("initial_audio_group", 1);

		// store the element history in a read-only list
		ReadOnlyList rol = elementAPI.getElementHistory();

		// the first audio item in the initial audio group is configured to say "I am tranferring you to";
		// the code below adds the name of the person the caller chose as a new audio item. 

		// if the element visited just before this one was "ConfirmChoice"...
		if ("ConfirmChoice".equalsIgnoreCase(rol.get(rol.size() - 2))) {
			// add an audio item to the initial audio group with the session data "choice1" (celeb's name)
			initial.addAudioItem(
				defaults.new StaticAudio(
					(String) elementAPI.getSessionData("choice1"),
					""));
			// otherwise...
		} else {
			// add an audio item to the initial audio group with the element data "value" from 
			// the element visited just before this one (either "SpecifyPerson" or "MoreThanOne")
			initial.addAudioItem(
				defaults.new StaticAudio(
					(String) elementAPI.getElementData(
						rol.get(rol.size() - 2),
						"value"),
					""));
		}

		return defaults;
	}
}
