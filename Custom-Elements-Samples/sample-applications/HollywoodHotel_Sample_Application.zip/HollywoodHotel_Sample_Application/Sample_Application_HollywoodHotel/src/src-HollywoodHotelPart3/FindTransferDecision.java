import com.audium.server.AudiumException;
import com.audium.server.session.DecisionElementData;
import com.audium.server.voiceElement.DecisionElementBase;

/* ********************************************************************************************
 * HOLLYWOODHOTEL - Advanced Sample Application 
 * Class: FindTransferDecision
 * 
 * This class powers a Decision element.  The Decision element needs to decide if a
 * name that the caller uttered was an exact match, unclear, or close but needs confirmation
 * when compared to a list of names in the grammar.  It examines the 2 best matches for
 * what the user uttered, and uses the confidence in these matches to decide which
 * exit state to follow (exact_match, unclear, or make_sure, more_than_one).
 * 
 * NOTE: This class is slightly different from the FindTransferDecision class used in
 * HollywoodHotelPart2.  This class allows for the possibility of two similar names,
 * and exits as more_than_one to find out which name the caller meant.
 ******************************************************************************************** */
public class FindTransferDecision extends DecisionElementBase {

	public String doDecision(String arg0, DecisionElementData element)
		throws AudiumException {
		// init the return value
		String transfer = "unclear";

		// set expr1 to the best interpretation the form ChoosePerson found (e.g. "+first1:michael+last1:douglas")
		String expr1 =
			element.getElementData("ChoosePerson", "nbestInterpretation1");

		// set expr2 to the second best interpretation the form ChoosePerson found (e.g. "+first2:michael+last2:caine")
		String expr2 =
			element.getElementData("ChoosePerson", "nbestInterpretation2");

		// init the var to be used to store the confidence in the best match
		int conf1 = 0;

		// init the var to be used to store the confidence in the second best match
		int conf2 = 0;

		// set utt1 to the best utterance the form ChoosePerson found (e.g. "michael douglas")
		String utt1 = element.getElementData("ChoosePerson", "nbestUtterance1");

		// attempt to turn the confidence values for the best and second best matches into ints, and store
		try {
			conf1 =
				Integer.parseInt(
					(
						element.getElementData(
							"ChoosePerson",
							"nbestConfidence1")).substring(
						2,
						4));
			conf2 =
				Integer.parseInt(
					(
						element.getElementData(
							"ChoosePerson",
							"nbestConfidence2")).substring(
						2,
						4));
		} catch (Exception ignore) {
		}

		// if the confidence in the best match is less than 40, return "unclear" (a hardcoded nomatch)
		if (conf1 < 40) {
			return "unclear";
		}

		// If the best interpretation is "ambiguous", we know that there must be more 
		// than one person with this name-fragment.  This works because of the way we generate the
		// grammar in sg_grammar.jsp; cases where different full names have a matching first or 
		// last name result in a special entry in the grammar for the common name-fragment that 
		// includes only a single slot: ambiguous='ambiguous'.  
		if (expr1.equalsIgnoreCase("ambiguous")) {
			element.setElementData("value", utt1);
			
			transfer = "more_than_one";
		} else {
			// the name the caller uttered is an exact match for only one name in the DB,
			// set it as session data as "choice1"
			element.setSessionData(
				"choice1",
				parseFirst(expr1) + " " + parseLast(expr1));

			// set it in this element's data as "value"
			element.setElementData(
				"value",
				parseFirst(expr1) + " " + parseLast(expr1));

			transfer = "exact_match";

			// although this is considered an exact match, if we have a 2nd best interpretation...
			if (expr2 != null) {
				// store the 2nd interpretation in session data as "choice2"
				element.setSessionData(
					"choice2",
					parseFirst(expr2) + " " + parseLast(expr2));
				// Look at the confidence levels, and possibly cancel our previous "exact_match"
				if ((conf1 > 95) || (conf2 < 5)) {
					transfer = "exact_match";
				} else {
					transfer = "make_sure";
				}
			} else {
				// there was no 2nd best interpretation, so set the value of session variable
				// "choice2" to an empty string
				element.setSessionData("choice2", "");
			}
		}

		// return the exit state
		return transfer;
	}

	// extracts the first-name portion of an interpretation
	private String parseFirst(String str) {

		if (str.indexOf(":") > 0) {
			str = str.substring(str.indexOf(":") + 1, str.indexOf("last") - 1);
		} else if (str.indexOf("=") > 0) {
			str = str.substring(str.indexOf("=") + 1, str.indexOf("last") - 1);
		}

		if (str.startsWith("'")) {
			str = str.substring(1, str.lastIndexOf("'"));
		}

		return str;
	}

	// extracts the last-name portion of an interpretation
	private String parseLast(String str) {

		if (str.indexOf(":") > 0) {
			str = str.substring(str.lastIndexOf(":") + 1);
		} else if (str.indexOf("=") > 0) {
			str = str.substring(str.lastIndexOf("=") + 1);
		}

		return str;
	}

}
