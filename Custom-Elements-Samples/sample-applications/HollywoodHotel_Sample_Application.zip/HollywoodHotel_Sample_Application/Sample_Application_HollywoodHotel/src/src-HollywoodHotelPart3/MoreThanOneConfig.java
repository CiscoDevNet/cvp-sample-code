import com.audium.server.AudiumException;
import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.session.ElementAPI;
import com.audium.server.xml.VoiceElementConfig;
import java.sql.*;

/* **********************************************************************
 * HOLLYWOODHOTEL - Advanced Sample Application
 * Class: MoreThanOneConfig
 * 
 * This class dynamically configures an element.  It finds a list of 
 * names from the DB that have a first or last name that matches the
 * best result stored in the ChoosePerson element.  If this 
 * element is reached, it is because the best result is ambiguous 
 * and may refer to several names in the DB (e.g. it holds "michael" and 
 * there are 2 Michaels in the DB).  Once the list of possible matches is
 * constructed, this class configures the element to prompt the user to 
 * clarify which name from the possibilities they meant.
 ********************************************************************** */
public class MoreThanOneConfig implements VoiceElementInterface {

	public VoiceElementConfig getConfig(
		String arg0,
		ElementAPI elementAPI,
		VoiceElementConfig defaults)
		throws AudiumException {

		// obtain a reference to this element's initial audio group's first audio item
		VoiceElementConfig.AudioGroup initial =
			defaults.getAudioGroup("initial_audio_group", 1);

		// sets person to the ambiguous name fragment stored in FindTransferDecision's element data
		String person = elementAPI.getElementData("FindTransfer", "value");

		try {
			// load the jdbc driver
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			// establish a db connection, and store a reference to it
			java.sql.Connection con =
				DriverManager.getConnection(
					"jdbc:mysql://localhost/HollywoodHotel?user=caller&password=caller");

			// get a reference to a new database statement
			Statement stmt = con.createStatement();

			// use the statement to execute a database query (find people in db who have the colName ("first" or "last")
			// that equals person (either a first or last name)), and store the result set in rset (i.e. find 
			// people in the db who the caller may have been trying to refer to)
			ResultSet rset =
				stmt.executeQuery(
					"SELECT DISTINCT * FROM guests WHERE first = '"
						+ person
						+ "'"
						+ " OR last = '"
						+ person
						+ "'");
						 
			// init counter used to keep track of which result set row is currently selected
			int i = 0;
			
			// attempt to select the next row in the result set, and if possible...
			while (rset.next()) {
				// if it's not the case that the column named "last" in the selected row is empty
				if (!rset.getString("last").equals("")) {
					// keep track of which result set row is currently selected
					i++;

					// add another setting to this element's configuration named "voice_keyword" (an in-line grammar),
					// and set its value to the first and last name from this row in the result set
					defaults.addSettingValue(
						"voice_keyword",
						rset.getString("first") + " " + rset.getString("last"));

					// add an audio item (TTS) to the initial audio group of this element, containing the first
					// and last name from this row in the result set
					initial.addAudioItem(
						defaults.new StaticAudio(
							rset.getString("first")
								+ " "
								+ rset.getString("last"),
							""));

					// every other row (starting with the first row, i==1), add an audio item (TTS) to the 
					// initial audio group with the text "or"
					if ((i % 2) != 0) {
						initial.addAudioItem(
							defaults.new StaticAudio(" or ", ""));
					}
				}
			}
		} catch (Exception ignore) {
			ignore.printStackTrace();
		}

		return defaults;
	}
}