import com.audium.server.proxy.*;
import com.audium.server.session.*;
import com.audium.server.session.user.*;
import com.audium.server.voiceElement.*;
import com.audium.server.*;
import com.audium.server.xml.*;

import java.util.*;

/**
 * This class creates teh dynamic configuration for the TransferFrom voice element.
 * This element's configuration is dynamic only because it needs to specify an inline
 * grammar containing only the caller's different accounts. This class takes the base
 * configuration specified in the Builder and adds keywords to the inline speech
 * grammar for each account.
 */
public class TransferFrom implements VoiceElementInterface 
{
    public VoiceElementConfig getConfig(java.lang.String name, 
										ElementAPI elementAPI, 
										VoiceElementConfig defaults)
										throws AudiumException 
	{
		/* The "voice_keyword" setting is repeatable so the dynamic configuration
		can simply add as many setting values as necessary. */
		if (elementAPI.getSessionData("checkingBalance") != null) {
			defaults.addSettingValue("voice_keyword", "checking");
		}
		if (elementAPI.getSessionData("savingsBalance") != null) {
			defaults.addSettingValue("voice_keyword", "savings");
		}
		if (elementAPI.getSessionData("mmBalance") != null) {
			defaults.addSettingValue("voice_keyword", "money market");
		}
	    return defaults;
    }
}

