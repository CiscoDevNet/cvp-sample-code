import com.audium.server.proxy.*;
import com.audium.server.session.*;
import com.audium.server.session.user.*;
import com.audium.server.AudiumException;
import com.audium.server.session.*;
import com.audium.server.voiceElement.ActionElementBase;
import java.util.*;

/**
 * This class is an action element that takes care of the transfer between
 * accounts. It stores the updated account balances and other information needed
 * to play back information to the caller. 
 */
public class DoTransfer extends ActionElementBase 
{
    public void doAction(java.lang.String name, ActionElementData actionAPI) throws AudiumException 
    {
    	/* Get the current user. */
		UserAPI userAPI = actionAPI.getUserAPI();
		User user = userAPI.getCurrentUser();
		
		/* Get the balances of all accounts (if applicable). */
		String checkingBalanceString = user.getCustom1();
		String savingsBalanceString = user.getCustom2();
		String mmBalanceString = user.getCustom3();
		
		float checkingBalance = -1.0f, savingsBalance = -1.0f, mmBalance = -1.0f;
		if (checkingBalanceString != null) {
			checkingBalance = Float.parseFloat(checkingBalanceString);
		}
		if (savingsBalanceString != null) {
			savingsBalance = Float.parseFloat(savingsBalanceString);
		}
		if (mmBalanceString != null) {
			mmBalance = Float.parseFloat(mmBalanceString);
		}
		
    	float transferAmount = Float.parseFloat(actionAPI.getElementData("TransferAmount", "value"));
    	String fromAccount = actionAPI.getElementData("TransferFrom", "value");
    	String toAccount = (String) actionAPI.getSessionData("transfer_to_account");
		
		/* Print out the transaction information. */
	    System.out.println("Transfer to account is:   " + toAccount);
	    System.out.println("Transfer from account is: " + fromAccount);
	    System.out.println("Transfer amount is:       " + transferAmount);
	    
		float fromAccountBalance, toAccountBalance;
		/* Now, calculate the final balances of the two accounts. */
		if (fromAccount.compareTo("checking") == 0) {
			checkingBalance -= transferAmount;
			checkingBalance = Math.round(checkingBalance * 100.0f)/100.0f;
			fromAccountBalance = checkingBalance;
		} else if (fromAccount.compareTo("savings") == 0) {
			savingsBalance -= transferAmount;
			savingsBalance = Math.round(savingsBalance * 100.0f)/100.0f;
			fromAccountBalance = savingsBalance;
		} else {
			mmBalance -= transferAmount;
			mmBalance = Math.round(mmBalance * 100.0f)/100.0f;
			fromAccountBalance = mmBalance;
		}
		
		if (toAccount.compareTo("checking") == 0) {
			checkingBalance += transferAmount;
			checkingBalance = Math.round(checkingBalance * 100.0f)/100.0f;
			toAccountBalance = checkingBalance;
		} else if (toAccount.compareTo("savings") == 0) {
			savingsBalance += transferAmount;
			savingsBalance = Math.round(savingsBalance * 100.0f)/100.0f;
			toAccountBalance = savingsBalance;
		} else {
			mmBalance += transferAmount;
			mmBalance = Math.round(mmBalance * 100.0f)/100.0f;
			toAccountBalance = mmBalance;
		}
		
    	/* Store these new balances for use by a future element. */
	    actionAPI.setSessionData("from_account_balance", Float.toString(fromAccountBalance));
	    actionAPI.setSessionData("to_account_balance", Float.toString(toAccountBalance));
	    
	    /* Update the User Management System to reflect the new balances to the accounts. */
	    if (checkingBalance != -1.0) {
	    	checkingBalanceString = Float.toString(checkingBalance);
			user.setCustom1(checkingBalanceString);
	    }
	    if (savingsBalance != -1.0) {
	    	savingsBalanceString = Float.toString(savingsBalance);
			user.setCustom2(savingsBalanceString);
	    }
	    if (mmBalance != -1.0) {
	    	mmBalanceString = Float.toString(mmBalance);
			user.setCustom3(mmBalanceString);
	    }
	    /* This method has to be called when making changes to the current user. If you recall, 
	    the current user's information is stored in a memory cache and when changes are made,
	    they remain in the cache. Calling the updateUser method stores the cached data back into 
	    the database. */ 
	    userAPI.updateUser(user);
	    
	    /* Print out more information. */
	    System.out.println("User internal checking account is: " + checkingBalanceString);
	    System.out.println("User internal savings account is: " + savingsBalanceString);
	    System.out.println("User internal mm account is: " + mmBalanceString);
	    
	    System.out.println("User checking account is: " + user.getCustom1());
	    System.out.println("User savings account is: " + user.getCustom2());
	    System.out.println("User mm account is: " + user.getCustom3());
	    
	    /* Store the final balances. */
	    actionAPI.setSessionData("checkingBalance", checkingBalanceString);
	    actionAPI.setSessionData("savingsBalance", savingsBalanceString);
	    actionAPI.setSessionData("mmBalance", mmBalanceString);
    }
}

