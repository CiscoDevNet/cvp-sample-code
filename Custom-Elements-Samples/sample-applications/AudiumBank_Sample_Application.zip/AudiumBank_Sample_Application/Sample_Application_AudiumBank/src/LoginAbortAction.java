import com.audium.server.proxy.*;
import com.audium.server.session.*;
import com.audium.server.controller.DirectoryStructure;
import com.audium.server.session.user.*;
import com.audium.server.AudiumException;
import com.audium.server.voiceElement.ActionElementBase;

import java.util.*;
import java.io.*;
import java.net.InetAddress;
import javax.mail.*;
import javax.mail.internet.*;

/**
 * This class deals with the action element that is called when a caller reaches
 * the maximum allowable incorrect logins. It simulates a security process by which
 * an administrator is contacted every time a caller maxes out their login. This could
 * be because their account is locked out and the admin must deal with manually
 * restoring their account, or other security procedure. Here, an e-mail is sent to
 * the administrator.
 */
public class LoginAbortAction extends ActionElementBase 
{
    private static final String CHECKING="checking";
    private static final String SAVINGS="savings";
    private static final String MONEY_MARKET="money market";
    public static final String TRANSFER_TO = "transferto";
    
    private static boolean hasErrors = false;    
    
    public void doAction(java.lang.String name, ActionElementData actionAPI) throws AudiumException 
    {
    	System.out.println("I am emailing the admin.");
		
		/* The information on where to e-mail the administrator is stored in a
		property file found in c:\temp\mail_properties.txt. This is obviously not
		a flexible design, and is presented only for demonstration purposes. The
		property file stores the SMTP host, the to address and the from address. */
		
		Properties properties = new Properties();
		try {
    		String mailPropFileName =  "c:"+ File.separator+ "temp"+ File.separator+ "mail_properties.txt";
	    	FileInputStream fis = new FileInputStream(new File(mailPropFileName));
	    	properties.load(fis);
	    	fis.close();
		}
		catch (Exception e) {
			/* If there is any exception, the exception is wrapped within an AudiumException
			which is caught by the Audium Server. Its error message will be printed in the 
			error log for the application. */
	    	throw new AudiumException(e.getMessage());
		}
		
		/* Write the e-mail message using Java Mail. */
		try	{
	    	String to = properties.getProperty("to");
	    	String from = properties.getProperty("from");
			    
	    	Session session = Session.getDefaultInstance(properties, null);
	    	session.setDebug(false);
	    	Message msg = new MimeMessage(session);
			    
	    	msg.setFrom(new InternetAddress(from));
	    	msg.setRecipients(Message.RecipientType.TO,
			    			  InternetAddress.parse(to, false));
	    	msg.setSubject("SECURITY ALERT: Failed login");
			    
	    	StringBuffer bmsg = new StringBuffer();
	    	bmsg.append("A caller failed to login after 3 tries\n\n");
	    	bmsg.append("******************************************\n\n");
	    	bmsg.append("ANI: " + actionAPI.getAni());
	    	bmsg.append("\n\nSessionId: " + actionAPI.getSessionId());
	    	bmsg.append("\n\nCall Start: " + actionAPI.getStartDate());
			
			/* For informational purposes, we want to show the element history
			in this e-mail. We get the element (and exit state) history from the API. */
	    	bmsg.append("\n\nHistory:\n\n ");
			    
	    	ReadOnlyList eh = actionAPI.getElementHistory();
	    	ReadOnlyList exh = actionAPI.getExitStateHistory();
			    
	    	for (int i=0; i<eh.size(); i++) {
				bmsg.append(eh.get(i));
				bmsg.append(":");
					
				/* The current entity does not have an exit state. */
				if (i != eh.size()-1) {
		    		bmsg.append(exh.get(i));
				}
				bmsg.append("\n");
	    	}
	    	msg.setText(bmsg.toString());
	    	msg.setHeader("X-Mailer", "AudiumBank");
	    	msg.setSentDate(new Date());
	    	Transport.send(msg);
	    } catch (Exception e) {
	    	throw new AudiumException(e.getMessage());
	    }
    }
}

