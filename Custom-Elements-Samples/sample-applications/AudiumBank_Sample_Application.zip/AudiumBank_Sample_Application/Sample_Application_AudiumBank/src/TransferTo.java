import com.audium.server.proxy.*;
import com.audium.server.session.*;
import com.audium.server.session.user.*;
import com.audium.server.voiceElement.*;
import com.audium.server.*;
import com.audium.server.xml.*;

import java.rmi.*;
import java.util.*;

/**
 * This class represents the dynamic configuration for the TransferTo voice element.
 * The element is dynamic because it needs to present the caller with the options for
 * the accounts they can transfer money to. The list of accounts is limited by (1) the
 * accounts the caller has, and (2) which account they chose to transfer money from.
 * The inline speech grammar is aseembled here appropriately. It also modifies some audio
 * items to reflect what choices of accounts there are. Remember, if the caller has only
 * two accounts, this element is skipped.
 */
public class TransferTo implements VoiceElementInterface 
{
    public VoiceElementConfig getConfig(java.lang.String name, 
										ElementAPI elementAPI, 
										VoiceElementConfig defaults)
										throws AudiumException 
	{
		boolean haveone = false;
		String accountChoices = "";
		VoiceElementConfig.AudioGroup initial = defaults.getAudioGroup("initial_audio_group", 1);
		
		/* The accounts to choose from to tranfer to must be the two accounts that were not
		being transfered from. For example, if the caller chose to transfer from checking, then
		the he only has a choice to transfer to savings and moneu market. */
		if (elementAPI.getSessionData("checkingBalance") != null && 
			((String)elementAPI.getElementData("TransferFrom", "value")).compareTo("checking")!=0) {
			defaults.addSettingValue("voice_keyword", "checking");
			
			accountChoices += "checking";
			haveone = true;
		}
		if (elementAPI.getSessionData("savingsBalance") != null && 
			((String)elementAPI.getElementData("TransferFrom", "value")).compareTo("savings")!=0) {
			defaults.addSettingValue("voice_keyword", "savings");
			
			if (haveone) {
				accountChoices += " or ";
			}
			accountChoices += "savings";
			haveone = true;
		}
		if (elementAPI.getSessionData("mmBalance") != null && 
			((String)elementAPI.getElementData("TransferFrom", "value")).compareTo("money market")!=0) {
			defaults.addSettingValue("voice_keyword", "money market");
			if (haveone) {
				accountChoices += " or ";
			}
			accountChoices += "money market";
		}
		/* The base configuration has created two audio items in the initial audio group, but
		we need to add more. We add an audio item that lists each account available (with an "or"
		in between them). We have to do the same thing for the noinput, nomatch, and help
		audio groups as well. */
		VoiceElementConfig.StaticAudio checkingAudio = defaults.new StaticAudio(accountChoices, null);
		initial.insertAudioItem(1, checkingAudio);
		
		VoiceElementConfig.AudioGroup nomatch = defaults.getAudioGroup("nomatch_audio_group", 1);
		nomatch.insertAudioItem(1, checkingAudio);
		
		VoiceElementConfig.AudioGroup noinput = defaults.getAudioGroup("noinput_audio_group", 1);
		noinput.insertAudioItem(1, checkingAudio);
		
		VoiceElementConfig.AudioGroup help = defaults.getAudioGroup("help_audio_group", 1);
		help.insertAudioItem(1, checkingAudio);
		
	    return defaults;
    }
}

