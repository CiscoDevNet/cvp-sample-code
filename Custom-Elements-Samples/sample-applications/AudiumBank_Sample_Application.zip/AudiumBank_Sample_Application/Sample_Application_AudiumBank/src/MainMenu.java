import com.audium.server.proxy.*;
import com.audium.server.session.*;
import com.audium.server.session.user.*;
import com.audium.server.voiceElement.*;
import com.audium.server.*;
import com.audium.server.xml.*;

import java.util.*;

/**
 * This class encapsulates the dynamic configuration for the Main Menu voice element.
 * The only dynamic part of the configuration is to provide options for each
 * kind of account the caller has. They may have all three accounts, two, or even one
 * account. To make things easier on the developer, the base configuration actually
 * contains the audio needed for all three accounts, and this dynamic configuration
 * then deletes those accounts the caller does not have. As for the speech-recognition
 * keywords, this class adds one for each account type the caller has.
 */
public class MainMenu implements VoiceElementInterface 
{
    public VoiceElementConfig getConfig(java.lang.String name, 
										ElementAPI elementAPI, 
										VoiceElementConfig defaults)
										throws AudiumException 
	{
		/* Get the initial audio group. This audio group has audio items for all
		account types. We need to modify it to list only those accounts the caller
		has. */
		VoiceElementConfig.AudioGroup initial = defaults.getAudioGroup("initial_audio_group", 1);
		
		/* If Session Data containing an account's balance exists, then the
		caller has that account. Delete the audio item having to do with that
		account and add a keyword for it in the inline grammar. */
		if (elementAPI.getSessionData("checkingBalance") == null) {
			initial.removeAudioItem(1);
		} else {
			defaults.addSettingValue("voice_keyword", "checking");
		}
		if (elementAPI.getSessionData("savingsBalance") == null) {
			initial.removeAudioItem(2);
		} else {
			defaults.addSettingValue("voice_keyword", "savings");
		}
		if (elementAPI.getSessionData("mmBalance") == null) {
			initial.removeAudioItem(3);
		} else {
			defaults.addSettingValue("voice_keyword", "money market");
		}
	    return defaults;
    }
}

