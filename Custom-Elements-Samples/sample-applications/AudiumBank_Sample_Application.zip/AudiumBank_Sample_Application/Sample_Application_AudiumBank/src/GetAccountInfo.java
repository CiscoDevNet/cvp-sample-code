import com.audium.server.proxy.*;
import com.audium.server.session.*;
import com.audium.server.session.user.*;
import com.audium.server.AudiumException;
import com.audium.server.voiceElement.ActionElementBase;
import java.util.*;

/**
 * This class contains the GetAccountInfo action element. The philosofy behind the
 * design of the Audium Bank application is to have a single action element that performs
 * much of the activity required by the application so that most of the rest of the
 * elements in the application can remain static. There are several advantages behind
 * this design:
 *
 * <P><LI> Most of the code for the application is concentrated in a single place. Making
 * changes is faster and more convenient.
 * <LI> Performance is improved by using static content since the Audium Server does not
 * need to run custom code.
 * <LI> This design works well in a developement enviroment that divides the work. The
 * developer can build the code while the application designer using the Audium Builder 
 * can build the flow of the application in parallel, simply referring to a "black box"
 * which they know the developer will supply later.
 *
 * <P>This design starts to break down once the activity becomes more involved.
 * The more work done, the longer the action will take, possibly incurring unnacceptable
 * wait times and burdening the memory footprint with data that may never be referred to
 * in the application. All these factors must be considered before the design of a voice
 * application is finalized.
 */

public class GetAccountInfo extends ActionElementBase
{
	static final int PREDICT_THRESHOLD = 3;
	
    public void doAction(java.lang.String name, ActionElementData actionAPI) throws AudiumException 
    {
    	/* Throughout the code is placed System.out statements to use for debugging
    	purposes. Depending on the application server, this content is printed on the
    	console on which the application server runs. */
    	
    	System.out.println("I am in account login");
    	
    	/* Use the API to get the account number and PIN entered by the caller. */
		String accountNumber = actionAPI.getElementData("Account", "value");
		String pin = actionAPI.getElementData("Pin", "value");
	    
	    /* Here, we need to use the User Management System to obtain information
	    on the user. We use the API provided for this. Since we need to find records
	    in the database affiliated with a user, we need to create a user query object.
	    We can set as many contraints as we want. Here the constraints are the account
	    number and PIN. Once the user query object is set, we obtain a list of users
	    that conform to the query constraints. */
		UserAPI userAPI = actionAPI.getUserAPI();
		UserQuery uq = new UserQuery();
		uq.setPinConstraint(pin);
		uq.setAccountNumberConstraint(accountNumber);
		
		List users =  userAPI.getUsers(uq);
		User user = null;
		
		/* If there are no users in the result, we know the account number and/or PIN
		is incorrect. We set the value of the Session Data named "badlogincount". The 
		presense of a non-zero value in this setting indicates that the login was incorrect.
		This value contains a count which is incremented here. A decision element later 
		in the call checks if the count has reached the maximum allowable. If the result 
		found a user, then we set this Session Data variable to 0, indicating the login 
		was valid*/
		if (users.size() == 0) {
			int badlogincount = 0;
			String savedCount = (String)actionAPI.getSessionData("badlogincount");
			if (savedCount != null) {
				badlogincount = Integer.parseInt(savedCount);
			}
			badlogincount++;
	    	actionAPI.setSessionData("badlogincount", Integer.toString(badlogincount));
	    	return;
		} else {
			actionAPI.setSessionData("badlogincount", Integer.toString(0));
		}
		
		String all_accounts = null;
		String balance = null;
		String account = null;
		String predicted_account = null;
		
		int naccounts = 0;
		
		/* Now that we know there is a user with the given account and PIN, we want
		to retrieve the User's record.*/
		
		user = (User) users.get(0);
		
		/* What we are doing here is a nice way to save ourselves work later. We "associate"
		this call with the user (identified by a UID automatically created by the user management
		system). From then on, there will be no need to go through the same process as above to
		get a record of that user, we just refer to the user associated with the account.
		This not only saves us coding work, but also acts as a "cache" for the user record. 
		All future requests for that user's data will come from the cache rather than making
		a new query from the database. The developer can then request information on this
		user as often as desired without worrying about whether that will hurt performance
		by dipping to the database each time. */
		Integer uid = user.getUid();
		userAPI.setUid(uid);
		
		/* The checking balance is stored in the "custom1" column of the user table. We
		get it and use the API to store it in Session Data named "checkingBalance". */
		String checkingBalance = user.getCustom1();
		if (checkingBalance != null) {
			account = all_accounts = "checking";
			naccounts++;
			balance = checkingBalance;
	    	actionAPI.setSessionData("checkingBalance", checkingBalance);
		}
		
		/* We do the same for savings (stored in the "custom2" column of the user table). */
		String savingsBalance = user.getCustom2();
		if (savingsBalance != null) {
			if (all_accounts != null) {
				all_accounts += " or savings";
			} else {
				all_accounts = "savings";
			}
			account = "savings";
			naccounts++;
			balance = savingsBalance;
	    	actionAPI.setSessionData("savingsBalance", savingsBalance);
		}
		/* Ditto for the money market (stored in "custom3"). */
		String mmBalance = user.getCustom3();
		if (mmBalance != null) {
			if (all_accounts != null) {
				all_accounts += " or money market";
			} else {
				all_accounts = "money market";
			}
			account = "money market";
			naccounts++;
			balance = mmBalance;
	    	actionAPI.setSessionData("mmBalance", mmBalance);
		}
			
		/* Now we have to check another part of the User Management System - the call
		history. We are interested in knowing how many times the caller got information
		on any of their accounts in previous calls. We will use this information to
		predict which account they are most likely interested in getting the balance of
		this time. This time a CallRecordQuery object is created with the restraints that
		of a call from the caller (identified by their UID) and a flag named "checking"
		was tripped during that call. We need to make sure the design of the call flow
		includes a flag trigger whenever a caller gets the balance of that account. */
		CallRecordQuery query = new CallRecordQuery(); 
		query.addFlagNameConstraint("checking"); 
		query.setUidConstraint(uid); 
		int num_checking = userAPI.getNumCallRecords(query); 
			
		query = new CallRecordQuery(); 
		query.addFlagNameConstraint("savings"); 
		query.setUidConstraint(uid); 
		int num_savings = userAPI.getNumCallRecords(query); 
			
		query = new CallRecordQuery(); 
		query.addFlagNameConstraint("money_market"); 
		query.setUidConstraint(uid); 
		int num_mm = userAPI.getNumCallRecords(query); 

		/* Now that we have that information, we use the following algorithm to determine
		which account to immediately give the caller the balance for:
		- The account that has been requested more than the other accounts
		- The number of times in the past the caller has requested the balance of the
		account is greater than some threshold. */
		if (num_checking > num_savings && num_checking > num_mm && 
			num_savings >= PREDICT_THRESHOLD) {
			predicted_account = account = "checking";
			balance = checkingBalance;
		} else if (num_savings > num_checking && num_savings > num_mm && 
				   num_savings >= PREDICT_THRESHOLD) {
			predicted_account = account = "savings";
			balance = savingsBalance;
		} else if (num_mm > num_savings && num_mm > num_checking && 
				   num_mm >= PREDICT_THRESHOLD) {
			predicted_account = account = "money market";
			balance = mmBalance;
		}
		/* We store various information needed by other elements in Session Data. */ 
	    actionAPI.setSessionData("balance", balance);
	    actionAPI.setSessionData("account", account);
	    if (predicted_account != null) {
	    	actionAPI.setSessionData("predicted_account", predicted_account);
	    }
	    actionAPI.setSessionData("all_accounts", all_accounts);
	    actionAPI.setSessionData("naccounts", Integer.toString(naccounts));
	    
	    /* We print out all the information for display purposes. */	    
		System.out.println("balance is              " + balance);
		System.out.println("account is              " + account);
		System.out.println("num_checking is         " + num_checking);
		System.out.println("num_savings is          " + num_savings);
		System.out.println("num_mm is               " + num_mm);
		System.out.println("predicted_account is    " + predicted_account);
		System.out.println("uid is                  " + uid);
		System.out.println("all_accounts is         " + all_accounts);
		System.out.println("naccounts is            " + naccounts);	    	
    }
}

