import com.audium.server.proxy.*;
import com.audium.server.session.*;
import com.audium.server.session.user.*;
import com.audium.server.AudiumException;
import com.audium.server.voiceElement.DecisionElementBase;

import java.util.*;

/**
 * Once the caller makes a choice in the main menu, we need to analyze that
 * choice and direct the call to the appropriate place. Even though we trigger
 * a different flag depending on the choice, we go to a single audio element
 * which reads back the balance. It gets the balance from Session Data that is
 * created here. This task is too much to do in an Audium XML Decision, so we
 * need to use a class.
 */
public class AccountBalanceQueryDecision extends DecisionElementBase 
{
    public String doDecision(java.lang.String name, DecisionElementData elementAPI) 
    						 throws AudiumException
    {
    	/* We have already associated a particular user with the call, so all
    	we need to do to get the user's information is use the getCurrentUser method.*/
		UserAPI userAPI = elementAPI.getUserAPI();
		User user = userAPI.getCurrentUser();
    	
    	/* The choice made by the caller is stored in Element Data named "value" in the
    	MainMenu element. We store this choice in Session Data. */
    	String choice = elementAPI.getElementData("MainMenu", "value");
	    elementAPI.setSessionData("account", choice);
	    
	    /* We next store the balance of the account chosen by the caller. */
	    if (choice.compareTo("checking") == 0) {
	    	elementAPI.setSessionData("balance", user.getCustom1());
	    } else if (choice.compareTo("savings") == 0) {
	    	elementAPI.setSessionData("balance", user.getCustom2());
	    } else if (choice.compareTo("money market") == 0) {
	    	choice = "money_market";
	    	elementAPI.setSessionData("balance", user.getCustom3());
	    }
	    
	    /* Return the appropriate account chosen by the caller. */
	    return choice;
    }
}

