import com.audium.server.proxy.*;
import com.audium.server.session.*;
import com.audium.server.session.user.*;
import com.audium.server.AudiumException;
import com.audium.server.voiceElement.ActionElementBase;

/**
 * This action class takes the selections made by the caller and sets up the appropriate
 * data for listing the source account and the destination account. This data is used in
 * other elements to make the transfer to save coding work elsewhere.
 */
public class FindTransferToAction extends ActionElementBase
{
    public void doAction(java.lang.String name, ActionElementData actionAPI) throws AudiumException 
    {
    	/* Get which account the caller wants to transfer from. */
	    String fromChoice = actionAPI.getElementData("TransferFrom", "value");
	    int naccounts = Integer.parseInt((String)actionAPI.getSessionData("naccounts"));
	    String toChoice = null;
	    
	    /* Find out which account to transfer to. */
	    if (naccounts == 2) {
	    	if (fromChoice.compareTo("checking") == 0) {
	    		if (actionAPI.getSessionData("savingsBalance") != null) {
	    			toChoice = "savings";
	    		} else {
	    			toChoice = "money market";
	    		}
	    	} else if (fromChoice.compareTo("savings") == 0) {
	    		if (actionAPI.getSessionData("checkingBalance") != null) {
	    			toChoice = "checking";
	    		} else {
	    			toChoice = "money market";
	    		}
	    	} else {
	    		if (actionAPI.getSessionData("checkingBalance") != null) {
	    			toChoice = "checking";
	    		} else {
	    			toChoice = "savings";
	    		}
	    	}
	    } else {
	    	toChoice = actionAPI.getElementData("TransferTo", "value");
	    }
	    if (fromChoice.compareTo("money market") == 0) {
	    	fromChoice = "mm";
	    }
	    
	    /* Store the balance of the account trasferring from and the name of the 
	    account transferring to. */
	    actionAPI.setSessionData("from_account_balance", 
	    						(String)actionAPI.getSessionData(fromChoice + "Balance"));
	    	
	    actionAPI.setSessionData("transfer_to_account", toChoice);
    }
}

