

1- Close Studio and stop VXML Server
2- Copy:
	XMPP_Library1.3.jar
	smack.jar 
	smackx.jar
	under:
	C:\Cisco\CallStudio\eclipse\plugins	\com.audiumcorp.studio.library.common_8.5.1\lib
(or similar for other versions)
	and
	C:\Cisco\CVP\VXMLServer\common\lib
3- Restart Studio and VXML Server
4- XMPP elements are now available from Studio palette, ready to be deployed.
5- Import the Sample Apps
6- Import ICM scripts


To debug the XMPP Elements, define the following Session Data in the Open element:

debug set as 1

if you are using pattern mode, you have to define also:
pool_debug set as 1

then, open the tomcat stdout log

Once done, set both Session data back to 0 or remove them, or logfile will grow



For comment/suggestion, post on

http://developer.cisco.com/web/cvp/forums/-/message_boards/view_message/4090997?_19_redirect=http%3a%2f%2fdeveloper.cisco.com%2fweb%2fcvp%2fforums%2f-%2fmessage_boards%2fsearch%3f_19_searchCategoryId%3d0%26_19_keywords%3dXMPP%26_19_breadcrumbsCategoryId%3d0%26_19_redirect%3dhttp%253a%252f%252fdeveloper.cisco.com%252fweb%252fcvp%252fforums%253fp_p_id%253d19%2526p_p_lifecycle%253d0%2526p_p_state%253dnormal%2526p_p_mode%253dview%2526p_p_col_id%253dcolumn-1%2526p_p_col_count%253d1

or send an email to mpirrone@cisco.com

This sample is supported as best effort. TAC does not support this Custom Lib
