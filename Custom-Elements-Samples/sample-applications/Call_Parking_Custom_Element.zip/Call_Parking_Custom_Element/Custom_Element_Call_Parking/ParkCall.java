package com.cisco.pt.cvp.vxml.ctrl;

/*
 * ===================================================================================
 * IMPORTANT
 *
 * This sample is intended for distribution on developer.cisco.com (CDC). It does not
 * form part of the CVP product release software and is not Cisco TAC supported. You
 * should refer to the CDC website Support Tab for support rules that apply to samples
 * published on CDC.
 * ===================================================================================
 *
 * PARK CALL CUSTOM VOICE ELEMENT
 * 
 * This element allows the caller to be parked at the CVP VoiceXML gateway on
 * an application-specified number and made available for pick-up by another caller
 * making a call to that gateway on the specified meet-me number.
 * Logically, the ParkCall element can be considered very similar to the Transfer
 * element used in bridged mode but with the transfer call leg direction reversed.
 * Instead of providing a destination number, you provide a pick-up number and a
 * call is received rather than sent.
 *
 * The call parking parameters are read from the element settings at run-time and
 * formatted into the handoff-object argument string in the following formats:
 *
 *      dnis=8881234 wait=120 media=flash:waitmusic.wav
 *      resume=<hold_id>
 *
 * VoiceXML is generated to perform a handoff-with-return operation to the TCL
 * service cvp_parkcall and the presence of the "resume" argument determines whether
 * an initial PARK or RESUME operation on an already-held pick-up call is performed.
 *
 * On return from TCL the park-call outcome is extracted from the handoff-object
 * return string, mapped into the element exit state and also copied into the element
 * data with name "result".  Other element data is populated from key:value pairs
 * appended to the outcome in the return string and separated by semi-colon,
 * for example:
 *
 *      pickup;holdid:cvp_parkcall_leg_394;name:Test Caller;cli:5517;addr:10.52.200.144;wait:15.236
 *
 * -----------------------------------------------------------------------------------
 * Version 1.0, Paul Tindall, Cisco, 22 Feb 2011
 * -----------------------------------------------------------------------------------
 */

import com.audium.server.AudiumException;
import java.util.*;

import com.audium.server.voiceElement.VoiceElementBase;
import com.audium.server.voiceElement.ElementInterface;
import com.audium.server.voiceElement.Setting;
import com.audium.server.voiceElement.ExitState;
import com.audium.server.voiceElement.ElementData;
import com.audium.server.voiceElement.ElementException;
import com.audium.server.session.VoiceElementData;
import com.audium.server.xml.VoiceElementConfig;

import com.audium.core.vfc.*;
import com.audium.core.vfc.form.*;
import com.audium.core.vfc.util.*;
import com.audium.server.voiceElement.Dependency;

public class ParkCall extends VoiceElementBase implements ElementInterface 
{
	public String getElementName()
	{
		return "ParkCall";
	}

	public String getDescription() 
	{
		return "Parks call at VoiceXML gateway on specified number";
	}

	public String getDisplayFolderName() 
	{
		return "Call Control";
	}

	public Setting[] getSettings() throws ElementException 
	{
                Setting cmd = new Setting("command", "Operation", "Parkcall operation: PARK, RESUME",
                                          true, true, true, new String[] {"PARK", "RESUME"});

                Setting pdn = new Setting("park_dnis", "Call Park DNIS",
                                          "Number to call to connect to parked call",
                                          true, true, true, Setting.STRING);

                Setting med = new Setting("play_media", "Caller Media",
                                          "Media played to caller while call is parked",
                                          true, true, true, Setting.STRING);

                Setting pto = new Setting("park_timeout", "Max Parked Time",
                                          "Maximum time (secs) call is parked waiting for incoming connection (default 60)",
                                          true, true, true, 0, null);

                Setting[] cfg_settings = new Setting[] {cmd, pdn, med, pto};

                pto.setDefaultValue("60");
								   
                Dependency cmdIsPark = new Dependency("command", "PARK", Dependency.EQUAL);
                Dependency[] dep_park = new Dependency[] {cmdIsPark};

                pdn.setDependencies(dep_park);
                med.setDependencies(dep_park);
                pto.setDependencies(dep_park);

                return cfg_settings;
	} 

	public HashMap getAudioGroups() throws ElementException 
	{
		return null;
        }
    
	public String[] getAudioGroupDisplayOrder() 
	{
		return null;
	}

        public ExitState[] getExitStates() throws ElementException 
	{
                ExitState timeout    = new ExitState("timeout", "timeout", "Maximum park time expired");
		ExitState duplicate  = new ExitState("duplicate_dnis", "duplicate_dnis", "Park call failed with duplicate DNIS");
		ExitState disconnect = new ExitState("disconnect", "disconnect", "Other party disconnected");
		ExitState error      = new ExitState("error", "error", "Error parking call");
		ExitState pickup     = new ExitState("pickup", "pickup", "Pickup-call received and held alerting");
                
		ExitState[] exitStateArray = new ExitState[] {timeout, duplicate, disconnect, error, pickup};
		return exitStateArray;
	}

	public ElementData[] getElementData() throws ElementException 
	{
                ElementData result = new ElementData("result", "Park call outcome");
                ElementData cli    = new ElementData("cli", "Calling line ID of user that picked-up call");
                ElementData addr   = new ElementData("addr", "IP address of pickup call");
                ElementData wait   = new ElementData("wait", "Caller wait time to call pickup");
                ElementData name   = new ElementData("name", "Caller display name of user that picked-up call");

                ElementData[] elemDataArray = new ElementData[] {result, cli, addr, wait, name};

                return elemDataArray;
	}
	
	protected String addXmlBody(VMain vxml, Hashtable reqParameters, VoiceElementData ved)
									throws VException, ElementException 
	{
		VPreference pref = ved.getPreference();
                Boolean process_response = (Boolean) ved.getScratchData("parkcall_sent");
                
		if (process_response == null)
                {
                    
// This is the first pass through addXmlBody() so build the VXML document.
// Start by looking up the dynamic settings for this element.
                    
                        VoiceElementConfig cfg = ved.getVoiceElementConfig();
                        
                        String cmd = cfg.getSettingValue("command", ved);
                        String pto = cfg.getSettingValue("park_timeout", ved);
                        String med = cfg.getSettingValue("play_media", ved);
                        String pdn = cfg.getSettingValue("park_dnis", ved);
                                           
// Start building the VXML doc by adding catch blocks to trap the various handoff events.

                        vxml.add(catch_block(pref, "telephone.disconnect.com.cisco.callhandoff", "parkresp", "error"));
                        vxml.add(catch_block(pref, "telephone.disconnect.com.cisco.handoff", "parkresp", "error"));
                        vxml.add(catch_block(pref, "telephone.disconnect", "parkresp", "error"));
                        vxml.add(catch_block(pref, "disconnect.com.cisco.callhandoff", "parkresp", "error"));
                        vxml.add(catch_block(pref, "disconnect.com.cisco.handoff", "parkresp", "error"));
                        vxml.add(catch_block(pref, "disconnect", "parkresp", "error"));

                        // Thrown if the conferenced call leg pair is returned to the VoiceXML session.
                        // Call legs stay connected but application ends so not exactly what we want.

//                        vxml.add(catch_block(pref, "connection.disconnect.com.cisco.callhandoff", "parkresp", "pickup"));

// Add main form which must be called "start"
// Add block containing setup actions before handing-off to TCL

                        VForm handoff_form = VForm.getNew(pref, "start");

                        VBlock handoff_init_blk = VBlock.getNew(pref);
                        VAction handoff_setup = VAction.getNew(pref, null, null, "PARKCALL, handing off to CVP_PARKCALL.TCL", false);
                        handoff_init_blk.add(handoff_setup);

                        handoff_form.add(handoff_init_blk);

// Add TCL handoff block to pass the park call parameters to the VXML gateway

                        String handoff_argstr;

                        if (cmd.equals("PARK"))
                        {
                                handoff_argstr = "'dnis=" + pdn + " wait=" + pto + " media=" + med + "'";
                        }
                        else
                        {
                                String holdid = (String) ved.getSessionData("parkcall_holdid");
                                handoff_argstr = "'resume=" + holdid + "'";
                        }

                        VObject handoff_obj = VObject.getNew(pref, "parkcall", "builtin://com.cisco.callhandoff", null);
                        handoff_obj.addParam("return", "true", true);
                        handoff_obj.addParam("app-uri", "'builtin://cvp_parkcall'", true);
                        handoff_obj.addParam("arg-string", handoff_argstr, true);
                        handoff_obj.setOutsideSubmit(false);
                        handoff_form.add(handoff_obj);

// Add block to handle and submit outcome following return from TCL back to VXML

                        VBlock handoff_complete_blk = VBlock.getNew(pref);

                        VAction handoff_submit = VAction.getNew(pref, null, null, "PARKCALL, returned from TCL", false);
                        handoff_submit.add(VAction.VARIABLE, "parkresp", "parkcall.argstring", false);
                        handoff_submit.add(getSubmitVAction("parkresp", pref));

                        handoff_complete_blk.add(handoff_submit);
                        handoff_form.add(handoff_complete_blk);
                        vxml.add(handoff_form);

                        ved.setScratchData("parkcall_sent", true);

                        return null;
                }
                else
                {
                    
// This is the second iteration through this method so process the park call outcome passed back on
// the VXML submit. Map the park call outcome to the correct element exit-state and write the actual
// result returned to element data.
                    
                        String exit_state;
                        String parkcall_outcome = (String) reqParameters.get("parkresp");

                        if (parkcall_outcome == null)
                        {
                                parkcall_outcome = "unknown";
                                exit_state = "error";
                        }
                        else
                        {
                                String[] rsptoken = parkcall_outcome.split(";");
                                exit_state = rsptoken[0];
                                parkcall_outcome = rsptoken[0];
                                String [] kv;

                                for (int i = 1; i < rsptoken.length; i++)
                                {

// Extract key:value pairs from the response message and write them to element data with the exception
// of the temporary call-holding session context ID that will be used on a subsequent RESUME operation;
// this is stored in session data.

                                        kv = rsptoken[i].split(":");
                                        if (kv.length == 2)
                                        {
                                                if ("holdid".equals(kv[0]))
                                                {
                                                        try {ved.setSessionData("parkcall_holdid", kv[1]);} catch (AudiumException ex) { }
                                                }
                                                else
                                                {
                                                        ved.setElementData(kv[0], kv[1], VoiceElementData.PD_STRING, true);
                                                }
                                        }
                                }
                        }

                        ved.setElementData("result", parkcall_outcome, VoiceElementData.PD_STRING, true);
                        return exit_state;
                }
        }

        private VEvent catch_block(VPreference pref, String event_name, String var_name, String var_value) throws VException
        {
                VEvent ev = VEvent.getNew(pref, event_name);
                VAction ev_assign = VAction.getNew(pref, VAction.VARIABLE, var_name, var_value, true);
                VAction submit_action = getSubmitVAction(var_name, pref);
                
                ev_assign.add(submit_action);
                ev.addCount(1);
                ev.setReprompt(1, false);
                ev.addItem(1, ev_assign);

                return ev;
        }
}        