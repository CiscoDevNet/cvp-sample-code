import java.util.*;

import com.audium.server.proxy.VoiceElementInterface;
import com.audium.server.AudiumException;
import com.audium.server.session.ElementAPI;
import com.audium.server.xml.VoiceElementConfig;

/**
 * This Dynamic Voice Element configuration class is used by the Clock Audio Voice Element
 * Configuration in the Audium Clock tutorial application.  It determines the current time and 
 * plays it for the caller, saying, "The current time is ____."
 */
public class TimeOfDay implements VoiceElementInterface
{
    /**
     * All Dynamic Voice Element Configuration classes must implement this method. This
     * method will be called when the call flow reaches a Voice Element Configuration that
     * references this class.
     */
    public VoiceElementConfig getConfig(String name, 
                                    ElementAPI elementAPI, 
                                    VoiceElementConfig defaults) throws AudiumException
    {
        // Since we do not have a base configuration, the VoiceElementConfig object defaults
        // is null.  Therefore, we need to create a new configuration.
        defaults = new VoiceElementConfig();

        // Create the initial Audio Group, whose actual name is "initial_audio_group" (see the voice elements
        // manual for more information).
        VoiceElementConfig.AudioGroup initialAudioGroup = defaults.new AudioGroup("initial_audio_group", true);

        // Create a Static Audio Item with the text-to-speech (TTS) "The current time is"
        VoiceElementConfig.StaticAudio beforeTime = defaults.new StaticAudio("The current time is ", null);

        // Next, create a Say-It-Smart Audio Item that says the current time.  Of course, before we do so,
        // we need to get the current time.
        Calendar c = Calendar.getInstance();
        c.setTime(new Date());
        String hour = new Integer(c.get(Calendar.HOUR_OF_DAY)).toString();
        if (hour.length() == 1) {
            hour = "0" + hour;
        }
        String minute = new Integer(c.get(Calendar.MINUTE)).toString();
        if (minute.length() == 1) {
            minute = "0" + minute;
        }
        String currentTime = hour + minute;
        
        /* 
        Construct a Say it Smart audio item that is to read back the time. We have to refer to a 
        Say It Smart plugin and define the input and output formats of the data. In this case we 
        are only interested in playing the audio in Text To Speech (TTS), though if we wanted to
        use pre-recorded audio we would have to specify an audio fileset that lists the audio
        files required to render the time.
        
        Note that the "real name" of the input and output formats are to be used here, not their "display
        names". The display names are only used in the Audium Builder. In this case, since what we want
        to read back is the time itself, we use the input format of "time_hhmm". There is only one output
        format for this input format, which is "time" (the Audium Time Say It Smart plugin can also handle
        time periods as well as the time itself). The last argument indicates that the data is to be
        hardcoded to what we pass it (the method is also used to specify a Session Data name to get the
        data from). The names of the standard Audium Say It Smart plugin classed are listed in the Audium 
        documentation.
        */
        String pluginClass = "com.audium.sayitsmart.plugins.AudiumSayItSmartTime";
        VoiceElementConfig.SayItSmart time = defaults.new SayItSmart(pluginClass, "time_hhmm", 
        															 "time", currentTime, false);

        // Add the two audio items we've built to the initial Audio Group.
        initialAudioGroup.addAudioItem(beforeTime);
        initialAudioGroup.addAudioItem(time);

        // Add the initial Audio Group to the Voice Element Configuration.
        defaults.setAudioGroup(initialAudioGroup);

        // Return the Voice Element Configuration.
        return defaults;
    }
}
