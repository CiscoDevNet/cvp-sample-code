import java.io.*;
import com.audium.server.AudiumException;
import com.audium.server.voiceElement.*;
import com.audium.server.session.ActionElementData;

/**
 * This Action class is used by the GetNumber Action Configuration in the Audium
 * Receptionist tutorial application. It retrieves either an office phone number
 * or a mobile phone number from one of two files, depending on the caller's selection
 * in the "OfficeOrMobile" Voice Element. While an action of this sort would normally
 * access a database to retrieve a phone number, we use a file to illustrate the use of
 * an Action without requiring a database.
 */
public class ReceptionistGetNumber extends ActionElementBase
{
    /**
     * All Action classes must implement this method.  This method will be called
     * when the call flow reaches an Action Element that references this class.
     */
    public void doAction(String name, ActionElementData actionData) throws AudiumException
    {
        String phoneFile = null;
        String phoneNum = null;

		// The file should be <Application Folder>/data/misc/
		String phonePath = actionData.getApplicationDirectory() + 
								File.separator + "data" +
								File.separator + "misc" +
								File.separator;
								
        // Get the caller's choice (office or mobile) from the option menu voice
        // element, OfficeOrMobile.  This data is stored in the variable "selection"
        // in OfficeOrMobile's Element Data (see the Voice Elements manual for more
        // information).
        String choice = actionData.getElementData("OfficeOrMobile", "value");

        if ("office".equals(choice)) {
            phoneFile = phonePath + "phone_office.txt";
        } else {
            phoneFile = phonePath + "phone_mobile.txt";
        }

        try {
            // Open the file and read it.
            FileInputStream fileInput = new FileInputStream(phoneFile);

            byte[] fileContents = new byte[fileInput.available()];
            fileInput.read(fileContents);
            fileInput.close();
            phoneNum = new String(fileContents).trim();

            if (phoneNum == null) {
                phoneNum = "";
            }
        } catch(FileNotFoundException e) {
            // If the file wasn't there, throw an exception.
            throw new AudiumException("Error retrieving phone number: file " +phoneFile+ " not found.");
        } catch (IOException ioe) {
            // If there was an I/O problem, throw an exception.
            throw new AudiumException("Error retrieving phone number: I/O error with file " +phoneFile+ ".");
        }

        // Set the value of the phone number retrieved into Element Data, and tell
        // the server to log the number to the activity log.
        actionData.setElementData("NumberToCall", phoneNum, ActionElementData.PD_INT, true);
    }
}
