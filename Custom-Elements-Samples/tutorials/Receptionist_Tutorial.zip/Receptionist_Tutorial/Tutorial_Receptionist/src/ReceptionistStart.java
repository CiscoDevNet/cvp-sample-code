import java.io.*;
import com.audium.server.AudiumException;
import com.audium.server.proxy.*;
import com.audium.server.session.*;

/**
 * This is the On Start Call class for the Audium Receptionist tutorial application.
 * It reads the total number of calls made to the receptionist from a text file and
 * stores this number in the Session Data as an Integer.  If we had a user management
 * database, the number of calls could easily be retrieved from the database, but to
 * illustrate the use of an On Start Call class without making a database necessary,
 * we use a file.
 */
public class ReceptionistStart implements StartCallInterface
{
    /**
     * All On Start Call classes must implement this method.  This method will
     * be called at the beginning of the call.  Note that this method runs in
     * a separate thread from the rest of the call, so there is no guarantee
     * that this method will complete its execution before parts of call flow
     * are reached.
     */
    public void onStartCall(CallStartAPI callStartAPI) throws AudiumException
    {
        // The file should be <Application Folder>/data/misc/num_calls.txt
        String fileNumCalls = callStartAPI.getApplicationDirectory() + 
                                File.separator + "data" +
                                File.separator + "misc" +
                                File.separator + "num_calls.txt";

        String numberOfCalls = null;
        Integer numberOfCallsAsInteger = null;
        FileInputStream fileInput = null;

        try {

            // Open the file and read it.
            fileInput = new FileInputStream(fileNumCalls);

            byte[] fileContents = new byte[fileInput.available()];
            fileInput.read(fileContents);
            fileInput.close();
            numberOfCalls = new String(fileContents);

            if (numberOfCalls != null) {
                try {
                    // The contents of the file should be nothing more than an integer.
                    numberOfCallsAsInteger = new Integer(numberOfCalls.trim());
                } catch (NumberFormatException nfe) {
                    // If the file contained anything other than an integer in it,
                    // set the number of calls to 0.
                    numberOfCallsAsInteger = new Integer(0);
                }
            } else {
                // If the file contained anything other than an integer in it,
                // set the number of calls to 0.
                numberOfCallsAsInteger = new Integer(0);
            }
        } catch(FileNotFoundException e) {
            // If the file wasn't there, set the number of calls to 0.
            numberOfCallsAsInteger = new Integer(0);
        } catch (IOException ioe) {
            // If there was an I/O problem, set the number of calls to 0.
            numberOfCallsAsInteger = new Integer(0);
        }

        // Set the Integer object containing the number of calls made to the receptionist
        // into the Session Data, under the variable name "Number Of Calls"
        callStartAPI.setSessionData("Number Of Calls", numberOfCallsAsInteger);
    }
}
