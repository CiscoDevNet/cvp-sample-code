import com.audium.server.AudiumException;
import com.audium.server.voiceElement.*;
import com.audium.server.session.DecisionElementData;

/**
 * This Decision class is used by the ValidateNumber Decision Configuration in the Audium
 * Receptionist tutorial application.  It validates the phone number retrieved by the
 * GetNumber Action Element, ensuring that it is an integer and contains exactly
 * 10 digits.
 */
public class ReceptionistValidateNumber extends DecisionElementBase
{
    /**
     * All Decision classes must implement this method.  This method will be called
     * when the call flow reaches a Decision Element that references this class.
     */
    public String doDecision(String name, DecisionElementData decisionData) throws AudiumException
    {
        String exitState = "invalid";

        // Get the phone number retrieved by GetNumber.
        String numToCall = decisionData.getElementData("GetNumber", "NumberToCall");

        // Validate the phone number.  It must be an integer, and it must be 10 digits
        // long.
        try {
            Long.parseLong(numToCall);

            if (numToCall.length() == 10) {
                exitState = "valid";
            }
        } catch (NumberFormatException ignore) {}

        return exitState;
    }
}
