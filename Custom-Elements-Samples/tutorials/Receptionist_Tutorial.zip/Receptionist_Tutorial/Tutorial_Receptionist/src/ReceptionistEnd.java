import java.io.*;
import com.audium.server.AudiumException;
import com.audium.server.proxy.*;
import com.audium.server.session.*;

/**
 * This is the On End Call class for the Audium Receptionist tutorial application.
 * It writes the total number of calls made to the receptionist to a text file.  The
 * number written is one greater than the number retrieved by the On Start Call class
 * (the number now stored in Session Data as an Integer with the variable name "Number
 * Of Calls").  If we had a user management database, this sort of update would be
 * performed automatically by Audium Call Services, but to illustrate the use of an On
 * End Call class without making a database necessary, we use a file and perform
 * the update manually.
 */
public class ReceptionistEnd implements EndCallInterface
{
    /**
     * All On End Call classes must implement this method.  This method will
     * be called at the end of the call, as soon as the call flow has been completed.
     */
    public void onEndCall(CallEndAPI endpointAPI) throws AudiumException
    {
		// The file should be <Application Folder>/data/misc/num_calls.txt
		String fileNumCalls = endpointAPI.getApplicationDirectory() + 
								File.separator + "data" +
								File.separator + "misc" +
								File.separator + "num_calls.txt";

        // Get the current number of calls from Session Data.
        Integer numberOfCallsAsInteger = (Integer)endpointAPI.getSessionData("Number Of Calls");
        if (numberOfCallsAsInteger != null) {
            numberOfCallsAsInteger = new Integer(numberOfCallsAsInteger.intValue() + 1);
        } else {
            numberOfCallsAsInteger = new Integer(1);
        }

        FileOutputStream fileOutput = null;
        try {

            // Open the file and write to it.
            fileOutput = new FileOutputStream(fileNumCalls, false);

            byte[] fileContents = numberOfCallsAsInteger.toString().getBytes();
            fileOutput.write(fileContents);
            fileOutput.close();
        } catch(FileNotFoundException e) {
            // If the file wasn't there, throw an exception.
            throw new AudiumException("Error updating number of calls: file not found.");
        } catch (IOException ioe) {
            // If there was an I/O problem, throw an exception.
            throw new AudiumException("Error updating number of calls: I/O error.");
        }
    }
}
