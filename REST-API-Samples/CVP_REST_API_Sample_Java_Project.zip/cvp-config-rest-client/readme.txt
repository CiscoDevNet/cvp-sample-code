This file provides sample on how to consume CVP configuration rest API's. The following are the steps to run the samples.

1. Import the maven project into Eclipse. File Menu > Import > Existing Maven Projects > Browse ..
2. Edit env.properties in the dir src\main\resources to reflect your CVP environment.
3. Go to src\test\java directory and run the JUnit files.
