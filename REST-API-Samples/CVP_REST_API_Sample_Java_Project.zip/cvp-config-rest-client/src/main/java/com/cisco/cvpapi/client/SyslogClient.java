/**
 *  Copyright (c) 2000 Cisco Systems Inc. All Rights Reserved.
 *
 * The Java source code is the confidential and proprietary information
 * of Cisco Systems Inc. ("Confidential Information").  You shall
 * not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Cisco Systems.
 *
 * Cisco Systems MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. Cisco Systems SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
package com.cisco.cvpapi.client;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.ClientFilter;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;

/**
 * Configures CVP Syslog using CVP configuration rest APIs. Uses Jersey client
 * api to send requests
 * 
 * @author ndreddy@cisco.com <Nagendra Reddy>
 */
public class SyslogClient extends BaseClient {

	/**
	 * Gets the syslog configuration for the given server.
	 * <p>
	 * 
	 * 1. First query deployed servers using GET Server List REST API. 2. Parse
	 * the response and obtain the server reference URL. 3. Call this method
	 * passing the server reference URLS
	 * 
	 * @param syslogUrl
	 *            - Server syslog URL. Example -
	 *            https://10.78.26.35:8111/cvp-config
	 *            /server/8a94edd0-0e3a-4e7e-9
	 *            a9a-cad5162c04e5/infrastructure/syslog
	 * 
	 * 
	 * @return
	 */
	public String get(String url) {

		Client client = null;
		ClientFilter authFilter = null;
		WebResource webResource = null;
		ClientResponse res = null;
		String jsonResponse = null;

		try {
			client = getSSLClient();
			authFilter = new HTTPBasicAuthFilter(userName, password);
			client.addFilter(authFilter);

			webResource = client.resource(url);
			res = webResource.accept(MediaType.APPLICATION_JSON).get(
					ClientResponse.class);
			log("get() - response: " + res.toString());
			if (res != null && res.getStatus() == 200) {
				jsonResponse = res.getEntity(new GenericType<String>() {
				});
			}
			log("get() - response json: " + jsonResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonResponse;
	}

	/**
	 * Updates the syslog configuration for the given server.
	 * <p>
	 * 
	 * 1. First query deployed servers using GET Server List REST API. 2. Parse
	 * the response and obtain the server reference URL. 3. Call this method
	 * passing the server reference URLS
	 * 
	 * @param url
	 *            - Server Reference URL.
	 *            https://10.78.26.35:8111/cvp-config/server
	 *            /8a94edd0-0e3a-4e7e-9a9a-cad5162c04e5
	 * @return
	 */
	public String put(String url) {

		Client client = null;
		ClientFilter authFilter = null;
		WebResource webResource = null;
		ClientResponse res = null;
		String jsonResponse = null;

		// Reads json form data.
		String jsonInput = readFile("syslog-config.json");

		try {
			// Gets Jersey Client
			client = getSSLClient();
			authFilter = new HTTPBasicAuthFilter(userName, password);
			client.addFilter(authFilter);

			// Gets Web Resource fo the url
			webResource = client.resource(url);

			// Sends put request.
			res = webResource.type(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON)
					.put(ClientResponse.class, jsonInput);
			log(res.toString());

			if (res != null && res.getStatus() == 200) {
				jsonResponse = res.getEntity(new GenericType<String>() {
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonResponse;
	}
	
	/**
	 * Deletes syslog configuration.
	 * There is no delete api for syslog instead a blank 
	 * configuration is read and applied.
	 * @param url
	 * @return json response.
	 */
	public String delete(String url) {

		Client client = null;
		ClientFilter authFilter = null;
		WebResource webResource = null;
		ClientResponse res = null;
		String jsonResponse = null;

		// Reads json form data.
		String jsonInput = readFile("syslogblank-config.json");

		try {
			// Gets Jersey Client
			client = getSSLClient();
			authFilter = new HTTPBasicAuthFilter(userName, password);
			client.addFilter(authFilter);

			// Gets Web Resource fo the url
			webResource = client.resource(url);

			// Sends put request.
			res = webResource.type(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_JSON)
					.put(ClientResponse.class, jsonInput);
			log(res.toString());

			if (res != null && res.getStatus() == 200) {
				jsonResponse = res.getEntity(new GenericType<String>() {
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonResponse;
	}

}
