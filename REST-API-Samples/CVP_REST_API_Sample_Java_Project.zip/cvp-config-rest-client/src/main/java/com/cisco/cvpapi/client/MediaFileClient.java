/**
 *  Copyright (c) 2000 Cisco Systems Inc. All Rights Reserved.
 *
 * The Java source code is the confidential and proprietary information
 * of Cisco Systems Inc. ("Confidential Information").  You shall
 * not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Cisco Systems.
 *
 * Cisco Systems MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. Cisco Systems SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */

package com.cisco.cvpapi.client;

import javax.ws.rs.core.MediaType;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.ClientFilter;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.multipart.FormDataMultiPart;

public class MediaFileClient extends BaseClient {

	/**
	 * Send Post request to the server. 
	 * @param url of the server. 
	 * <p>
	 * Example. url = "https://cvp.com:8111/cvp-config/mediafile"
	 * <p>
	 * @return response form the server.
	 */
	public String post(String url) {

		// Jersey client fields.
		Client client = null;
		ClientFilter authFilter = null;
		WebResource webResource = null;
		ClientResponse res = null;
		
		// File upload fields
		byte fileContent[] = null;
		String metadata = null;
		
		// Final response
		String jsonResponse = null;
				
		// Creates Multi Part Form Data
		FormDataMultiPart formData = new FormDataMultiPart();

		// Reads music.wav from class path into bytes.
		fileContent = readFileAsBytes("music.wav");

		// Adds file bytes to multipart form data.
		formData.field("mediafile", fileContent,
				MediaType.APPLICATION_OCTET_STREAM_TYPE);

		// Reads metadata from the file in classpath
		metadata = readFile("create_mediafile.json");

		// Adds metadata to multipart form data.
		formData.field("mediaUploadConfig", metadata,
				MediaType.APPLICATION_JSON_TYPE);

		try {
			
			// Creates Secure Jersey Client.
			client = getSSLClient();
			
			// Adds Http Basic Authentication
			authFilter = new HTTPBasicAuthFilter(userName,
					password);
			client.addFilter(authFilter);
			
			// Get web resource from client for the URL
			webResource = client.resource(url);
			
			// Specifies type and accept header and posts the request.
			res = webResource.type(MediaType.MULTIPART_FORM_DATA)
					.accept(MediaType.APPLICATION_JSON_TYPE)
					.post(ClientResponse.class, formData);
			
			// Logs the response.
			log("post() - response: " + res.toString());
			
			// Checks whether the response has success code
			if (res != null && res.getStatus() == 200) {
				jsonResponse = res.getEntity(new GenericType<String>() {
				});
			}
		} catch (Exception e) {
			//Handle the exception. Here just logs it to console.
			e.printStackTrace();
		}
		return jsonResponse;
	}
	
	/**
	 * Gets the media file on server
	 * 
	 * @param url The url of the file
	 * <p>
	 * Example https://cvp.com/cvp-config/mediafile/en-us/music.wav
	 * @return response from the server.
	 */
	public String get(String url) {

		Client client = null;
		ClientFilter authFilter = null;
		WebResource webResource = null;
		ClientResponse res = null;
		String jsonResponse = null;
		
		try {
			client = getSSLClient();
			authFilter = new HTTPBasicAuthFilter(userName,
					password);
			client.addFilter(authFilter);

			
			webResource = client.resource(url);
			res = webResource.accept(MediaType.APPLICATION_JSON)
					.get(ClientResponse.class);
			log("get() - response: " + res.toString());
			if (res != null && res.getStatus() == 200) {
				jsonResponse = res.getEntity(new GenericType<String>() {
				});
			}
			log("get() - response json: " + jsonResponse);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonResponse;
	}
	
	
	/**
	 * Deletes the file on the server.
	 * @param url Url of the file.
	 * @return response.
	 */
	public String delete(String url){
		
		Client client = null;
		ClientFilter authFilter = null;
		WebResource webResource = null;
		ClientResponse res = null;
		String jsonResponse = null;
		
		try {
			client = getSSLClient();
			authFilter = new HTTPBasicAuthFilter(userName,
					password);
			client.addFilter(authFilter);

			
			webResource = client.resource(url);
			res = webResource.accept(MediaType.APPLICATION_JSON)
					.delete(ClientResponse.class);
			
			log("delete() - response: " + res.toString());
			if (res != null && res.getStatus() == 202) {
				jsonResponse = res.getEntity(new GenericType<String>() {
				});
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return jsonResponse;
	}

}
