/**
 *  Copyright (c) 2000 Cisco Systems Inc. All Rights Reserved.
 *
 * The Java source code is the confidential and proprietary information
 * of Cisco Systems Inc. ("Confidential Information").  You shall
 * not disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Cisco Systems.
 *
 * Cisco Systems MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. Cisco Systems SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 */
package com.cisco.cvpapi.client;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.core.MediaType;

import org.codehaus.plexus.util.IOUtil;
import org.custommonkey.xmlunit.XMLUnit;
import org.custommonkey.xmlunit.XpathEngine;
import org.python.google.common.io.ByteStreams;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.client.filter.ClientFilter;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.sun.jersey.client.urlconnection.HTTPSProperties;

/**
 * Provides common functionality for all the rest clients.
 * 
 * @author ndreddy@cisco.com
 *
 */
public class BaseClient {

	/** The user name. */
	protected String userName;

	/** The password. */
	protected String password;

	/** The base url. */
	protected String baseUrl;
	
	/** The env. */
	private Env env = null;
	
	// Change WSM Credentials to reflect your env. 
	//String userName = "wsmadmin";
	//String password = "cvp4!CVP12Ccbu12";
	
	// Change IP to reflect your OAMP IP Address
	String srvListurl = "https://10.78.26.35:8111/cvp-config/server/";
	
	
	public BaseClient() {
		super();
		initEnv();
	}

	/**
	 * Inits the env.
	 */
	public void initEnv() {
		env = Env.getInstance();
		this.userName = env.getUserId();
		this.password = env.getPassword();
		this.baseUrl = env.getBaseUrl();
	}
	
	public String getOneSrvRefUrl() {

		NodeList nodeList = null;
		int size = 0;
		String[] urls = null;
		String serverType = "CALL";

		try {
			Document doc = XMLUnit.buildControlDocument(getRequest(srvListurl,
					MediaType.APPLICATION_XML));
			XpathEngine engine = XMLUnit.newXpathEngine();
			nodeList = engine.getMatchingNodes(
					"//server/refURL[../type/text() = '" + serverType + "']",
					doc);
			size = nodeList.getLength();
			log("getRefUrls(): No of Servers : [" + serverType + "] = " + size);
			urls = new String[size];
			for (int i = 0; i < size; i++) {
				Node node = nodeList.item(i);
				urls[i] = node.getTextContent();
				log("getRefUrls():" + urls[i]);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return urls[0];

	}

	/**
	 * 
	 * @param url
	 * @param type
	 * @return
	 */
	public String getRequest(String url, String type) {

		String response = null;

		try {
			Client client = getSSLClient();
			ClientFilter authFilter = new HTTPBasicAuthFilter(userName,
					password);
			client.addFilter(authFilter);

			WebResource webResource = null;
			webResource = client.resource(url);
			ClientResponse res = webResource.accept(type).get(
					ClientResponse.class);
			System.out.println(res);
			if (res != null && res.getStatus() == 200) {
				response = res.getEntity(new GenericType<String>() {
				});
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(response);
		return response;
	}

	
	/**
	 * Create SSL client for https requests
	 * 
	 * @return Secure Client
	 * @throws NoSuchAlgorithmException
	 * @throws KeyManagementException
	 */
	public static Client getSSLClient() throws NoSuchAlgorithmException,
			KeyManagementException {

		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs,
					String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs,
					String authType) {
			}
		} };

		// Install the all-trusting trust manager
		SSLContext sc = null;
		try {
			sc = SSLContext.getInstance("TLS");
			sc.init(null, trustAllCerts, new SecureRandom());
			HttpsURLConnection
					.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception e) {
			;
		}

		ClientConfig config = new DefaultClientConfig();
		config.getProperties().put(HTTPSProperties.PROPERTY_HTTPS_PROPERTIES,
				new HTTPSProperties(new HostnameVerifier() {
					@Override
					public boolean verify(String s, SSLSession sslSession) {
						// whatever your matching policy states
						return true;
					}
				}, sc));
		Client client = Client.create(config);

		return client;
	}
	

	/**
	 * Reads the file from classpath..
	 * 
	 * @param fileName
	 *            the file name
	 * @return the byte[]
	 */
	public String readFile(String fileName) {
		InputStream in = null;
		String theString = null;

		log("readFile() - Searching for file in classpath: " + fileName);
		in = getClass().getResourceAsStream('/' + fileName);
		if (in == null) {
			log("readFile() - File not found in classpath.");
		}

		try {
			StringWriter writer = new StringWriter();
			IOUtil.copy(in, writer);
			theString = writer.toString();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (theString != null) {
			log("readFile() - file lenght: " + theString.length());
			log("readFile() - file content: " + theString);
		}
		return theString;

	}
	
	/**
	 * Reads the file from classpath..
	 * 
	 * @param fileName
	 *            the file name
	 * @return the byte[]
	 */
	public byte[] readFileAsBytes(String fileName) {
		InputStream in = null;
		byte[] bytes = null;

		log("readFileAsBytes() - Searching for file in classpath: " + fileName);
		in = getClass().getResourceAsStream('/' + fileName);
		if (in == null) {
			log("readFile() - File not found in classpath.");
		}

		try {
			bytes = ByteStreams.toByteArray(in);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (bytes != null) {
			log("readFileAsBytes() - bytes read: " + bytes.length);
		}
		return bytes;

	}

	
	

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

	public void log(String msg) {
		System.out.println(this.getClass().getSimpleName()+ ":" + msg);
	}

}
