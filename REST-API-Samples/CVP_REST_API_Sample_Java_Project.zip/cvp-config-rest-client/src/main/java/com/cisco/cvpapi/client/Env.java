package com.cisco.cvpapi.client;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

/**
 * Provides test environment properties like rest host ipaddress, userId and
 * password details.
 * 
 * @author <a href="mailto:ndreddy@cisco.com">Nagendra Reddy</a>
 */
public class Env {

	/** The Constant PORT. */
	private static final String PORT = "port";

	/** The Constant PROTOCOL. */
	private static final String PROTOCOL = "protocol";

	/** The Constant BASE_URL. */
	private static final String HOST = "OAMP";

	/** The Constant PASSWORD. */
	private static final String PASSWORD = "password";

	/** The Constant USER_ID. */
	private static final String USER_ID = "userId";

	/** The resource bundle. */
	private ResourceBundle rb;

	private static volatile Env INSTANCE;

	/**
	 * Instantiates a new env.
	 */
	protected Env() {

		try {
			rb = ResourceBundle.getBundle("env");
		} catch (MissingResourceException mre) {
			log("No resource bundle found for: env.properties");
		}
	}

	/**
	 * Gets singlton instance of Env.
	 * 
	 * @return Env instance
	 */
	public static Env getInstance() {
		if (INSTANCE == null)
			synchronized (Env.class) {
				if (INSTANCE == null)
					INSTANCE = new Env();
			}
		return INSTANCE;
	}

	/**
	 * Gets the user id.
	 * 
	 * @return the user id
	 */
	public String getUserId() {
		return getProperty(USER_ID);
	}

	/**
	 * Gets the passwrod.
	 * 
	 * @return the passwrod
	 */
	public String getPassword() {
		return getProperty(PASSWORD);
	}

	/**
	 * Gets the base url.
	 * 
	 * @return the base url
	 */
	public String getBaseUrl() {
		String baseUrl = new StringBuilder(getProperty(PROTOCOL)).append("://")
				.append(getProperty(HOST)).append(":")
				.append(getProperty(PORT)).toString();
		log("getBaseUrl():" + baseUrl);
		return baseUrl;
	}

	/**
	 * Gets the property.
	 * 
	 * @param property
	 *            the property
	 * @return the property
	 */
	private String getProperty(String property) {
		String value = System.getenv(property);
		if (value == null || value.isEmpty()) {
			value = rb.getString(property);
		}
		return value;
	}

	/**
	 * Logs message to a file.
	 * 
	 * @param msg
	 *            the msg
	 */
	public static void log(String msg) {
		System.out.println("Env." + msg);
	}
}
