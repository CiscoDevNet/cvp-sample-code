package com.cisco.cvpapi.client.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cisco.cvpapi.client.MediaFileClient;

public class MediaFileClientTest {

	
	@Test
	public void testCreateMediafile() {
		MediaFileClient client = new MediaFileClient();
		String url =  client.getBaseUrl() + "/cvp-config/mediafile";
		assertNotNull(client.post(url));
	}

	@Test
	public void testGetMediafile() {
		MediaFileClient client = new MediaFileClient();
		String url =  client.getBaseUrl() + "/cvp-config/mediafile/en-us/music.wav";
		assertNotNull(client.get(url));
	}

	@Test
	public void testDeleteMediafile() {
		MediaFileClient client = new MediaFileClient();
		String url =  client.getBaseUrl() + "/cvp-config/mediafile/en-us/music.wav";
		assertNotNull(client.delete(url));
	}
	
}
