package com.cisco.cvpapi.client.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.cisco.cvpapi.client.VxmlAppClient;

public class VxmlAppClientTest {

	@Test
	public void testCreateVxmlApp() {
		VxmlAppClient client = new VxmlAppClient();
		String url =  client.getBaseUrl() + "/cvp-config/vxmlapp/deploy";
		assertNotNull(client.post(url));
	}

	@Test
	public void testGetVxmlApp() {
		VxmlAppClient client = new VxmlAppClient();
		String url =  client.getBaseUrl() + "/cvp-config/vxmlapp/SelfService";
		assertNotNull(client.get(url));
	}

	@Test
	public void testDeleteVxmlApp() {
		VxmlAppClient client = new VxmlAppClient();
		String url =  client.getBaseUrl() + "/cvp-config/vxmlapp/SelfService";
		// Allow to create
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

		assertNotNull(client.delete(url));
	}
}
