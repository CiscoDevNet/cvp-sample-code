package com.cisco.cvpapi.client.test;
import static org.junit.Assert.assertNotNull;

import org.junit.Test;

import com.cisco.cvpapi.client.SyslogClient;


public class SyslogClientTest {

	
	@Test
	public void testGetSyslog() {
		SyslogClient syslogClient = new SyslogClient();
		String srvRefUrl = syslogClient.getOneSrvRefUrl();
		String syslogUrl = srvRefUrl + "/infrastructure/syslog";
		assertNotNull(syslogClient.get(syslogUrl));
	}

	@Test
	public void testPutSyslog() {
		SyslogClient syslogClient = new SyslogClient();
		String srvRefUrl = syslogClient.getOneSrvRefUrl();
		assertNotNull(syslogClient.put(srvRefUrl));
	}

	@Test
	public void testDeleteSyslog() {
		SyslogClient syslogClient = new SyslogClient();
		String srvRefUrl = syslogClient.getOneSrvRefUrl();
		assertNotNull(syslogClient.delete(srvRefUrl));
	}
		
	
}
